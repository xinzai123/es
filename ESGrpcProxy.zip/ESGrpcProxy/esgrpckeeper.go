package main

import (
	"os/exec"
	"strings"
	"time"
	"./tools"
)

func main() {
	for{
		//fmt.Println("开始监控ES-Proxy服务状态......")
		cmd := exec.Command("/bin/sh", "-c", `ps -ef | grep "/usr/local/esgrpc/ESService"`)
		ret, _ := cmd.Output()
		out := string(ret)
		if !strings.Contains(out, "/usr/local/esgrpc/ESService agent") {
			//不正常，启动服务
			tools.SendWeixinMsg("esgrpc服务状态异常，自动重启","Host:"+tools.MyConfigHelper.ConfigCentor().Server_Host)
			cmd = exec.Command("/bin/sh", "-c", `/usr/local/esgrpc/restartesgrpc.sh`)
			_, err := cmd.Output()
			if err != nil {
				tools.SendWeixinMsg("esgrpc服务状态异常，自动重启失败","Host:"+tools.MyConfigHelper.ConfigCentor().Server_Host+","+err.Error())
			}
		}
		time.Sleep(5 * time.Second)
	}
}
package tools

import "strings"

var ObjCommonHelper CommonHelper

type CommonHelper struct {

}

//region 检查slice中是否包含某值
func (this *CommonHelper) CheckSliceContain(arr []int32,val int32) (r bool) {
	if arr==nil || len(arr)==0{
		return false
	}
	for i := 0; i < len(arr); i++ {
		if arr[i]==val{
			return true
		}
	}
	return false
}

func (this *CommonHelper) CheckSliceContainInt(arr []int,val int) (r bool) {
	if arr==nil || len(arr)==0{
		return false
	}
	for i := 0; i < len(arr); i++ {
		if arr[i]==val{
			return true
		}
	}
	return false
}

func (this *CommonHelper) CheckSliceContainString(arr []string,val string) (r bool) {
	if arr==nil || len(arr)==0{
		return false
	}
	for i := 0; i < len(arr); i++ {
		if strings.ToLower(arr[i])==strings.ToLower(val) {
			return true
		}
	}
	return false
}
//endregion

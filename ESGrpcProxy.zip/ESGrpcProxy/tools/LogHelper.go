package tools

import (
	"encoding/json"
	"fmt"
	"time"
	pb "../grpc"
	"os"
	"sync"
	//"strconv"
	"strconv"
)

type LogHelper struct {

}

//region 公共变量初始化
var logCountIndexName = "esgrpccount"
//提交搜索次数日志的频率(分钟)
var logCountInterval = 5
//搜索详细日志channel大小
var logChannelSize int = 10000
//搜索次数日志channel大小
var logCountChannelSize int = 10000
//搜索详细日志channel对象
var logChannel chan *RuntimeLogger
//搜索次数日志channel对象
var logCountChannel chan *CountLogger
//搜索次数日志计数器channel对象
var logCountTotalChannel chan *CountLoggerTotalMap
var logger *LogHelper
var InitStatus bool = false
//搜索次数汇总日志map
var mapLogCounter CountLoggerTotalMap
var mutex *sync.Mutex=new(sync.Mutex)
//endregion

//region 单例入口
func  GetLogger() (r *LogHelper){
	if !InitStatus{
		InitStatus=true
		logger=new(LogHelper)
	}
	return logger
}
//endregion

//region 搜索详细日志channel消费入口
func ConsumeLogChannel(){
	//defer close(logChannel)
	if logChannel==nil{
		logChannel=make(chan *RuntimeLogger,logChannelSize)
	}
	for{
		if log, ok := <-logChannel; ok {
			if MyConfigHelper.ConfigCentor().LogType=="elk"{
				GetLogger().sendLogToELKMQ(log,MyConfigHelper.ConfigCentor().MQLogRouteKey)
			}else if MyConfigHelper.ConfigCentor().LogType=="file"{
				GetLogger().WriteFileLog(log)
			}
			continue
		}
		time.Sleep(5*time.Second)
	}
}
//endregion

//region 搜索次数日志channel消费入口
func ConsumeLogCountChannel(){
	//region 捕获搜索异常信息
	defer func(){
		if err:=recover();err!=nil{
			fmt.Println("记录请求次数日志异常："+err.(error).Error())
		}
	}()
	//endregion
	if logCountChannel==nil{
		logCountChannel=make(chan *CountLogger,logCountChannelSize)
	}
	for{
		//判断是否需要提交请求次数日志到ELK
		sendLogCountLogToELKMQ()
		if len(logCountChannel)<=0{
			//channel中暂无数据，休眠5秒后继续循环
			time.Sleep(5*time.Second)
			//fmt.Println("休眠5秒:"+time.Now().Format("2006-01-02 15:04:05"))
		}else {
			if len(logCountChannel)>0{
			if log, ok := <-logCountChannel; ok {
				var logtotal *CountLoggerTotalMap
				var oktotal bool
				if logCountTotalChannel==nil{
					logCountTotalChannel=make(chan *CountLoggerTotalMap,10)
				}
				if len(logCountTotalChannel)>0{
					if logtotal,oktotal= <-logCountTotalChannel;oktotal{
					if curLog,okmap:=logtotal.MapCount[log.RequestSource];okmap{
						//读取单个CountLogger，合并到mapCountLoggerTotal对象
						//fmt.Println("累加RequestCount")
						curLog.RequestCount++
						curLog.TotalTime+=log.SearchTime
						if log.ResultCount==0{
							curLog.EmptyCount++
						}
					}else{
						//fmt.Println("new tCountLoggerTotal")
						curLog=initCountLoggerTotal(log)
						logtotal.MapCount[log.RequestSource]=curLog
					}
					}
				}else{
					//fmt.Println("new CountLoggerTotalMap")
					logtotal=new(CountLoggerTotalMap)
					curLog:=initCountLoggerTotal(log)
					logtotal.MapCount=make(map[int32]*CountLoggerTotal)
					logtotal.MapCount[log.RequestSource]=curLog
				}
				logCountTotalChannel <- logtotal
				}
			}else{
				fmt.Println("logCountChannel  empty...")
			}
		}
	}
}

func initCountLoggerTotal(log *CountLogger)*CountLoggerTotal{
	curLog:=new(CountLoggerTotal)
	curLog.RequestSource=log.RequestSource
	curLog.RequestCount=1
	curLog.IndexName=logCountIndexName
	curLog.ClientIp=log.ClientIp
	curLog.SysName=log.SysName
	curLog.TotalTime=log.SearchTime
	curLog.ServerIp=MyConfigHelper.ConfigCentor().Server_Host
	if log.ResultCount==0{
		curLog.EmptyCount=1
	}else{
		curLog.EmptyCount=0
	}
	return curLog
}
//endregion

//region 发送channel中的请求次数信息到ELK-MQ
func sendLogCountLogToELKMQ(){
	//region 捕获异常信息
	defer func(){
		if err:=recover();err!=nil{
			fmt.Println("发送请求次数日志到MQ异常："+err.(error).Error())
		}
	}()
	//endregion

	mutex.Lock()
	defer mutex.Unlock()
	curTime := time.Now()
	if curTime.Minute()%logCountInterval==0 {
		//每隔5分钟提交一次
		if logtotal,oktotal:= <-logCountTotalChannel;oktotal {
			if curTime.Sub(logtotal.LastTime).Minutes()>1{
				for _, log := range logtotal.MapCount {
					if log.RequestCount > 0 {
						log.LogTime = curTime
						log.AvgTime = (log.TotalTime / float64(log.RequestCount))*1000
						GetLogger().sendLogToELKMQ(log,MyConfigHelper.ConfigCentor().MQLogRouteKeyMonth)
						log.RequestCount = 0
						log.AvgTime = 0.0
						log.TotalTime = 0.0
					}
				}
				logtotal.LastTime=time.Now()
			}
			logCountTotalChannel <- logtotal
		}
	}else{
		//fmt.Println("not submit time")
	}
	//fmt.Println("check and submit MQ over")
}
//endregion

//region 搜索明细日志channel生产入口
func (this *LogHelper)addLogChannel(objLog *RuntimeLogger){
	if logChannel==nil{
		logChannel=make(chan *RuntimeLogger,logChannelSize)
	}
	if len(logChannel)<logChannelSize{
		logChannel <- objLog
	}
}
//endregion

//region 搜素次数日志channel生产入口
func (this *LogHelper)addLogCountChannel(objLog *CountLogger){
	if logCountChannel==nil{
		logCountChannel=make(chan *CountLogger,logCountChannelSize)
	}
	if len(logCountChannel)<logCountChannelSize {
		logCountChannel <- objLog
	}
}
//endregion

//region 添加搜索日志对象到channel
//记录请求参数日志
func (this *LogHelper) LogRequest(indexname string,count int,arrDsl []string,param *pb.SearchCondition,duration float64){
	var islog bool=false
	if len(MyConfigHelper.ConfigCentor().RequestLogSource)>0{
		if MyConfigHelper.ConfigCentor().RequestLogSource[0]==0{
			islog=true
		}else{
			if ObjCommonHelper.CheckSliceContainInt(MyConfigHelper.ConfigCentor().RequestLogSource,int(param.RequestSource)) {
				islog=true
			}
		}
	}
	if islog{
		this.Log("{RequestSource:"+strconv.Itoa(int(param.RequestSource))+",Count:"+strconv.Itoa(count)+"}",indexname,1,arrDsl,nil,nil,duration,int64(count))
	}
}
func (this *LogHelper) Log(msginfo string,indexname string,loglevel int32,arrDsl []string,param *pb.SearchCondition,ex error,duration float64,carcount int64){
	var objLog = new(RuntimeLogger)
	objLog.IndexName="esgrpc"
	objLog.LogLevel=loglevel
	objLog.Exception=ex
	objLog.LogTime=time.Now()
	objLog.Param=param
	objLog.QueryDsl=arrDsl
	objLog.Message=msginfo
	objLog.SysName=indexname
	objLog.ServerIp=MyConfigHelper.ConfigCentor().Server_Host
	objLog.Duration=duration
	objLog.CarCount=carcount
	if MyConfigHelper.ConfigCentor().LogType=="elk"{
		this.addLogChannel(objLog)
	}else if MyConfigHelper.ConfigCentor().LogType=="file"{
		this.WriteFileLog(objLog)
	}
}
//endregion

//region 记录搜索次数到channel
func (this *LogHelper) LogCount(indexname string,requestsource int32,searchtime float64,resultcount int64){
	var objLog = new(CountLogger)
	objLog.SysName=indexname
	objLog.RequestSource=requestsource
	objLog.SearchTime=searchtime
	this.addLogCountChannel(objLog)
}
//endregion

//region 发送日志消息到MQ-->ELK
func (this *LogHelper)sendLogToELKMQ(objLog interface{},routekey string)bool{
	json,_:=json.Marshal(objLog)
	if json!=nil{
		var r bool
		if routekey==""{
			routekey=MyConfigHelper.ConfigCentor().MQLogRouteKey
		}
		r = SendMQMessageWithLogRoutekey(json,routekey)
		//fmt.Println("MQ消息发送完成"+strconv.FormatBool(r)+"|"+string(json))
		if !r{
			//发送日志消息失败，记录文本日志
			this.WriteFileLog(objLog)
		}
		return r
	}
	return false
}
//endregion

//region 记录文本日志
func (this *LogHelper) WriteFileLog(objLog interface{}){
	filename:=this.GetLogFileName()
	objfile, err := os.OpenFile(filename,os.O_RDWR|os.O_CREATE|os.O_APPEND,0666)
	if err!=nil{
		objfile, err = os.Create(filename)
	}
	defer objfile.Close()
	logmsg,err:=json.Marshal(objLog)
	if err!=nil{
		objfile.WriteString("记录文本日志异常：反序列化日志对象失败："+err.Error())
		return
	}
	objfile.Write(logmsg)
	objfile.WriteString("\r\n---------------------------------------------\r\n")

}

func (this *LogHelper) GetLogFileName()string{
	_, err := os.Stat(MyConfigHelper.ConfigCentor().LogPath)
	if err != nil {
		os.MkdirAll(MyConfigHelper.ConfigCentor().LogPath,0777)
	}
	filename:= MyConfigHelper.ConfigCentor().LogPath+time.Now().Format("2006-01-02")+".log"
	return filename
}
//endregion

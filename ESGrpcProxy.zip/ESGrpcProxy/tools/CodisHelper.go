package tools

import (
	"gopkg.in/redis.v5"
	"time"
	"fmt"
	"strconv"
)

type CodisHelper struct{
}

//连接池大小
var redisClientChannelSize int=100
//redis连接池通道
var redisClientChannel chan *redis.Client
var objCodisHelper *CodisHelper
func GetCodisHelper() *CodisHelper{
	if objCodisHelper==nil{
		if MyConfigHelper.ConfigCentor().ES_LogLevel>1 {
			fmt.Println("初始化CodisHelper对象...")
		}
		objCodisHelper=new(CodisHelper)
	}
	if redisClientChannel==nil{
		if MyConfigHelper.ConfigCentor().ES_LogLevel>1 {
			fmt.Println("创建redisClientChannel对象")
		}
		redisClientChannel=make(chan *redis.Client,redisClientChannelSize)
		objCodisHelper.NewClient()
	}
	return objCodisHelper
}

//region 取出一个redis client对象
func (this *CodisHelper) GetClient()*redis.Client{
	if client, ok := <-redisClientChannel; ok {
		if len(redisClientChannel)<3{
			go this.NewClient()
		}
		if MyConfigHelper.ConfigCentor().ES_LogLevel>1 {
			fmt.Println("获取redis.Client对象1")
			fmt.Println("redisClientChannel长度：" + strconv.Itoa(len(redisClientChannel)))
		}
		return client
	}else{
		this.NewClient()
		client,_ = <-redisClientChannel
		if MyConfigHelper.ConfigCentor().ES_LogLevel>1{
			fmt.Println("获取redis.Client对象2")
			fmt.Println("redisClientChannel长度："+strconv.Itoa(len(redisClientChannel)))
		}
		return client
	}
}
//endregion

//region 归还redis client对象
func (this *CodisHelper) RebackClient(client *redis.Client){
	if client!=nil {
		if len(redisClientChannel)>8{
			if MyConfigHelper.ConfigCentor().ES_LogLevel>1 {
				fmt.Println("销毁redis.Client对象")
			}
			client.Close()
		}else{
			redisClientChannel <- client
			if MyConfigHelper.ConfigCentor().ES_LogLevel>1 {
				fmt.Println("归还redis.Client对象")
				fmt.Println("redisClientChannel长度：" + strconv.Itoa(len(redisClientChannel)))
			}
		}
	}
}
//endregion

//region 创建Redis-Client对象并添加到channel中
func (this *CodisHelper) NewClient() {
	for _,addr:=range MyConfigHelper.ConfigCentor().CodisProxyAddr{
		var redisClient *redis.Client
		opt:=new(redis.Options)
		opt.Addr=addr
		opt.DialTimeout=10 * time.Second
		opt.PoolSize=100
		redisClient = redis.NewClient(opt)
		redisClientChannel <- redisClient
		if MyConfigHelper.ConfigCentor().ES_LogLevel>1 {
			fmt.Println("创建redis.Client对象：" + addr)
			fmt.Println("redisClientChannel长度：" + strconv.Itoa(len(redisClientChannel)))
		}
	}
}
//endregion

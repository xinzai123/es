package tools

import (
	"time"
	pb "../grpc"
)
type RuntimeLogger struct {
	IndexName string
	LogTime time.Time
	LogName string
	LogLevel int32
	Message string
	Exception error
	SysName string
	ServerIp string
	ClientIp string
	QueryDsl []string
	Duration float64
	CarCount int64
	Param *pb.SearchCondition
}

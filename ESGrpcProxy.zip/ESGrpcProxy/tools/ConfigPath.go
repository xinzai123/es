package tools

var ConfigFilePath = "D:\\Gitlab\\Search\\ESGRpcServer\\config.ini"
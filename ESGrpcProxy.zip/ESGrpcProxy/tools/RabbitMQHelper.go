package tools

import (
	"github.com/streadway/amqp"
	"time"
	"fmt"
)

var MQConn *amqp.Connection
var MQChannel *amqp.Channel
var MQInitStatus bool
var NQInitTime time.Time

func InitMQConnection(){
	if MQConn==nil || MQChannel==nil || !MQInitStatus{
		var err error
		MQConn, err = amqp.Dial(MyConfigHelper.ConfigCentor().MQConntionString)
		if err!=nil{
			//MQ拨号异常
			fmt.Println("ConnectMQ:dial to rabbitmq error:"+MyConfigHelper.ConfigCentor().MQConntionString+"|"+err.Error())
			NQInitTime=time.Now()
			return
		}
		MQChannel, err = MQConn.Channel()
		if err!=nil{
			fmt.Println("ConnectMQ:create channel error:"+err.Error())
			NQInitTime=time.Now()
			return
		}
		if err := MQChannel.ExchangeDeclare(
			MyConfigHelper.ConfigCentor().MQLogExchange,     // name
			MyConfigHelper.ConfigCentor().MQLogExchangeType, // type
			false,         // durable
			true,        // auto-deleted
			false,        // internal
			false,        // noWait
			nil,          // arguments
		); err != nil {
			fmt.Println("ConnectMQ:declare exchange error:"+MyConfigHelper.ConfigCentor().MQLogExchange+","+MyConfigHelper.ConfigCentor().MQLogExchangeType+"|"+err.Error())
			NQInitTime=time.Now()
			return
		}
		MQInitStatus=true
		NQInitTime=time.Now()
	}
}

//region 发送MQ消息
func SendMQMessageWithLogRoutekey(msginfo []byte,routekey string) bool{
	InitMQConnection()
	err := MQChannel.Publish(
		MyConfigHelper.ConfigCentor().MQLogExchange, // exchange
		routekey,          // routing key
		false,           // mandatory
		false,           // immediate
		amqp.Publishing{
			DeliveryMode:MyConfigHelper.ConfigCentor().MQLogDeliveryMode,
			Body:msginfo,
		})
	if err!=nil{
		//发送消息失败
		fmt.Println("ConnectMQ:publish message error:"+MyConfigHelper.ConfigCentor().MQLogExchange+","+MyConfigHelper.ConfigCentor().MQLogExchangeType+","+string(msginfo)+"|"+err.Error())
		if time.Now().Sub(NQInitTime).Minutes()>1{
			MQInitStatus=false
		}
		return false
	}
	return true
}
//endregion

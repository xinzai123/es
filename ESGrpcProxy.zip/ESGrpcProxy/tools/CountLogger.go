package tools

import "time"

type CountLogger struct {
	RequestSource int32
	ClientIp string
	SysName string
	SearchTime float64
	ResultCount int64
}

type CountLoggerTotalMap struct{
	MapCount map[int32]*CountLoggerTotal
	LastTime time.Time
}

type CountLoggerTotal struct {
	IndexName string
	RequestSource int32
	RequestCount int64
	LogTime time.Time
	ClientIp string
	ServerIp string
	SysName string
	TotalTime float64
	AvgTime float64
	EmptyCount int64
}
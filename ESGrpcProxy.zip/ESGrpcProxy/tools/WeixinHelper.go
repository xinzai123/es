package tools

import (
	"strings"
	"time"
	"net/http"
)



//发送微信消息：收件人在配置文件中设置
func SendWeixinMsg(title string, msginfo string){
	fullmsg:=`{"wx":"wx0a73d57fdec1510c","template":"kugbHMOAu_rUoS_ljsmRMhKUyU_ExCN1moRBIFYpDYc","user":"{{User}}","color":"","url":"",
		"param":[{"Item1":"first","Item2":"{{first}}","Item3":"#FF3300"},{"Item1":"keyword1","Item2":"{{keyword1}}","Item3":"#173177"},
		{"Item1":"keyword2","Item2":"{{keyword2}}","Item3":"#173177"},{"Item1":"remark","Item2":"{{remark}}","Item3":"#173177"}]}`
	for _,user:=range MyConfigHelper.ConfigCentor().WeixinUser{
		temp1:=strings.Replace(fullmsg,"{{User}}",user,-1)
		temp2:=strings.Replace(temp1,"{{first}}",MyConfigHelper.ConfigCentor().SysName,-1)
		temp3:=strings.Replace(temp2,"{{keyword1}}",title,-1)
		temp4:=strings.Replace(temp3,"{{keyword2}}",msginfo,-1)
		temp5:=strings.Replace(temp4,"{{remark}}",time.Now().Format("2006-01-02 15:04:05"),-1)
		//msgtemp:=strings.Replace(strings.Replace(strings.Replace(strings.Replace(strings.Replace(fullmsg,"{{User}}",user,-1),"{{first}}","ES-Proxy状态异常",-1),"{{keyword1}}",title,-1),"{{keyword2}}",msginfo,-1),"{{remark}}",time.Now().Format("2006-01-02 15:04:05"),-1)
		resp, err := http.Post("http://wx.api..cn/SendMsg/new","application/x-www-form-urlencoded",strings.NewReader(temp5))
		if err != nil {
		}else{
			if resp.StatusCode!=200{
			}
		}
	}
}


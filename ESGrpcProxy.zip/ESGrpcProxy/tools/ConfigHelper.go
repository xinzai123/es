package tools

import (
	"goini"
	"strconv"
	"time"
)

var MyConfigHelper=ConfigHelper{IsInit:false}
var objConfig *goini.Config
var LastRefreshConfigTime time.Time=time.Now()

type ConfigHelper struct {
	IsInit bool

	//region ES相关配置
	ES_LogLevel int
	ES_Url string
	ES_Url_V5 string
	SysName string
	WeixinUser []string
	LogPath string
	LogType string
	RequestLogSource []int
	ES_IsNewVersion bool
	ES_IsCopyRequest bool
	ES_CopyRequestSource int
	ES_LocalCacheExpire int
	ES_LocalCacheSize int
	//endregion

	//region Server相关配置
	Server_Host string
	Server_Port string
	Server_RequestTimeout int
	Server_SlowRequestTime float64
	//endregion

	//region Codis相关配置
	CodisKeyPrefix string
	CodisProxyAddr []string
	CodisRecommendTimeout int64
	CodisIsRecommendCache bool
	//endregion

	//region MQ相关配置
	MQConntionString string
	MQLogExchange string
	MQLogExchangeType string
	MQLogRouteKey string
	MQLogRouteKeyMonth string
	MQLogIsDirect bool
	MQLogDeliveryMode uint8
	//endregion

	//region LDS车源规则相关配置
	LDSMarkingvendorSource []int
	LDSMarkingAgencyCity []int32
	LDSMarkingAgencyCustomer []int32
	//屏蔽打标示的非看看车商家车源的渠道ID集合
	LDSMarkflagRequestSource []int32
	//endregion

	//region CPL车源补充相关配置
	//补充CPL车源时的最低车源PV，即只补充前7天车源PV大于此阀值的车源
	CPLCarPvNumber int
	//车源列表页补充CPL车源的阀值，即搜索结果车源量小于此阀值时才需要补充CPL车源
	CPLCarListNumber int
	//补充CPL车源数量阀值，即最多补充不超过此阀值数量的CPL车源
	CPLCarNumber int
	//CPL车源来源客户ID配置
	CPLCustomerIdArray []int32
	//CPL规则启用RequestSource集合（限制展示数量）
	CPLRequestSourceArray []int32
	//CPL规则启用RequestSource集合（完全屏蔽展示）
	CPLRequestSourceForMarking []int32
	//endregion
}

func (this *ConfigHelper) ConfigCentor()(result ConfigHelper){
	if !MyConfigHelper.IsInit{
		this.InitConfigCentor()
	}
	return MyConfigHelper
}

func (this *ConfigHelper) InitConfigCentor(){
	objConfig=goini.SetConfig(ConfigFilePath)
	MyConfigHelper.IsInit=true
	LastRefreshConfigTime=time.Now()
	MyConfigHelper.ES_LogLevel=objConfig.GetValueInt("ES","LogLevel")
	MyConfigHelper.ES_Url=objConfig.GetValue("ES","Url")
	MyConfigHelper.ES_Url_V5=objConfig.GetValue("ES","Url_V5")
	MyConfigHelper.WeixinUser=objConfig.GetValueArray("ES","WeixinUser")
	MyConfigHelper.SysName=objConfig.GetValue("ES","SysName")
	MyConfigHelper.LogPath=objConfig.GetValue("ES","LogPath")
	MyConfigHelper.LogType=objConfig.GetValue("ES","LogType")
	MyConfigHelper.RequestLogSource=objConfig.GetValueIntArray("ES","RequestLogSource")
	MyConfigHelper.ES_IsNewVersion,_=strconv.ParseBool(objConfig.GetValue("ES","IsNewVersion"))
	MyConfigHelper.ES_IsCopyRequest,_=strconv.ParseBool(objConfig.GetValue("ES","IsCopyRequest"))
	MyConfigHelper.ES_CopyRequestSource=objConfig.GetValueInt("ES","CopyRequestSource")
	MyConfigHelper.ES_LocalCacheExpire=objConfig.GetValueInt("ES","LocalCacheExpire")
	MyConfigHelper.ES_LocalCacheSize=objConfig.GetValueInt("ES","LocalCacheSize")



	MyConfigHelper.CodisKeyPrefix=objConfig.GetValue("Codis","KeyPrefix")
	MyConfigHelper.CodisProxyAddr=objConfig.GetValueArray("Codis","ProxyAddr")
	MyConfigHelper.CodisRecommendTimeout=objConfig.GetValueInt64("Codis","RecommendTimeout")
	MyConfigHelper.CodisIsRecommendCache,_=strconv.ParseBool(objConfig.GetValue("Codis","IsRecommendCache"))

	MyConfigHelper.Server_Host=objConfig.GetValue("Server","Host")
	MyConfigHelper.Server_Port=objConfig.GetValue("Server","Port")
	MyConfigHelper.Server_RequestTimeout=objConfig.GetValueInt("Server","RequestTimeout")
	MyConfigHelper.Server_SlowRequestTime=objConfig.GetValueFloat64("Server","SlowRequestTime")

	MyConfigHelper.MQConntionString=objConfig.GetValue("MQ","ConntionString")
	MyConfigHelper.MQLogExchange=objConfig.GetValue("MQ","LogExchange")
	MyConfigHelper.MQLogExchangeType=objConfig.GetValue("MQ","LogExchangeType")
	MyConfigHelper.MQLogRouteKey=objConfig.GetValue("MQ","LogRouteKey")
	MyConfigHelper.MQLogRouteKeyMonth=objConfig.GetValue("MQ","LogRouteKeyMonth")
	MyConfigHelper.MQLogIsDirect,_=strconv.ParseBool(objConfig.GetValue("MQ","LogIsDirect"))
	MyConfigHelper.MQLogDeliveryMode=uint8(objConfig.GetValueInt("MQ","DeliveryMode"))

	MyConfigHelper.LDSMarkingvendorSource=objConfig.GetValueIntArray("LDS","MarkingvendorSource")
	MyConfigHelper.LDSMarkingAgencyCity=objConfig.GetValueInt32Array("LDS","MarkingAgencyCity")
	MyConfigHelper.LDSMarkingAgencyCustomer=objConfig.GetValueInt32Array("LDS","MarkingAgencyCustomer")
	MyConfigHelper.LDSMarkflagRequestSource=objConfig.GetValueInt32Array("LDS","MarkflagRequestSource")

	MyConfigHelper.CPLCarPvNumber=objConfig.GetValueInt("CPL","CarPvNumber")
	MyConfigHelper.CPLCarListNumber=objConfig.GetValueInt("CPL","CarListNumber")
	MyConfigHelper.CPLCarNumber=objConfig.GetValueInt("CPL","CPLCarNumber")
	MyConfigHelper.CPLCustomerIdArray=objConfig.GetValueInt32Array("CPL","CPLCustomerId")
	MyConfigHelper.CPLRequestSourceArray=objConfig.GetValueInt32Array("CPL","CPLRequestSource")
	MyConfigHelper.CPLRequestSourceForMarking=objConfig.GetValueInt32Array("CPL","CPLRequestSourceForMarking")
}

//region 刷新配置文件
func RefreshConfigCentor(){
	for {
		//判断上次加载配置文件的时间
		cutTime := time.Now()
		intervalMinute := cutTime.Sub(LastRefreshConfigTime).Minutes()
		if intervalMinute > 1 {
			MyConfigHelper.InitConfigCentor()
		}else{
			//未达到时间间隔，休眠
			time.Sleep(10*time.Second)
		}
	}
}
//endregion

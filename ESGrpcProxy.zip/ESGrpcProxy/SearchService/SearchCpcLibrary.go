package ESGoServer

/*
功能：基于多标签个性化推荐车源检索的实体定义
使用情况：未启用
 */

/*
[
 {
        "Id": 10324924,
        "SiteId": 5,
        "CarPublishTime": "2016-12-05T14:40:28.47",
        "Guid": "b8682ff6-403d-45cd-be97-1cf7c8241b20"
    }
    ]


var cpc = new CPCEntity
                {
                    AreaId = fromwebsite,
                    DealerId = car.Userid,
                    ClickPrice = price,
                    ClickType = 10,
                    Sort = i + 1,
                    SourceId = fromsource,
                    Id = m.Id
                };
                guid = string.Format("D:CPC:GUID:{0}", guid);
                BitAuto..Utils.Common.RedisHelper.Instance.SET(guid, JsonConvert.SerializeObject(cpc),
                    DateTime.Now.AddHours(2), 0);


 */

type DTORecommendCpcCar struct{
	AreaId		int32
	DealerId	int32
	ClickPrice	float32
	ClickType	int32
	Sort		int
	SourceId	int32
	Id		int32
}

type DTORecommendCarField struct {
	id            int32   `protobuf:"varint,1,opt,name=id" json:"id,omitempty"`
	serialnumber  string  `protobuf:"bytes,2,opt,name=serialnumber" json:"serialnumber,omitempty"`
	Carproviceid      int32   `protobuf:"varint,4,opt,name=carproviceid" json:"carproviceid,omitempty"`
	Carcityid         int32   `protobuf:"varint,5,opt,name=carcityid" json:"carcityid,omitempty"`
	Drivingmileage    int32   `protobuf:"varint,7,opt,name=drivingmileage" json:"drivingmileage,omitempty"`
	Displayprice      float64 `protobuf:"fixed64,17,opt,name=displayprice" json:"displayprice,omitempty"`
	Buycardate        string  `protobuf:"bytes,20,opt,name=buycardate" json:"buycardate,omitempty"`
	picwholepath  string  `protobuf:"bytes,22,opt,name=picwholepath" json:"picwholepath,omitempty"`
	Carprovincename   string  `protobuf:"bytes,33,opt,name=carprovincename" json:"carprovincename,omitempty"`
	Carcityname       string  `protobuf:"bytes,34,opt,name=carcityname" json:"carcityname,omitempty"`
	Userid            int32   `protobuf:"varint,66,opt,name=userid" json:"userid,omitempty"`
	Vendorname        string  `protobuf:"bytes,68,opt,name=vendorname" json:"vendorname,omitempty"`
	Cartitle          string  `protobuf:"bytes,84,opt,name=cartitle" json:"cartitle,omitempty"`
	Score             float64 `protobuf:"fixed64,92,opt,name=score" json:"score,omitempty"`
	Carsource1l	  int32
	Isauthenticated	  int32
	Isactivity	  int32
	Iswarranty	  int32
	//Callnodeviationrate float64
	Iscpc		int32
	//Boostapp	float64
	Guid		string	`广告车源计费标识Guid`
}

type SearchRecommendTag struct{
	Fieldname	string
	Score 		float64
	Fieldvalue	[]SearchRecommendTagItem
}

type SearchRecommendTagItem struct{
	Value		string
	Weight		float64
}
package ESGoServer

import (
	"encoding/json"
	"errors"
	"fmt"
	"gopkg.in/olivere/elastic.v2"
	"reflect"
	"strconv"
	"strings"
	pb "../grpc"
	"../tools"
	"time"
	"gopkg.in/redis.v5"
	"bytes"
	"encoding/base64"
	"github.com/simplejia/lc"
)

/*
功能：搜索过程实现方法
适用版本：1.5.2
 */

type SearchServiceClient struct {
}
var esClient *elastic.Client
var objSearchConfition *SearchConditionLibrary
var objSearchRule SearchRule

//region 【新版本，多组标签】搜索推荐车源入口方法：推荐车源搜索，补充CPC车源：传入SearchRecommendCondition对象
func (this *SearchServiceClient) SearchRecommendCar(param *pb.SearchRecommendCondition)(r *pb.SearchRecommendResult,err error){
	//region 变量定义及初始化
	var objRet = new(pb.SearchRecommendResult)
	var objCarList []*DTORecommendCarField
	var arrTag []SearchRecommendTag
	var isusecpc bool=true	//判断是否对cpc车源进行加分
	var tagdsl bytes.Buffer		//筛选条件拼接
	//endregion

	//region 校验参数&反序列化推荐标签
	if param.PageSize<=0{
		param.PageSize=10
	}
	if param.PageIndex<=0{
		param.PageIndex=1
	}
	if param.SearchCondition!=""{
		err:=json.Unmarshal([]byte(param.SearchCondition), &arrTag)
		if err!=nil{
			tools.GetLogger().Log("推荐车源解析标签异常:"+param.SearchCondition,"recommendcar",4,nil,nil,err,0,-1)
			return objRet,err
		}
		if arrTag==nil || len(arrTag)==0{
			tools.GetLogger().Log("推荐车源标签解析结果为空:"+param.SearchCondition,"recommendcar",4,nil,nil,nil,0,-1)
			return objRet,err
		}

	}
	//endregion

	//region 判断缓存数据
	var codiskey string
	var redisclient *redis.Client
	if tools.MyConfigHelper.ConfigCentor().CodisIsRecommendCache{
		codiskey= tools.MyConfigHelper.ConfigCentor().CodisKeyPrefix+"RecommendCar_"+strconv.Itoa(int(param.PageSize))+"_"+param.SearchCondition
		redisclient= tools.GetCodisHelper().GetClient()
		if redisclient!=nil{
			cmd:=redisclient.Get(codiskey)
			val,err:=cmd.Result()
			tools.GetCodisHelper().RebackClient(redisclient)
			if err==nil && len(val)>0{
				err=json.Unmarshal([]byte(val), objRet)
				if err==nil && objRet!=nil && objRet.Count>0 && len(objRet.CarJson)>0{
					return objRet,nil
				}else{
					tools.GetLogger().Log("推荐车源反序列化缓存结果异常:"+codiskey,"recommendcar",4,nil,nil,err,0,-1)
				}
			}

		}
	}
	//endregion

	//region 拼接查询语句dsl
	arrReturnField:=[]string{"id","serialnumber","carproviceid","carcityid","drivingmileage","displayprice","buycardate","picwholepath","carprovincename","carcityname","userid","vendorname","cartitle","score","iscpc","carsource1l","isauthenticated","isactivity","iswarranty"}
	querytemplate:=`{"from":%d,"size":%d,"fields": ["%s"],"query": {"filtered": {"filter": {"bool":{"must": [{"term": {"carsource1l": 2}},{"term": {"status": 1}}%s]}},"query": {"bool":{"must":[{"function_score": {"functions": [{"script_score": {"script": "recommendscore","params": {"SearchCondition":"%s"},"lang": "native"}}],"score_mode": "sum","boost_mode": "replace","max_boost": 10000}}]}}}}}`

	//region 添加省份城市检索条件
	var tempBuf bytes.Buffer
	if len(param.CarCityIdArray)>0 && param.CarCityIdArray[0]>0{
		tempBuf=objSearchConfition.GetSingleTermFilterDsl_Int32Array("carcityid",param.CarCityIdArray,false)
	}else if len(param.CarProvinceIdArray)>0 && param.CarProvinceIdArray[0]>0{
		tempBuf=objSearchConfition.GetSingleTermFilterDsl_Int32Array("carproviceid",param.CarProvinceIdArray,false)
	}
	tagdsl.Write(tempBuf.Bytes())
	//endregion

	//region 添加推荐标签检索条件
	if len(arrTag)>0{
		tagdsl.WriteString(",{\"bool\": {\"should\": [{}")
		for _,tag:=range arrTag{
			switch strings.ToLower(tag.Fieldname) {
			case "mainbrandid","brandid","carlevelvalue":
				//region 通用规则推荐标签
				for _,val := range tag.Fieldvalue{
					tagdsl.WriteString(",{\"term\": {\"")
					tagdsl.WriteString(tag.Fieldname)
					tagdsl.WriteString("\": ")
					tagdsl.WriteString(val.Value)
					tagdsl.WriteString("}}")
				}
				//endregion
				break
			case "displayprice":
				//region 价格标签
				var arrPrice []string
				for _,val := range tag.Fieldvalue{
					if val.Value==""{continue}
					arrPrice=strings.Split(val.Value,",")
					if len(arrPrice)!=2 {continue}
					tagdsl.WriteString(",{\"range\": {\"")
					tagdsl.WriteString(tag.Fieldname)
					tagdsl.WriteString("\": {")
					if arrPrice[0]!=""{
						tagdsl.WriteString("\"gte\":")
						tagdsl.WriteString(arrPrice[0])
					}
					if arrPrice[1]!=""{
						if arrPrice[0]!=""{tagdsl.WriteString(",")}
						tagdsl.WriteString("\"lte\":")
						tagdsl.WriteString(arrPrice[1])
					}
					tagdsl.WriteString("}}}")
				}
				//endregion
				break
			case "iscpc":
				//region 判断是否启用精准车源
				if tag.Score<=0{
					//CPC车源不加分
					isusecpc=false
				}
				//endregion
				break
			}
		}
		tagdsl.WriteString("]}}")
	}
	//endregion

	//生成最终查询条件
	querydsl:=fmt.Sprintf(querytemplate,(param.PageIndex-1)*param.PageSize,param.PageSize,strings.Join(arrReturnField,"\",\""),tagdsl.String(),base64.StdEncoding.EncodeToString([]byte(param.SearchCondition)))
	//endregion

	//region 搜索车源(普通车源&精准车源，按命中标签数量和精准推广状态评分)
	ret,err:=this.SearchEsByQuerystring(querydsl, "", "car",arrReturnField)
	if ret.Count>0 && len(ret.CarList)>0{
		var tempCpcCar *DTORecommendCpcCar
		for i,carinfo := range ret.CarList{
			//拼接车源到搜索结果对象
			tempCar:=this.ConvertRecommendCar(carinfo)
			//region 生成Guid并将id和guid的映射关系写入codis缓存
			if isusecpc && carinfo.Iscpc==1{
				guid := tools.GetGuidHelper().NewGuid()
				tempCpcCar=new(DTORecommendCpcCar)
				tempCpcCar.AreaId=param.RequestSource
				tempCpcCar.SourceId=param.RequestSource
				tempCpcCar.ClickPrice=1.0
				tempCpcCar.ClickType=10
				tempCpcCar.DealerId=carinfo.Userid
				tempCpcCar.Sort=i+1
				tempCpcCar.Id=carinfo.id
				tempCar.Guid = guid
				redisclient = tools.GetCodisHelper().GetClient()
				if redisclient!=nil{
					key := "D:CPC:GUID:"+guid
					curcarinfo, _ :=json.Marshal(tempCpcCar)
					err := redisclient.Set(key, string(curcarinfo),time.Duration(2)*time.Hour).Err()
					if err!=nil{
						//保存缓存异常，报警
						tools.GetLogger().Log("保存推荐车源Guid缓存数据异常:"+key, "recommendcar", 4, nil, nil,err,0,-1)
					}
					tools.GetCodisHelper().RebackClient(redisclient)
				}else{
					tools.GetLogger().Log("保存推荐车源Guid缓存数据失败，获取RedisClient失败", "recommendcar", 4, nil, nil,err,0,-1)
				}
			}else if !isusecpc && carinfo.Iscpc==1{
				//不启动CPC车源的情况下，将车源IsCPC属性强制清除
				carinfo.Iscpc=0
			}
			//endregion
			objCarList=append(objCarList,tempCar)
		}
	}
	objRet.Count=int64(len(objCarList))
	carjson,_:=json.Marshal(objCarList)
	objRet.CarJson=string(carjson)
	if param.IsQueryDsl>0{
		objRet.QueryDsl=querydsl
	}
	//endregion

	//region 更新缓存数据
	if tools.MyConfigHelper.ConfigCentor().CodisIsRecommendCache{
		val,err:=json.Marshal(objRet)
		if err==nil && len(val)>0{
			redisclient= tools.GetCodisHelper().GetClient()
			if redisclient!=nil{
				err:=redisclient.Set(codiskey,val,time.Duration(tools.MyConfigHelper.ConfigCentor().CodisRecommendTimeout)*time.Second).Err()
				if err!=nil{
					//保存缓存异常，报警
					tools.GetLogger().Log("推荐车源保存缓存异常:"+codiskey,"recommendcar",4,nil,nil,err,0,-1)
				}
				tools.GetCodisHelper().RebackClient(redisclient)
			}
		}else{
			//反序列化推荐车源结果异常
			tools.GetLogger().Log("推荐车源序列化异常:"+codiskey,"recommendcar",4,nil,nil,err,0,-1)
		}
	}
	//endregion

	return objRet,nil
}

func (this *SearchServiceClient) ConvertRecommendCar(sourcecar *pb.DTOCarInfoIndexField)*DTORecommendCarField{
	var recommendcar =new(DTORecommendCarField)
	recommendcar.id=sourcecar.id
	recommendcar.Buycardate=sourcecar.Buycardate
	recommendcar.Carcityid=sourcecar.Carcityid
	recommendcar.Carcityname=sourcecar.Carcityname
	recommendcar.Carproviceid=sourcecar.Carproviceid
	recommendcar.Carprovincename=sourcecar.Carprovincename
	recommendcar.Cartitle=sourcecar.Cartitle
	recommendcar.Displayprice=sourcecar.Displayprice
	recommendcar.Drivingmileage=sourcecar.Drivingmileage
	recommendcar.picwholepath=sourcecar.picwholepath
	recommendcar.serialnumber=sourcecar.serialnumber
	recommendcar.Userid=sourcecar.Userid
	recommendcar.Vendorname=sourcecar.Vendorname
	recommendcar.Score=sourcecar.Score
	//recommendcar.Callnodeviationrate=sourcecar.Callnodeviationrate
	recommendcar.Iscpc=sourcecar.Iscpc
	recommendcar.Carsource1l=sourcecar.Carsource1L
	recommendcar.Isactivity=sourcecar.Isactivity
	recommendcar.Isauthenticated=sourcecar.Isauthenticated
	recommendcar.Iswarranty=sourcecar.Iswarranty
	//recommendcar.Boostapp=sourcecar.Boostapp
	return recommendcar
}
//endregion

//region  搜索ES集群入口方法：车源搜索：传入SearchCondition对象--Local Cache版本
func (this *SearchServiceClient) SearchEsWithLocalCache(param *pb.SearchCondition,indexname string) (r *pb.SearchResult, err error) {
	//region 捕获搜索异常信息
	//defer func(){
	//	if err:=recover();err!=nil{
	//		fmt.Println("SearchEsWithLocalCache Exception:"+err.(error).Error())
	//		tools.GetLogger().Log("搜索异常_SearchEsWithLocalCache",indexname,4,nil,param,err.(error),0,-1)
	//		r.Count=-1
	//	}
	//}()
	//endregion

	//开始计时
	startTime:=time.Now()

	//region 判断缓存
	var cachekey string
	var iscache bool=false
	var iscachedata bool=false
	iscache,cachekey=objSearchRule.CheckIsLocalCache(param,indexname)
	if iscache && cachekey!=""{
		v, ok := lc.Get(cachekey)
		if ok && v!=nil {
			r=v.(*pb.SearchResult)
			iscachedata=true
		}
	}
	//endregion

	//region 无缓存数据，搜索ES，并更新local cache
	if r==nil{
		r,err=this.SearchEs(param,indexname)
		if err==nil{
			//region 更新本地缓存
			if iscache && cachekey!=""{
				//单位：秒
				lc.Set(cachekey,r,time.Duration(tools.MyConfigHelper.ConfigCentor().ES_LocalCacheExpire)*time.Second)
			}
			//endregion
		}
	}
	//endregion

	//region 检索完成，结束计时，记录搜索次数及性能日志
	endTime:=time.Now()
	querytime:=endTime.Sub(startTime).Seconds()
	tools.GetLogger().LogCount(indexname,param.RequestSource,querytime,r.Count)
	//&& querytime>tools.MyConfigHelper.ConfigCentor().Server_SlowRequestTime
	if tools.MyConfigHelper.ConfigCentor().ES_LogLevel>0 {
		tools.GetLogger().LogRequest(indexname,int(r.Count),[]string{fmt.Sprintf("{iscache:%t,iscachedata:%t,cachekey:%s}",iscache, iscachedata,cachekey)+r.RequestParametersLog},param,querytime)
	}
	//
	//if tools.MyConfigHelper.ConfigCentor().ES_LogLevel>0 {
	//	tools.GetLogger().Log(fmt.Sprintf("{iscache:%t,iscachedata:%t,cachekey:%s}",iscache, iscachedata,cachekey), indexname, 0, nil, param, nil, querytime, r.Count)
	//}

	return r, err
	//endregion
}
//endregion

//region  搜索ES集群入口方法：车源搜索：传入SearchCondition对象
func (this *SearchServiceClient) SearchEs(param *pb.SearchCondition,indexname string) (r *pb.SearchResult, err error) {
	var arrQuery []string
	var ret bool
	var msg string
	var tempResult *pb.SearchResult
	//region 捕获搜索异常信息
	//defer func(){
	//	if err:=recover();err!=nil{
	//		fmt.Println("SearchEs Exception:"+err.(error).Error())
	//		tools.GetLogger().Log("搜索异常_SearchEs",indexname,4,arrQuery,param,err.(error),0,-1)
	//		r.Count=-1
	//	}
	//}()
	//endregion

	//region 对检索参数进行预处理
	if objSearchConfition == nil {
		objSearchConfition = new(SearchConditionLibrary)
	}
	if tools.MyConfigHelper.ConfigCentor().ES_LogLevel>1{
		fmt.Println("校验参数...开始...")
	}
	param, ret, msg = objSearchRule.CheckParameters(param,indexname)
	if tools.MyConfigHelper.ConfigCentor().ES_LogLevel>1{
		fmt.Println("校验参数...完成...ret:"+strconv.FormatBool(ret)+",errormsg:"+msg)
	}
	if !ret {
		err = errors.New(msg)
		return r, err
	}
	//LDS相关规则实施 2017-03-29
	param = objSearchRule.CheckCarLdsRules(param,indexname)
	//endregion

	//region 解析筛选条件，获取qsl查询语句
	if tools.MyConfigHelper.ConfigCentor().ES_LogLevel>1{
		fmt.Println("构建查询语句...开始...")
	}
	arrQuery=objSearchConfition.GetSearchCarDSL(param)
	if tools.MyConfigHelper.ConfigCentor().ES_LogLevel>1{
		fmt.Println("构建查询语句...完成，搜索次数："+strconv.Itoa(len(arrQuery)))
	}
	//endregion

	//region 执行搜索并合并返回结果
	r=new(pb.SearchResult)
	//计算起始位置
	startNum := int(param.StartNum) + int((param.PageIndex - 1) * param.PageSize)
	topNum := int(param.PageSize)
	for i,queryString := range arrQuery{
		tempResult=nil
		//region 计算起始位置和获取记录条数
		if i>0 && startNum>0{
			//取翻页数据
			if len(r.CarList)>0{
				//已经取到有效数据
				startNum=0
				topNum = topNum - len(r.CarList)
			}else{
				//尚未取到有效数据
				startNum = startNum-int(r.Count)
			}
		}
		//endregion

		//请求ES，获取json结果
		queryString=fmt.Sprintf(queryString,startNum,topNum)
		arrQuery[i]=queryString
		//region 处理SearchType
		searchtype := ""
		if param.IsCountSearch {
			searchtype = "count"
		}else{
			//判断当前步骤，如果非第1步，判断车源是否已取够，如果足够，后续查询只查询数量，不返回具体车源
			if i>0 && len(r.CarList)==int(param.PageSize){
				//非第一步且车源数量已取够
				searchtype = "count"
			}
		}
		//endregion
		if tools.MyConfigHelper.ConfigCentor().ES_LogLevel>1{
			fmt.Println("第"+strconv.Itoa(i+1)+"步检索：search_type="+searchtype+"|"+queryString)
		}

		if tempResult==nil{
			//基于连接池搜索ES集群
			fmt.Println(queryString)
			esjson, err := this.RequestESByConnectionPool(queryString, searchtype, indexname)
			if err!=nil{
				errmsg:=fmt.Sprintf("SearchEs Error:[%d:CommonFlag=%d,SortBoostFlag=%d,RequestSource=%d,searchtype=%s]%s",(i + 1),param.CommonFlag,param.SortBoostFlag,param.RequestSource,searchtype,queryString)
				tools.GetLogger().Log(errmsg,indexname,4,arrQuery,param,err.(error),0,-1)
				r.Count=-1
				return r,err
			}

			//解析json结果
			tempResult = this.esResultHandler(esjson, param)
		}
		//分布检索处理
		if i==0{
			//第一步检索结果
			r = tempResult
		}else{
			//region 非第1步检索结果，合并搜索结果
			if tempResult!=nil && tempResult.Count>0{
				r.Count=r.Count+tempResult.Count
				if tempResult.CarList!=nil && len(tempResult.CarList)>0{
					//合并搜索结果中的车源列表
					if r.CarList==nil || len(r.CarList)==0{
						r.CarList=tempResult.CarList
					}else{
						endindex:=len(tempResult.CarList)
						if len(tempResult.CarList)>(int(param.PageSize)-len(r.CarList)){
							endindex=int(param.PageSize)-len(r.CarList)
						}
						r.CarList=append(r.CarList,tempResult.CarList[:endindex]...)
					}
				}
			}
			//endregion
		}
		if param.RequestParametersLog=="get"{
			if i==0{
				r.RequestParametersLog=fmt.Sprintf("[%d:CommonFlag=%d,SortBoostFlag=%d,RequestSource=%d,searchtype=%s]%s",(i + 1),param.CommonFlag,param.SortBoostFlag,param.RequestSource,searchtype,queryString)
			}else{
				r.RequestParametersLog+=fmt.Sprintf("[%d:CommonFlag=%d,SortBoostFlag=%d,RequestSource=%d,searchtype=%s]%s",(i + 1),param.CommonFlag,param.SortBoostFlag,param.RequestSource,searchtype,queryString)
			}
		}
	}
	//endregion

	return r,nil
}

//endregion

//region  搜索ES集群入口方法：车源搜索：传入SearchCondition对象-CPL车源补充策略
func (this *SearchServiceClient) SearchEs_CPL(param *pb.SearchCondition,indexname string) (r *pb.SearchResult, err error) {
	var arrQuery []string
	//region 捕获搜索异常信息
	defer func(){
		if err:=recover();err!=nil{
			fmt.Println("SearchEs_CPL Exception:"+err.(error).Error())
			tools.GetLogger().Log("搜索异常_SearchEs_CPL",indexname,4,arrQuery,param,err.(error),0,-1)
		}
	}()
	//endregion

	//开始计时
	startTime:=time.Now()
	//region 对检索参数进行预处理
	param, ret, msg := objSearchRule.CheckParameters_CPL(param,indexname)
	if !ret {
		err = errors.New(msg)
		return r, err
	}
	//LDS相关规则实施 2017-03-29
	param = objSearchRule.CheckCarLdsRules(param,indexname)
	//endregion

	//排除瓜子经销商所属客户编号
	sourceNoCrmCustomerIdArray:=param.NoCrmCustomerIdArray
	param.NoCrmCustomerIdArray=append(param.NoCrmCustomerIdArray,tools.MyConfigHelper.CPLCustomerIdArray...)

	//region 解析筛选条件，获取qsl查询语句
	arrQuery=objSearchConfition.GetSearchCarDSL(param)
	//endregion

	//region 搜索常规车源索引
	r=new(pb.SearchResult)
	var tempResult *pb.SearchResult
	//计算起始位置
	startNum := param.StartNum + (param.PageIndex - 1) * param.PageSize
	topNum := param.PageSize
	queryString:=fmt.Sprintf(arrQuery[0],startNum,topNum)
	//fmt.Println(queryString)
	//基于连接池搜索ES集群
	esjson, err := this.RequestESByConnectionPool(queryString, "", indexname)
	if err!=nil{
		tools.GetLogger().Log("搜索请求_CPL异常",indexname,4,arrQuery,param,err.(error),0,-1)
		return r,err
	}
	if param.RequestParametersLog=="get"{
		r.RequestParametersLog+="[1:CommonFlag="+strconv.Itoa(int(param.CommonFlag)) +",SortBoostFlag="+strconv.Itoa(int(param.SortBoostFlag))+",RequestSource="+strconv.Itoa(int(param.RequestSource))+",]"+queryString
	}
	//解析json结果
	tempResult = this.esResultHandler(esjson, param)
	r = tempResult


	//判断结果车源量是否达到列表页最低车源数量阀值
	if int(tempResult.Count)<tools.MyConfigHelper.ConfigCentor().CPLCarListNumber{
		//region 补充CPL车源
		startNum=param.StartNum + (param.PageIndex - 1) * param.PageSize-int32(r.Count)
		if startNum<0{
			startNum=0
		}
		topNum=param.PageSize-int32(len(r.CarList))
		if topNum>int32(tools.MyConfigHelper.ConfigCentor().CPLCarNumber){
			topNum=int32(tools.MyConfigHelper.ConfigCentor().CPLCarNumber)
		}
		param.NoCrmCustomerIdArray=sourceNoCrmCustomerIdArray
		param.CrmCustomerIdArray=tools.MyConfigHelper.ConfigCentor().CPLCustomerIdArray
		param.CarPvMin=int32(tools.MyConfigHelper.ConfigCentor().CPLCarPvNumber)
		arrQuery=objSearchConfition.GetSearchCarDSL(param)
		queryString=fmt.Sprintf(arrQuery[0],startNum,topNum)

		//基于连接池搜索ES集群
		esjson, _ = this.RequestESByConnectionPool(queryString, "", objSearchRule.GetCPLCarIndexName(param))
		if param.RequestParametersLog=="get"{
			r.RequestParametersLog+="[2:CommonFlag="+strconv.Itoa(int(param.CommonFlag)) +",SortBoostFlag="+strconv.Itoa(int(param.SortBoostFlag))+",RequestSource="+strconv.Itoa(int(param.RequestSource))+",]"+queryString
		}
		//解析json结果
		tempResult = this.esResultHandler(esjson, param)

		if tools.MyConfigHelper.ConfigCentor().ES_LogLevel>1{
			usecount:=int64(tools.MyConfigHelper.ConfigCentor().CPLCarListNumber-int(r.Count))
			if usecount>tempResult.Count{
				usecount=tempResult.Count
			}
			tools.GetLogger().Log(fmt.Sprintf("{\"NeedCPL\":1,\"NeedCount\":%d,\"CPLCount\":%d}",(tools.MyConfigHelper.ConfigCentor().CPLCarListNumber-int(r.Count)),tempResult.Count),indexname,int32(tempResult.Count),arrQuery,param,nil,0,usecount)
		}

		if tempResult.Count>0{
			//计算需要合并的数据量
			//合并检索结果，考虑排序机制
			count2:=tempResult.Count
			if count2>int64(tools.MyConfigHelper.ConfigCentor().CPLCarNumber){
				count2=int64(tools.MyConfigHelper.ConfigCentor().CPLCarNumber)
			}
			if (r.Count+count2)>int64(tools.MyConfigHelper.ConfigCentor().CPLCarListNumber){
				r.Count=int64(tools.MyConfigHelper.ConfigCentor().CPLCarListNumber)
			}else{
				r.Count+=count2
			}
			if len(param.OrderByFieldArray)>0 && len(param.OrderByFieldArray)==len(param.OrderByIsDESCArray){
				r.CarList=objSearchTool.MergeCarListWithSortField(r.CarList,tempResult.CarList,param)
			}else{
				//默认排序
				r.CarList=append(r.CarList,tempResult.CarList...)
			}
		}
		//endregion
	}
	//endregion

	//region 结束计时，记录搜索次数及性能日志
	endTime:=time.Now()
	querytime:=endTime.Sub(startTime).Seconds()
	if tools.MyConfigHelper.ConfigCentor().ES_LogLevel>1 {
		tools.GetLogger().Log(fmt.Sprintf("CPL搜索完成:%d",r.Count),indexname,1,arrQuery,param,nil,querytime,r.Count)
	}
	tools.GetLogger().LogCount(indexname,param.RequestSource,querytime,r.Count)
	if tools.MyConfigHelper.ConfigCentor().ES_LogLevel>0 && querytime>tools.MyConfigHelper.ConfigCentor().Server_SlowRequestTime{
		tools.GetLogger().LogRequest(indexname,int(r.Count),arrQuery,param,querytime)
	}
	//endregion
	return r, err
}

//endregion

//region  搜索ES集群入口方法：车源搜索：传入查询语句字符串
func (this *SearchServiceClient) SearchEsByQuerystring(queryString string,searchtype string,indexname string,arrfield []string) (r *pb.SearchResult, err error) {
	var arrQuery = []string{queryString}
	//region 捕获搜索异常信息
	defer func(){
		if err:=recover();err!=nil{
			fmt.Println("SearchEsByQuerystring Exception"+err.(error).Error())
			tools.GetLogger().Log("SearchEsByQuerystring Exception:"+queryString,indexname,4,arrQuery,nil,err.(error),0,-1)
		}
	}()
	//endregion

	//开始计时
	startTime:=time.Now()
	//解析筛选条件，获取qsl查询语句
	if objSearchConfition == nil {
		objSearchConfition = new(SearchConditionLibrary)
	}
	//region 执行搜索并返回结果
	r=new(pb.SearchResult)
	//基于连接池搜索ES集群
	esjson, _ := this.RequestESByConnectionPool(queryString, searchtype, indexname)
	//解析json结果
	var param =new(pb.SearchCondition)
	param.ReturnFieldArray=arrfield
	r = this.esResultHandler(esjson, param)
	if param.RequestParametersLog=="get"{
		r.RequestParametersLog+="CommonFlag="+strconv.Itoa(int(param.CommonFlag)) +",SortBoostFlag="+strconv.Itoa(int(param.SortBoostFlag))+",RequestSource="+strconv.Itoa(int(param.RequestSource))+","+searchtype+"]"+queryString
	}
	//endregion

	//结束计时，记录搜索次数及性能日志
	endTime:=time.Now()
	querytime:=endTime.Sub(startTime).Seconds()
	tools.GetLogger().LogCount("car",param.RequestSource,querytime,r.Count)
	if tools.MyConfigHelper.ConfigCentor().ES_LogLevel>0 && querytime>tools.MyConfigHelper.ConfigCentor().Server_SlowRequestTime{
		tools.GetLogger().LogRequest(indexname,int(r.Count),arrQuery,param,querytime)
	}
	return r, err
}

//endregion

//region  搜索ES集群入口方法，问答搜索：传入SearchQuestionCondition对象---Question
func (this *SearchServiceClient) SearchEsQuestion(param *pb.SearchQuestionCondition) (r *pb.SearchResult, err error) {
	//开始计时
	startTime:=time.Now()

	//解析筛选条件，获取dsl查询语句
	if objSearchConfition == nil {
		objSearchConfition = new(SearchConditionLibrary)
	}
	param, ret, msg := objSearchRule.CheckParametersQuestion(param)
	if !ret {
		err = errors.New(msg)
		return r, err
	}
	queryString := objSearchConfition.GetSearchQuestionDSL(param)
	//请求ES，获取json结果
	searchtype := ""
	if param.IsCountSearch {
		searchtype = "count"
	}

	//基于连接池搜索ES集群
	esjson, _ := this.RequestESByConnectionPool(queryString, searchtype,"question")
	//解析json结果
	r = this.esResultHandlerQuestion(esjson, param)
	if param.RequestParametersLog=="get"{
		r.RequestParametersLog=queryString
	}

	endTime:=time.Now()
	querytime:=endTime.Sub(startTime).Seconds()
	if tools.MyConfigHelper.ConfigCentor().ES_LogLevel>0{
		tools.GetLogger().Log("SearchEsQuestion", "question", 0, []string{queryString}, nil, nil, querytime, r.Count)
	}

	return r, err
}

//endregion


//region 基于连接池机制请求ES集群
func (this *SearchServiceClient) RequestESByConnectionPool(data string, searchtype string,indexname string) (result *elastic.Response, err error) {
	arrQuery:=[]string{data}
	if esClient == nil || !esClient.IsRunning() {
		var arrUrl=strings.Split(tools.MyConfigHelper.ConfigCentor().ES_Url,",")
		esClient, err = elastic.NewClient(elastic.SetURL(arrUrl...))
		if err!=nil{
			tools.GetLogger().Log("create es client error",indexname,4,arrQuery,nil,err,0,-1)
		}
		if tools.MyConfigHelper.ConfigCentor().Server_RequestTimeout>0{
			esClient.SetHttpTimeout(time.Millisecond*time.Duration(tools.MyConfigHelper.ConfigCentor().Server_RequestTimeout))
		}
	}
	searchpath := "/" + indexname + "/_search"
	if searchtype != "" {
		searchpath = searchpath + "?search_type=" + searchtype
	}
	ret, err := esClient.PerformRequest("post", searchpath, nil, data)
	if err != nil {
		tools.GetLogger().Log("request error",indexname,4,arrQuery,nil,err,0,-1)
		return ret, err
	}

	return ret, err
}
//endregion

//region 车源搜索：将ES返回的json结果转换为SearchResult对象
func (this *SearchServiceClient) esResultHandler(response *elastic.Response, param *pb.SearchCondition) (result *pb.SearchResult) {
	var obj elastic.SearchResult
	var objResult = new(pb.SearchResult)
	if response == nil || response.StatusCode != 200 {
		return objResult
	}
	err := json.Unmarshal(response.Body, &obj)
	if err != nil {
		fmt.Println("将ES返回的json结果转换为SearchResult对象-json.Unmarshal异常："+err.Error())
	}
	arrCount := len(obj.Hits.Hits)
	if arrCount == 0 {
		arrCount = 1
	}
	var arrModel []*pb.DTOCarInfoIndexField

	//region 读取Facets切面聚合结果  废弃，升级为aggs
	if len(obj.Facets)>0 && len(param.AggrFieldList)>0{
		var arrFacet []*pb.AggrFieldResult
		for i:=0;i<len(param.AggrFieldList);i++{
			fieldname:=param.AggrFieldList[i].FieldName
			var tempField = new(pb.AggrFieldResult)
			var arrTermResult []*pb.AggrFieldResultItem
			tempField.FieldName=fieldname
			tempField.AggrType=param.AggrFieldList[i].AggregationType
			switch param.AggrFieldList[i].AggregationType {
			case 1,3:
				//term facets
				for j:=0;j<len(obj.Facets[fieldname].Terms);j++{
					var tempFieldTerm = new(pb.AggrFieldResultItem)
					objtemp:=obj.Facets[fieldname].Terms[j]
					switch reflect.TypeOf(objtemp.Term).Kind() {
					case reflect.Int32:
						tempFieldTerm.TermName=strconv.Itoa(int(objtemp.Term.(int32)))
						tempFieldTerm.Count=int32(objtemp.Count)
					case reflect.Int64:
						tempFieldTerm.TermName=strconv.Itoa(int(objtemp.Term.(int64)))
						tempFieldTerm.Count=int32(objtemp.Count)
					case reflect.Float64:
						tempFieldTerm.TermName=strconv.FormatFloat(objtemp.Term.(float64),'f',2,64)
						tempFieldTerm.Count=int32(objtemp.Count)
					default:
						tempFieldTerm.TermName=objtemp.Term.(string)
						tempFieldTerm.Count=int32(objtemp.Count)
					}
					//tempFieldTerm.Min=objtemp.Min
					//tempFieldTerm.Max=objtemp.Max
					//tempFieldTerm.Avg=objtemp.Mean
					//tempFieldTerm.Sum=objtemp.Total
					arrTermResult=append(arrTermResult,tempFieldTerm)
				}
				break
			case 2:
				//Range facets
				for j:=1;j<=len(obj.Facets[fieldname].Ranges);j++{
					var tempFieldTerm = new(pb.AggrFieldResultItem)
					objtemp:=obj.Facets[fieldname].Ranges[j-1]
					tempFieldTerm.TermName=strconv.Itoa(j)
					tempFieldTerm.Count=int32(objtemp.Count)
					arrTermResult=append(arrTermResult,tempFieldTerm)
				}
				break

			}
			tempField.AggrValue=arrTermResult
			arrFacet=append(arrFacet,tempField)
		}
		objResult.Facet=arrFacet
	}
	//endregion

	//region 读取aggregations聚合结果
	if len(obj.Aggregations)>0 && len(param.AggrFieldList)>0{
		var arrAggr []*pb.AggrFieldResult
		for i:=0;i<len(param.AggrFieldList);i++{
			fieldname:=param.AggrFieldList[i].FieldName
			var tempField = new(pb.AggrFieldResult)
			var arrTermResult []*pb.AggrFieldResultItem
			tempField.FieldName=fieldname
			tempField.AggrType=param.AggrFieldList[i].AggregationType
			switch param.AggrFieldList[i].AggregationType {
			case 1:
				//region 读取 term 字段
				tempTerm, found := obj.Aggregations.Terms(fieldname)
				if found {
					for j := 0; j < len(tempTerm.Buckets); j++ {
						var tempFieldTerm = new(pb.AggrFieldResultItem)
						objtemp := tempTerm.Buckets[j]
						tempFieldTerm.Count = int32(objtemp.DocCount)
						switch reflect.TypeOf(objtemp.Key).Kind() {
						case reflect.Int32:
							tempFieldTerm.TermName = strconv.Itoa(int(objtemp.Key.(int32)))
						case reflect.Int64:
							tempFieldTerm.TermName = strconv.Itoa(int(objtemp.Key.(int64)))
						case reflect.Float64:
							tempFieldTerm.TermName = strconv.FormatFloat(objtemp.Key.(float64), 'f', 2, 64)
						default:
							tempFieldTerm.TermName = objtemp.Key.(string)
						}
						for k:=0;k<len(param.AggrFieldList[i].SubKeyFieldArray);k++{
							tempAvg,_:=objtemp.Aggregations[param.AggrFieldList[i].SubKeyFieldArray[k]]
							data,_:=json.Marshal(tempAvg)
							if tempFieldTerm.SubAggr==nil{
								tempFieldTerm.SubAggr=make(map[string]string)
							}
							tempFieldTerm.SubAggr[param.AggrFieldList[i].SubKeyFieldArray[k]]=string(data)
						}
						arrTermResult = append(arrTermResult, tempFieldTerm)
					}
				}
				//endregion
				break
			case 2:
				//region 读取 Range 字段
				tempRange, found := obj.Aggregations.Range(fieldname)
				if found{
					for j:=0;j<len(tempRange.Buckets);j++{
						var tempFieldTerm = new(pb.AggrFieldResultItem)
						objtemp := tempRange.Buckets[j]
						tempFieldTerm.TermName=objtemp.Key
						tempFieldTerm.Count=int32(objtemp.DocCount)

						for k:=0;k<len(param.AggrFieldList[i].SubKeyFieldArray);k++{
							tempAvg,_:=objtemp.Aggregations[param.AggrFieldList[i].SubKeyFieldArray[k]]
							data,_:=json.Marshal(tempAvg)
							if tempFieldTerm.SubAggr==nil{
								tempFieldTerm.SubAggr=make(map[string]string)
							}
							tempFieldTerm.SubAggr[param.AggrFieldList[i].SubKeyFieldArray[k]]=string(data)
						}
						arrTermResult = append(arrTermResult, tempFieldTerm)
					}
				}
				//endregion
				break
			}
			tempField.AggrValue=arrTermResult
			arrAggr=append(arrAggr,tempField)
		}
		objResult.Facet=arrAggr
	}
	//endregion

	//region 读取Hits数据集合
	if len(obj.Hits.Hits) > 0 {
		//region 读取返回数据集合
		var objHit elastic.SearchHit

		for i := 0; i < len(obj.Hits.Hits); i++ {
			objHit = *obj.Hits.Hits[i]
			//fmt.Println("开始读取第"+strconv.Itoa(i+1)+"条")
			//fmt.Println(objHit.Source)
			var tempModel pb.DTOCarInfoIndexField
			for j := 0; j < len(param.ReturnFieldArray); j++ {
				fieldName := strings.ToLower(param.ReturnFieldArray[j])
				var fieldTitle string
				if fieldName=="carsource1l"{
					fieldTitle = "Carsource1L"
				}else if fieldName=="b2bprice"{
					fieldTitle = "B2Bprice"
				}else if fieldName=="c2bprice"{
					fieldTitle = "C2Bprice"
				}else if fieldName=="isb2b"{
					fieldTitle = "Isb2B"
				}else if fieldName=="car_referprice"{
					fieldTitle = "Carreferprice"
				} else{
					fieldTitle = strings.Title(fieldName)
				}
				//处理score返回字段
				if fieldName=="score"{
					if objHit.Score!=nil{
						tempModel, err = this.initCarModelProperty_Float(tempModel, fieldTitle, *objHit.Score)
					}
					continue
				}else if objHit.Fields[fieldName] == nil {
					continue
				}
				//处理其他返回字段
				fieldtype := reflect.TypeOf(objHit.Fields[fieldName].([]interface{})[0]).Kind()
				switch fieldtype {
				case reflect.Int32:
					tempvalue := objHit.Fields[fieldName].([]interface{})[0].(int64)
					tempModel, err = this.initCarModelProperty_Int64(tempModel, fieldTitle, tempvalue)
					break
				case reflect.Int64:
					tempvalue := objHit.Fields[fieldName].([]interface{})[0].(int64)
					tempModel, err = this.initCarModelProperty_Int64(tempModel, fieldTitle, tempvalue)
					break
				case reflect.Float64:
					tempvalue := objHit.Fields[fieldName].([]interface{})[0].(float64)
					tempModel, err = this.initCarModelProperty_Float(tempModel, fieldTitle, tempvalue)
					break
				default:
					tempvalue := objHit.Fields[fieldName].([]interface{})[0].(string)
					tempModel, err = this.initCarModelProperty_String(tempModel, fieldTitle, tempvalue)
					break
				}

			}
			arrModel=append(arrModel,&tempModel)
		}
		objResult.CarList = arrModel
		//endregion
	}
	//endregion

	//取出记录数
	objResult.Count = obj.TotalHits()
	return objResult
}

//endregion

//region 问答搜索：将ES返回的json结果转换为SearchResult对象---Question
func (this *SearchServiceClient) esResultHandlerQuestion(response *elastic.Response, param *pb.SearchQuestionCondition) (result *pb.SearchResult) {
	var obj elastic.SearchResult
	var objResult = new(pb.SearchResult)
	if response == nil || response.StatusCode != 200 {
		return objResult
	}
	err := json.Unmarshal(response.Body, &obj)
	if err != nil {
		fmt.Println(err)
	}
	arrCount := len(obj.Hits.Hits)
	if arrCount == 0 {
		arrCount = 1
	}
	var arrModel []*pb.DTOQuestionIndexField

	if len(obj.Hits.Hits) > 0 {
		//region 读取返回数据集合
		var objHit elastic.SearchHit
		//取出记录数
		objResult.Count = obj.Hits.TotalHits
		for i := 0; i < len(obj.Hits.Hits); i++ {
			objHit = *obj.Hits.Hits[i]
			//fmt.Println("开始读取第"+strconv.Itoa(i+1)+"条")
			var tempModel pb.DTOQuestionIndexField
			for j := 0; j < len(param.ReturnFieldArray); j++ {
				fieldName := param.ReturnFieldArray[j]
				fieldTitle := strings.Title(fieldName)
				if objHit.Highlight!=nil{
					if objHit.Highlight[fieldName]!=nil{
						tempvalue := objHit.Highlight[fieldName][0]
						tempModel = this.initQuestionModelProperty_String(tempModel, fieldTitle, tempvalue,param)
						continue
					}
				}
				if objHit.Fields[fieldName] == nil {
					continue
				}
				fieldtype := reflect.TypeOf(objHit.Fields[fieldName].([]interface{})[0]).Kind()
				if tools.MyConfigHelper.ConfigCentor().ES_LogLevel>1{
					//fmt.Println(fieldName+"/"+fieldtype.String())
				}
				switch fieldtype {
				case reflect.Int32:
					tempvalue := objHit.Fields[fieldName].([]interface{})[0].(int64)
					tempModel = this.initQuestionModelProperty_Int64(tempModel, fieldTitle, tempvalue)
					break
				case reflect.Int64:
					tempvalue := objHit.Fields[fieldName].([]interface{})[0].(int64)
					tempModel = this.initQuestionModelProperty_Int64(tempModel, fieldTitle, tempvalue)
					break
				case reflect.Float64:
					tempvalue := objHit.Fields[fieldName].([]interface{})[0].(float64)
					tempModel = this.initQuestionModelProperty_Float(tempModel, fieldTitle, tempvalue)
					break
				default:
					tempvalue := objHit.Fields[fieldName].([]interface{})[0].(string)
					tempModel = this.initQuestionModelProperty_String(tempModel, fieldTitle, tempvalue, param)
					break
				}

			}
			arrModel=append(arrModel,&tempModel)
			//fmt.Println(objHit.Highlight)
		}
		objResult.QuestionList = arrModel
		//endregion
	}
	return objResult
}

//endregion


//region 解析ES Json结果：处理string属性
func (this *SearchServiceClient) initCarModelProperty_String(model pb.DTOCarInfoIndexField, fieldTitle string, fieldvalue string) (r pb.DTOCarInfoIndexField, err error) {
	tempModelProperty := reflect.ValueOf(&model).Elem()
	fieldtype1 := tempModelProperty.FieldByName(fieldTitle).Kind()
	switch fieldtype1 {
	case reflect.Int32:
		tempvalue, err := strconv.ParseInt(fieldvalue, 10, 64)
		if err == nil {
			tempModelProperty.FieldByName(fieldTitle).SetInt(tempvalue)
		}
		break
	case reflect.Int64:
		tempvalue, err := strconv.ParseInt(fieldvalue, 10, 64)
		if err == nil {
			tempModelProperty.FieldByName(fieldTitle).SetInt(tempvalue)
		}
		break
	case reflect.Float64:
		tempvalue, err := strconv.ParseFloat(fieldvalue, 2)
		if err == nil {
			tempModelProperty.FieldByName(fieldTitle).SetFloat(tempvalue)
		}
		break
	default:
		tempModelProperty.FieldByName(fieldTitle).SetString(fieldvalue)
		break
	}
	err = nil
	return model, err
}
//endregion

//region 解析ES Json结果：处理int64属性

func (this *SearchServiceClient) initCarModelProperty_Int64(model pb.DTOCarInfoIndexField, fieldTitle string, fieldvalue int64) (r pb.DTOCarInfoIndexField, err error) {
	tempModelProperty := reflect.ValueOf(&model).Elem()
	fieldtype1 := tempModelProperty.FieldByName(fieldTitle).Kind()
	switch fieldtype1 {
	case reflect.Int32:
		tempModelProperty.FieldByName(fieldTitle).SetInt(fieldvalue)
		break
	case reflect.Int64:
		tempModelProperty.FieldByName(fieldTitle).SetInt(fieldvalue)
		break
	case reflect.Float64:
		tempModelProperty.FieldByName(fieldTitle).SetFloat(float64(fieldvalue))
		break
	default:
		tempModelProperty.FieldByName(fieldTitle).SetString(string(fieldvalue))
		break
	}
	err = nil
	return model, err
}

//endregion

//region 解析ES Json结果：处理float64属性
func (this *SearchServiceClient) initCarModelProperty_Float(model pb.DTOCarInfoIndexField, fieldTitle string, fieldvalue float64) (r pb.DTOCarInfoIndexField, err error) {
	tempModelProperty := reflect.ValueOf(&model).Elem()
	fieldtype1 := tempModelProperty.FieldByName(fieldTitle).Kind()
	switch fieldtype1 {
	case reflect.Int32:
		tempModelProperty.FieldByName(fieldTitle).SetInt(int64(fieldvalue))
		break
	case reflect.Int64:
		tempModelProperty.FieldByName(fieldTitle).SetInt(int64(fieldvalue))
		break
	case reflect.Float64:
		tempModelProperty.FieldByName(fieldTitle).SetFloat(float64(fieldvalue))
		break
	case reflect.Invalid:
		//非法
		fmt.Print("异常结果列数据："+fieldTitle+"  ")
		fmt.Print(fieldtype1)
		fmt.Println(fieldvalue)
		break
	default:
		if fieldvalue>0{
			tempModelProperty.FieldByName(fieldTitle).SetString(strconv.FormatFloat(fieldvalue, 'e', 2, 64))
		}else{
			tempModelProperty.FieldByName(fieldTitle).SetString("")
		}

		break
	}
	err = nil
	return model, err
}
//endregion


//region 解析ES Json结果：处理int64属性

func (this *SearchServiceClient) initQuestionModelProperty_Int64(model pb.DTOQuestionIndexField, fieldTitle string, fieldvalue int64) (r pb.DTOQuestionIndexField) {
	tempModelProperty := reflect.ValueOf(&model).Elem()
	fieldtype1 := tempModelProperty.FieldByName(fieldTitle).Kind()
	switch fieldtype1 {
	case reflect.Int32:
		tempModelProperty.FieldByName(fieldTitle).SetInt(fieldvalue)
		break
	case reflect.Int64:
		tempModelProperty.FieldByName(fieldTitle).SetInt(fieldvalue)
		break
	case reflect.Float64:
		tempModelProperty.FieldByName(fieldTitle).SetFloat(float64(fieldvalue))
		break
	default:
		tempModelProperty.FieldByName(fieldTitle).SetString(string(fieldvalue))
		break
	}
	return model
}

//endregion

//region 解析ES Json结果：处理float64属性
func (this *SearchServiceClient) initQuestionModelProperty_Float(model pb.DTOQuestionIndexField, fieldTitle string, fieldvalue float64) (r pb.DTOQuestionIndexField) {
	tempModelProperty := reflect.ValueOf(&model).Elem()
	fieldtype1 := tempModelProperty.FieldByName(fieldTitle).Kind()
	switch fieldtype1 {
	case reflect.Int32:
		tempModelProperty.FieldByName(fieldTitle).SetInt(int64(fieldvalue))
		break
	case reflect.Int64:
		tempModelProperty.FieldByName(fieldTitle).SetInt(int64(fieldvalue))
		break
	case reflect.Float64:
		tempModelProperty.FieldByName(fieldTitle).SetFloat(float64(fieldvalue))
		break
	case reflect.Invalid:
		//非法
		fmt.Print("Invalid Data:"+fieldTitle)
		fmt.Print(fieldtype1)
		fmt.Print(fieldvalue)
		break
	default:
		if fieldvalue>0{
			tempModelProperty.FieldByName(fieldTitle).SetString(strconv.FormatFloat(fieldvalue, 'e', 2, 64))
		}else{
			tempModelProperty.FieldByName(fieldTitle).SetString("")
		}

		break
	}
	return model
}
//endregion

//region 解析ES Json结果：处理string属性
func (this *SearchServiceClient) initQuestionModelProperty_String(model pb.DTOQuestionIndexField, fieldTitle string, fieldvalue string,param *pb.SearchQuestionCondition) (r pb.DTOQuestionIndexField) {
	tempModelProperty := reflect.ValueOf(&model).Elem()
	fieldtype1 := tempModelProperty.FieldByName(fieldTitle).Kind()
	switch fieldtype1 {
	case reflect.Int32:
		tempvalue, err := strconv.ParseInt(fieldvalue, 10, 64)
		if err == nil {
			tempModelProperty.FieldByName(fieldTitle).SetInt(tempvalue)
		}
		break
	case reflect.Int64:
		tempvalue, err := strconv.ParseInt(fieldvalue, 10, 64)
		if err == nil {
			tempModelProperty.FieldByName(fieldTitle).SetInt(tempvalue)
		}
		break
	case reflect.Float64:
		tempvalue, err := strconv.ParseFloat(fieldvalue, 2)
		if err == nil {
			tempModelProperty.FieldByName(fieldTitle).SetFloat(tempvalue)
		}
		break
	default:
		if !param.IsHightLight && len(param.CutLengthFieldNameArray)>0 && len(param.CutLengthFieldNameArray)==len(param.CutLengthFieldValueArray){
			//处理返回字段值截取
			for i,field:= range param.CutLengthFieldNameArray {
				if strings.ToLower(fieldTitle)==field{
					//截取指定长度
					cutlen:=param.CutLengthFieldValueArray[i]
					if len(strings.Trim(strings.Trim(fieldvalue,"<em>"),"</em>"))>int(cutlen){
						//初步截取
						temp1:=fieldvalue[0:cutlen]
						//考虑高亮标签占位符的情况
						cutlen=cutlen+int32(strings.Count(temp1,"<em>")*4)
						cutlen=cutlen+int32(strings.Count(temp1,"</em>")*5)
						//重新截取最终结果
						fieldvalue=fieldvalue[0:cutlen]
					}
				}
			}
		}
		tempModelProperty.FieldByName(fieldTitle).SetString(fieldvalue)
		break
	}
	return model
}
//endregion

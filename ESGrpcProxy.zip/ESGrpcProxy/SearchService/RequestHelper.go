package ESGoServer

import (
	"time"
	pb "../grpc"
	"../tools"
	"fmt"
)

type RequestHelper struct {
	InitStatus bool
}

var MyRequestHelper *RequestHelper
//车源搜索条件通道
var requestChannelSize int = 100000
var requestChannel =make(chan *pb.SearchCondition,requestChannelSize)

//region 接收请求channel消费入口
func ConsumeRequestChannel(){
	var objSearchService = new(SearchServiceClient_V5)
	var objSearchRule = new(SearchRule)
	//defer close(requestChannel)
	var loopindex int32=0
	startTime:=time.Now()
	for{
		//region 捕获搜索异常信息
		defer func(){
			if err:=recover();err!=nil{
				fmt.Println("ConsumeRequestChannel Exception"+err.(error).Error())
				tools.GetLogger().Log("copyrequest exception:","car_copyrequest",4,nil,nil,err.(error),0,-1)
			}
		}()
		//endregion

		if requestChannel==nil || len(requestChannel)==0{
			//fmt.Println("sleep--copy channel is nil")
			time.Sleep(30*time.Second)
			continue
		}
		if req, ok := <-requestChannel; ok {
			if loopindex<100{
				loopindex++
				fmt.Println(fmt.Sprintf("ignore copy request,loopindex=%d",loopindex))
				continue
			}
			fmt.Println("begin copy request")
			fmt.Println(req)
			loopindex=0
			//开始计时
			startTime=time.Now()
			//发起请求
			indexname:=objSearchRule.GetIndexName(req)
			fmt.Println(indexname)
			req.RequestParametersLog="get"
			ret,err:=objSearchService.SearchEs(req,indexname)
			endTime:=time.Now()
			querytime:=endTime.Sub(startTime).Seconds()
			fmt.Println("finish copy request")
			if err!=nil{
				fmt.Println("error copy request")
				tools.GetLogger().Log("copyrequest error:",indexname,4,[]string{ret.RequestParametersLog},req,err,querytime,-1)
			}
			tools.GetLogger().Log("copyrequest",indexname,req.RequestSource,[]string{ret.RequestParametersLog},req,err,querytime,ret.Count)

			continue
		}
		time.Sleep(1*time.Second)
	}
}
//endregion


//region 接收请求channel生产入口
func (this *RequestHelper)AddRequestChannel(param *pb.SearchCondition){
	if requestChannel==nil{
		requestChannel=make(chan *pb.SearchCondition,requestChannelSize)
	}
	requestChannel <- param
	//if len(requestChannel)<requestChannelSize{
	//	requestChannel <- param
	//}
}
//endregion


package ESGoServer

import (
	"bytes"
	"strconv"
	"strings"
	pb "../grpc"
	"time"
	"fmt"
)

/*
主要功能：构建Elasticsearch查询语句（适用ES版本：5.4.1）
 */

type SearchConditionLibrary_V5 struct {
}

//region 拼接问答查询DSL参数
func (this *SearchConditionLibrary_V5) GetSearchQuestionDSL(param *pb.SearchQuestionCondition) (esqsl string) {
	//region 1. 拼接返回字段字符串
	var bufField bytes.Buffer
	bufField.WriteString(",\"fields\": [")
	if param.ReturnFieldArray != nil {
		for i := 0; i < len(param.ReturnFieldArray); i++ {
			if i > 0 {
				bufField.WriteString(",")
			}
			bufField.WriteString("\"")
			bufField.WriteString(strings.ToLower(param.ReturnFieldArray[i]))
			bufField.WriteString("\"")
		}
	}
	bufField.WriteString("]")
	//endregion

	//region 2 拼接filter查询条件
	var bufFilterAndNot bytes.Buffer
	var tempBuf bytes.Buffer
	bufFilterAndNot.WriteString("\"bool\":{\"must\": [{}")

	//包含问题ID数组
	if param.QoIdArray != nil && len(param.QoIdArray) > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32Array("qoid", param.QoIdArray, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
	}
	//排除问题ID数组检索
	if param.NoQoIdArray != nil && len(param.NoQoIdArray) > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32Array("qoid", param.NoQoIdArray, true)
		bufFilterAndNot.Write(tempBuf.Bytes())
	}
	//问题解决状态检索
	if param.IsSolveArray != nil && len(param.IsSolveArray) > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32Array("issolve", param.IsSolveArray, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
	}
	//主品牌ID数组检索
	if param.MainBrandIdArray != nil && len(param.MainBrandIdArray) > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32Array("masterbrandid", param.MainBrandIdArray, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
	}
	//车系ID数组检索
	if param.BrandIdArray != nil && len(param.BrandIdArray) > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32Array("brandid", param.BrandIdArray, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
	}
	//地区ID数组检索
	if param.AreaIdArray != nil && len(param.AreaIdArray) > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32Array("areaid", param.AreaIdArray, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
	}
	//省份ID数组检索
	if param.ProvinceIdArray != nil && len(param.ProvinceIdArray) > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32Array("pvcid", param.ProvinceIdArray, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
	}
	//城市ID数组检索
	if param.CityIdArray != nil && len(param.CityIdArray) > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32Array("cityid", param.CityIdArray, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
	}
	//最大回复次数检索
	if param.MaxReplyCount > 0 {
		tempBuf = this.GetSingleRangeFilterDsl("replycount","", strconv.Itoa(int(param.MaxReplyCount)) ,3)
		bufFilterAndNot.Write(tempBuf.Bytes())
	}
	//最小回复次数检索
	if param.MinReplyCount > 0 {
		tempBuf = this.GetSingleRangeFilterDsl("replycount", strconv.Itoa(int(param.MinReplyCount)) ,"",3)
		bufFilterAndNot.Write(tempBuf.Bytes())
	}
	//最大浏览次数检索
	if param.MaxViewCount > 0 {
		tempBuf = this.GetSingleRangeFilterDsl("viewcount","", strconv.Itoa(int(param.MaxViewCount)) ,3)
		bufFilterAndNot.Write(tempBuf.Bytes())
	}
	//最小浏览次数检索
	if param.MinViewCount > 0 {
		tempBuf = this.GetSingleRangeFilterDsl("viewcount", strconv.Itoa(int(param.MinViewCount)) ,"",3)
		bufFilterAndNot.Write(tempBuf.Bytes())
	}

	//2.1.5 And区域收尾
	bufFilterAndNot.WriteString("]}")

	//2.3 拼接全量filter查询条件
	var bufFilter bytes.Buffer
	bufFilter.WriteString("\"should\": {")
	bufFilter.Write(bufFilterAndNot.Bytes())
	bufFilter.WriteString("}")
	//endregion

	//region 3. 拼接关键词查询条件
	var bufQuery bytes.Buffer
	isHaveQuery := false
	bufQuery.WriteString(",\"query\": {\"bool\":{\"must\":[")
	//关键词检索
	if param.KeyWord != "" {
		if isHaveQuery{
			bufQuery.WriteString(",")
		}
		isHaveQuery = true
		tempBuf = this.GetKeywordQueryDsl_MultiMatchQuery(param.KeyWord,"\"title^10\",\"fullinfo\"")
		bufQuery.Write(tempBuf.Bytes())
	}
	//标题检索
	if param.Title != "" {
		if isHaveQuery{
			bufQuery.WriteString(",")
		}
		isHaveQuery = true
		tempBuf = this.GetKeywordQueryDsl_MultiMatchQuery(param.Title,"\"title\"")
		bufQuery.Write(tempBuf.Bytes())
	}
	//问题描述检索
	if param.Body != "" {
		if isHaveQuery{
			bufQuery.WriteString(",")
		}
		isHaveQuery = true
		tempBuf = this.GetKeywordQueryDsl_MultiMatchQuery(param.Body,"\"body\"")
		bufQuery.Write(tempBuf.Bytes())
	}
	//最佳答案检索
	if param.ReplyBody != "" {
		if isHaveQuery{
			bufQuery.WriteString(",")
		}
		isHaveQuery = true
		tempBuf = this.GetKeywordQueryDsl_MultiMatchQuery(param.ReplyBody,"\"replybody\"")
		bufQuery.Write(tempBuf.Bytes())
	}
	//标签检索
	if param.TagsArray != nil && len(param.TagsArray) > 0 {
		if isHaveQuery{
			bufQuery.WriteString(",")
		}
		isHaveQuery = true
		tempBuf = this.GetSingleQueryStringDsl_StringArray("tags", param.TagsArray)
		bufQuery.Write(tempBuf.Bytes())
	}
	//问题分类检索
	if param.CategoriesArray != nil && len(param.CategoriesArray) > 0 {
		if isHaveQuery{
			bufQuery.WriteString(",")
		}
		isHaveQuery = true
		tempBuf = this.GetSingleQueryStringDsl_StringArray("categories", param.CategoriesArray)
		bufQuery.Write(tempBuf.Bytes())
	}
	//问题分类分组检索
	if param.CategoriesGroupArray != nil && len(param.CategoriesGroupArray) > 0 {
		if isHaveQuery{
			bufQuery.WriteString(",")
		}
		isHaveQuery = true
		tempBuf = this.GetSingleQueryStringDsl_StringArray("categroup", param.CategoriesGroupArray)
		bufQuery.Write(tempBuf.Bytes())
	}
	bufQuery.WriteString("]}}")
	//endregion

	//region 4. 聚合检索
	var bufAggr bytes.Buffer
	if param.AggrFieldList != nil && len(param.AggrFieldList) > 0 {
		bufAggr.WriteString(",\"facets\" : {")
		for i := 0; i < len(param.AggrFieldList); i++ {
			tempBuf = this.GetAggregationDsl(param.AggrFieldList[i])
			if i > 0 {
				bufAggr.WriteString(",")
			}
			bufAggr.Write(tempBuf.Bytes())
		}
		bufAggr.WriteString("}")
	}
	//endregion

	//region 5. 拼接排序语句
	var bufSort bytes.Buffer
	bufSort = this.GetSortQueryDsl(param.OrderByFieldArray,param.OrderByIsDESCArray)
	//endregion

	//region 6. 拼接最终查询语句DSL
	var bufTotalResult bytes.Buffer
	bufTotalResult.WriteString("{")
	bufTotalResult.WriteString("\"from\":")
	startNum := int((param.PageIndex - 1) * param.PageSize)
	if startNum == 0 {
		bufTotalResult.WriteString("0")
	} else {
		bufTotalResult.WriteString(strconv.Itoa(startNum))
	}
	bufTotalResult.WriteString(",\"size\":")
	bufTotalResult.WriteString(strconv.Itoa(int(param.PageSize)))
	bufTotalResult.Write(bufField.Bytes())
	bufTotalResult.WriteString(",")
	bufTotalResult.WriteString("\"query\": {\"bool\": {")
	if bufFilter.Bytes() != nil {
		bufTotalResult.Write(bufFilter.Bytes())
	}
	if bufQuery.Bytes() != nil && isHaveQuery {
		bufTotalResult.Write(bufQuery.Bytes())
	}
	bufTotalResult.WriteString("}}")
	//添加高亮语句
	if param.IsHightLight && len(param.HightLightFieldArray)>0{
		tempBuf = this.GetKeywordHighlightDsl(param.HightLightFieldArray)
		bufTotalResult.Write(tempBuf.Bytes())
	}
	if bufAggr.Bytes() != nil {
		bufTotalResult.Write(bufAggr.Bytes())
	}
	if bufSort.Bytes() != nil {
		bufTotalResult.WriteString(",")
		bufTotalResult.Write(bufSort.Bytes())
	}
	bufTotalResult.WriteString("}")
	//endregion

	return bufTotalResult.String()
}
//endregion

//region 拼接车源查询DSL参数
func (this *SearchConditionLibrary_V5) GetSearchCarDSL(param *pb.SearchCondition) (arrDsl []string) {
	//region 1. 拼接返回字段字符串
	var bufField bytes.Buffer
	var bufFieldDistance bytes.Buffer
	bufField.WriteString(",\"_source\": [")
	if param.ReturnFieldArray != nil {
		for i := 0; i < len(param.ReturnFieldArray); i++ {
			if !objSearchRule.CheckCarReturnFieldIsValid(param,param.ReturnFieldArray[i]){
				//无效返回字段，跳过
				continue
			}
			if param.ReturnFieldArray[i]!="distance"{
				if i > 0 {
					bufField.WriteString(",")
				}
				bufField.WriteString("\"")
				bufField.WriteString(strings.ToLower(param.ReturnFieldArray[i]))
				bufField.WriteString("\"")
			}
		}
	}
	bufField.WriteString("]")
	//endregion

	//2 拼接filter查询条件--And区域
	var arrFilter []bytes.Buffer
	var bufFilterAndNot bytes.Buffer
	var tempBuf bytes.Buffer
	bufFilterAndNot.WriteString("\"bool\":{\"must\": [{}")

	//region 2.1.1 车源相关查询条件
	//region 关键词查询条件
	var bufQuery bytes.Buffer
	if param.KeyWord != "" {
		tempBuf = this.GetKeywordQueryDsl_MultiMatchQuery(param.KeyWord,"\"cartitle^1000\",\"cartitleinfo^500\",\"cartitlefullinfo^100\"")
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 包含车源ID数组
	if param.IdArray != nil && len(param.IdArray) > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32Array("id", param.IdArray, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 站点ID数组【废弃】
	//if param.SiteId != nil && len(param.SiteId) > 0 {
	//	tempBuf = this.GetSingleTermFilterDsl_Int32Array("siteid", param.SiteId, false)
	//	bufFilterAndNot.Write(tempBuf.Bytes())
	//	tempBuf.Reset()
	//}
	//endregion
	//region 排除车源ID数组
	if param.NoIdArray != nil && len(param.NoIdArray) > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32Array("id", param.NoIdArray, true)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 是否厂商认证车
	if param.IsAuthenticated > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32("isauthenticated", param.IsAuthenticated, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 是否可跨区，即是否可售外地
	if param.Source > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32("source", param.Source, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 车源编号数组
	if param.SerialNumberArray != nil && len(param.SerialNumberArray) > 0 {
		tempBuf = this.GetSingleTermFilterDsl_StringArray("serialnumber", param.SerialNumberArray)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 颜色数组
	if param.ColorArray != nil && len(param.ColorArray) > 0 {
		var arrColor []string
		for i := 0; i < len(param.ColorArray); i++ {
			arrColor = append(arrColor, objSearchTool.GetStandardColor(param.ColorArray[i]))
		}
		tempBuf = this.GetSingleTermFilterDsl_StringArray("color", arrColor)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 车辆来源：个人、商家
	if param.CarSource1L > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32("carsource1l", param.CarSource1L, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 是否有图：1为有图
	if param.PictureCount > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32("picturecount", param.PictureCount, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 排除城市ID数组
	if param.NoCityIdArray != nil && len(param.NoCityIdArray) > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32Array("carcityid", param.NoCityIdArray, true)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 价格区间
	if param.PriceHighArray != nil && len(param.PriceHighArray) > 0 && param.PriceLowerArray != nil && len(param.PriceLowerArray) > 0 && len(param.PriceLowerArray) == len(param.PriceHighArray) {
		tempBuf = this.GetSingleRangeFilterDsl_FloatArray("displayprice", param.PriceLowerArray, param.PriceHighArray, 3)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 厂商指导价区间
	if param.CPriceHighArray != nil && len(param.CPriceHighArray) > 0 && param.CPriceLowerArray != nil && len(param.CPriceLowerArray) > 0 && len(param.CPriceLowerArray) == len(param.CPriceHighArray) {
		tempBuf = this.GetSingleRangeFilterDsl_FloatArray("car_referprice", param.CPriceLowerArray, param.CPriceHighArray, 3)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region B2B串车价格区间
	if param.B2BPriceHighArray != nil && len(param.B2BPriceHighArray) > 0 && param.B2BPriceLowerArray != nil && len(param.B2BPriceLowerArray) > 0 && len(param.B2BPriceLowerArray) == len(param.B2BPriceHighArray) {
		tempBuf = this.GetSingleRangeFilterDsl_FloatArray("b2bprice", param.B2BPriceLowerArray, param.B2BPriceHighArray, 3)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 车龄区间
	if param.CarAgeLowerArray != nil && len(param.CarAgeLowerArray) > 0 && param.CarAgeHighArray != nil && len(param.CarAgeHighArray) > 0 && len(param.CarAgeLowerArray) == len(param.CarAgeHighArray) {
		var arrLower, arrHigh []string
		for i := 0; i < len(param.CarAgeHighArray); i++ {
			var agehigh, agelower int32
			agehigh = param.CarAgeHighArray[i]
			agelower = param.CarAgeLowerArray[i]
			if agehigh > 100 {
				agehigh = 100
			}
			if agehigh < 0 {
				agehigh = 0
			}
			if agelower > 100 {
				agelower = 100
			}
			if agelower < 0 {
				agelower = 0
			}
			var low, high string
			if agehigh == 0 {
				low = ""
			} else {
				low = time.Now().AddDate(int(agehigh*-1), 0, 0).Format("\"2006-01") + "-01T00:00:00\""
			}
			if agelower == 0 {
				high = ""
			} else {
				high = time.Now().AddDate(int(agelower*-1), 0, 0).Format("\"2006-01") + "-01T00:00:00\""
			}
			arrLower = append(arrLower, low)
			arrHigh = append(arrHigh, high)
		}
		tempBuf = this.GetSingleRangeFilterDsl_StringArray("buycardate", arrLower, arrHigh, 3)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 排气量自定义区间
	if param.ExhaustLevelHighArray != nil && len(param.ExhaustLevelHighArray) > 0 && param.ExhaustLevelLowerArray != nil && len(param.ExhaustLevelLowerArray) > 0 && len(param.ExhaustLevelLowerArray) == len(param.ExhaustLevelHighArray) {
		tempBuf = this.GetSingleRangeFilterDsl_FloatArray("exhaustvalue", param.ExhaustLevelLowerArray, param.ExhaustLevelHighArray, 3)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 排气量枚举值
	if param.ExhaustLevelArray != nil && len(param.ExhaustLevelArray) > 0 {
		var arrLower, arrHigh []float64
		for i := 0; i < len(param.ExhaustLevelArray); i++ {
			switch param.ExhaustLevelArray[i] {
			case 1:
				arrLower = append(arrLower, 0)
				arrHigh = append(arrHigh, 1.0)
				break
			case 2:
				arrLower = append(arrLower, 1.1)
				arrHigh = append(arrHigh, 1.5)
				break
			case 3:
				arrLower = append(arrLower, 1.6)
				arrHigh = append(arrHigh, 2.0)
				break
			case 4:
				arrLower = append(arrLower, 2.1)
				arrHigh = append(arrHigh, 3.0)
				break
			case 5:
				arrLower = append(arrLower, 3.1)
				arrHigh = append(arrHigh, 100)
				break
			default:
				arrLower = append(arrLower, 0)
				arrHigh = append(arrHigh, 0)
				break
			}
		}
		tempBuf = this.GetSingleRangeFilterDsl_FloatArray("exhaustvalue", arrLower, arrHigh, 3)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 行驶里程区间
	if param.DrivingMileageHighArray != nil && len(param.DrivingMileageHighArray) > 0 && param.DrivingMileageLowerArray != nil && len(param.DrivingMileageLowerArray) > 0 && len(param.DrivingMileageLowerArray) == len(param.DrivingMileageHighArray) {
		var arrLower, arrHigh []int32
		for i := 0; i < len(param.DrivingMileageHighArray); i++ {
			arrLower = append(arrLower, param.DrivingMileageLowerArray[i]*10000)
			arrHigh = append(arrHigh, param.DrivingMileageHighArray[i]*10000)
		}
		tempBuf = this.GetSingleRangeFilterDsl_IntArray("drivingmileage", arrLower, arrHigh, 3)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 国别数组
	if param.CountryArray != nil && len(param.CountryArray) > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32Array("countryvalue", param.CountryArray, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 上级厂商ID
	if param.SuperiorId > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32("superiorid", param.SuperiorId, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 品牌属性数组
	if param.BrandAttrArray != nil && len(param.BrandAttrArray) > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32Array("brandattr", param.BrandAttrArray, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 车辆来源
	if param.UserType > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32("usertype", param.UserType, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 审核状态
	if param.IsNeglect > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32("isneglect", param.IsNeglect, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 是否首图合格
	if param.IsFirstPicTrue > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32("firstpictrue", param.IsFirstPicTrue, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 是否商家推荐车源
	if param.IsDealerRecommend > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32("isdealerrecommend", param.IsDealerRecommend, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 车源来源类型
	if param.CarSourceTypeArray != nil && len(param.CarSourceTypeArray) > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32Array("cartype", param.CarSourceTypeArray, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 车型年款数组
	if param.CarYearArray != nil && len(param.CarYearArray) > 0 {
		tempBuf = this.GetSingleTermFilterDsl_StringArray("caryear", param.CarYearArray)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 车辆配置数组
	if param.CarTypeConfig != nil && len(param.CarTypeConfig) > 0 {
		var arrField []string
		var arrValue = []int32{1}
		for i := 0; i < len(param.CarTypeConfig); i++ {
			if param.CarTypeConfig[i] > 0 {
				arrField = append(arrField, "ctconfig_"+strconv.Itoa(i+1))
			}
		}
		for i := 0; i < len(arrField); i++ {
			tempBuf = this.GetSingleTermFilterDsl_Int32Array(arrField[i], arrValue, false)
			bufFilterAndNot.Write(tempBuf.Bytes())
		}
		tempBuf.Reset()
	}
	//endregion
	//region 是否豪华车源
	if param.IsRecommendGL > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32("isrecommendgl", param.IsRecommendGL, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 是否保障车
	if param.IsWarranty > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32("iswarranty", param.IsWarranty, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 保障服务类型
	if param.WarrantyTypeArray != nil && len(param.WarrantyTypeArray) > 0 {
		var arrField []string
		var arrValue = []int32{1}
		for i := 0; i < len(param.WarrantyTypeArray); i++ {
			if param.WarrantyTypeArray[i] > 0 {
				arrField = append(arrField, "warrantytypes_"+strconv.Itoa(i+1))
			}
		}
		for i := 0; i < len(arrField); i++ {
			tempBuf = this.GetSingleTermFilterDsl_Int32Array(arrField[i], arrValue, false)
			bufFilterAndNot.Write(tempBuf.Bytes())
		}
		tempBuf.Reset()
	}
	//endregion
	//region 是否置顶车源
	if param.IsTop > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32("istop", param.IsTop, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 是否参加特定活动车源
	if param.IsActivity > 0 {
		if param.IsActivity==100{
			tempBuf = this.GetSingleRangeFilterDsl("isactivity", "1" ,"", 3)
			bufFilterAndNot.WriteString(",")
			bufFilterAndNot.Write(tempBuf.Bytes())
			tempBuf.Reset()
		}else{
			tempBuf = this.GetSingleTermFilterDsl_Int32("isactivity", param.IsActivity, false)
			bufFilterAndNot.Write(tempBuf.Bytes())
			tempBuf.Reset()
		}
	}
	//endregion
	//region 是否帮买车源
	if param.IsBangmai > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32("isbangmai", param.IsBangmai, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 是否帮买车app车源
	if param.IsBangmaiche > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32("isbangmaiche", param.IsBangmaiche, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 否显示维保记录
	if param.IsShowMr > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32("isshowmr", param.IsShowMr, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 是否有json车检报告
	if param.IsB2B > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32("isb2b", param.IsB2B, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 是否B2B串车车源
	if param.IsCheckReportJson > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32("ischeckreportjson", param.IsCheckReportJson, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 用户ID数组
	if param.UserIdArray != nil && len(param.UserIdArray) > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32Array("userid", param.UserIdArray, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 排除UserID数组
	if param.NoUserIdArray != nil && len(param.NoUserIdArray) > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32Array("userid", param.NoUserIdArray, true)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 客户编号数组
	if param.CrmCustomerIdArray != nil && len(param.CrmCustomerIdArray) > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32Array("crmcustomerid", param.CrmCustomerIdArray, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region CPC车源投放城市
	if param.AdCity>0{
		tempBuf = this.GetSingleTermFilterDsl_Int32("cityids", param.AdCity, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region CPC车源投放筛选条件 2017-02-09
	if param.AdCondition==1{
		//默认列表页检索，只筛选adconditions包含0的车源
		tempBuf = this.GetSingleTermFilterDsl_Int32("adconditions", 0, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 车源优惠/超值系数区间查询 2017-02-13
	if param.CarBenefitRateHigh >0 && param.CarBenefitRateLower >= 0 {
		lowvalue:=""
		if param.CarBenefitRateLower>0{
			lowvalue=strconv.FormatFloat(param.CarBenefitRateLower, 'f', 2, 64)
		}
		tempBuf.WriteString(",")
		temp1:=this.GetSingleRangeFilterDsl("carbenefitrate", lowvalue ,strconv.FormatFloat(param.CarBenefitRateHigh, 'f', 2, 64), 3)
		tempBuf.Write(temp1.Bytes())
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 商家7天内接通率区间查询 2017-03-29
	if param.CallConnectRateHigh >0 && param.CallConnectRateLower >= 0 {
		lowvalue:=""
		if param.CallConnectRateLower>0{
			lowvalue=strconv.FormatFloat(param.CallConnectRateLower, 'f', 2, 64)
		}
		tempBuf.WriteString(",")
		temp1:=this.GetSingleRangeFilterDsl("callconnectrate", lowvalue ,strconv.FormatFloat(param.CallConnectRateHigh, 'f', 2, 64), 3)
		tempBuf.Write(temp1.Bytes())
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region VIN码数组  2017-03-29
	if param.VinCodeArray != nil && len(param.VinCodeArray) > 0 {
		tempBuf = this.GetSingleTermFilterDsl_StringArray("vincode", param.VinCodeArray)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 车牌所在地 2017-04-10
	if param.LicenseCityIdArray != nil && len(param.LicenseCityIdArray) > 0 && param.LicenseCityIdArray[0]>0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32Array("licensecityid", param.LicenseCityIdArray, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}else if param.LicenseProvinceIdArray != nil && len(param.LicenseProvinceIdArray) > 0 && param.LicenseProvinceIdArray[0]>0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32Array("licenseproviceid", param.LicenseProvinceIdArray, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 是否上牌 2017-04-11
	if param.IsLicensed==1{
		//已上牌
		tempBuf = this.GetSingleTermFilterDsl_Int32("islicensed", 1, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}else if param.IsLicensed==-1{
		//未上牌
		tempBuf = this.GetSingleTermFilterDsl_Int32("islicensed", 0, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 排除CrmCustomerId数组 2017-04-12
	if param.NoCrmCustomerIdArray != nil && len(param.NoCrmCustomerIdArray) > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32Array("crmcustomerid", param.NoCrmCustomerIdArray, true)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 车源7天内PV数 2017-05-03
	if param.CarPvMin >0 || param.CarPvMax > 0 {
		min:=""
		max:=""
		if param.CarPvMin>0{
			min=strconv.Itoa(int(param.CarPvMin))
		}
		if param.CarPvMax>0{
			max=strconv.Itoa(int(param.CarPvMax))
		}
		tempBuf.WriteString(",")
		temp1:=this.GetSingleRangeFilterDsl("clickcount", min ,max, 3)
		tempBuf.Write(temp1.Bytes())
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 排除厂商ID数组 2017-05-22
	if param.NoSuperiorIdArray != nil && len(param.NoSuperiorIdArray) > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32Array("superiorid", param.NoSuperiorIdArray, true)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()

	}
	//endregion
	//region 是否认证车 2017-07-25
	if param.IsDealerAuthorized!=0{
		//已上牌
		tempBuf = this.GetSingleTermFilterDsl_Int32("isdealerauthorized", param.IsDealerAuthorized, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 贷款首付金额区间 2017-07-26
	if param.LoanFirstPayHighArray != nil && len(param.LoanFirstPayHighArray) > 0 && param.LoanFirstPayLowerArray != nil && len(param.LoanFirstPayLowerArray) > 0 && len(param.LoanFirstPayLowerArray) == len(param.LoanFirstPayHighArray) {
		tempBuf = this.GetSingleRangeFilterDsl_FloatArray("loanfirstpay", param.LoanFirstPayLowerArray, param.LoanFirstPayHighArray, 3)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 贷款日还款金额区间 2017-07-26
	if param.LoanDailyPayHighArray != nil && len(param.LoanDailyPayHighArray) > 0 && param.LoanDailyPayLowerArray != nil && len(param.LoanDailyPayLowerArray) > 0 && len(param.LoanDailyPayLowerArray) == len(param.LoanDailyPayHighArray) {
		tempBuf = this.GetSingleRangeFilterDsl_FloatArray("loandailypay", param.LoanDailyPayLowerArray, param.LoanDailyPayHighArray, 3)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//region 贷款月还款金额区间 2017-07-26
	if param.LoanMonthPayHighArray != nil && len(param.LoanMonthPayHighArray) > 0 && param.LoanMonthPayLowerArray != nil && len(param.LoanMonthPayLowerArray) > 0 && len(param.LoanMonthPayLowerArray) == len(param.LoanMonthPayHighArray) {
		tempBuf = this.GetSingleRangeFilterDsl_FloatArray("loanmonthpay", param.LoanMonthPayLowerArray, param.LoanMonthPayHighArray, 3)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//endregion
	//endregion

	//region 2.1.2 车型相关查询条件
	//车辆级别数组：包括一级级别和二级级别
	if (param.CarLevelArray != nil && len(param.CarLevelArray) > 0) || (param.CarLevelSecondArray != nil && len(param.CarLevelSecondArray) > 0) {
		var arrField []string
		var arrValue []int32
		if param.CarLevelArray != nil && len(param.CarLevelArray) > 0 {
			for i := 0; i < len(param.CarLevelArray); i++ {
				arrField = append(arrField, "carlevelvalue")
				arrValue = append(arrValue, param.CarLevelArray[i])
			}
		}
		if param.CarLevelSecondArray != nil && len(param.CarLevelSecondArray) > 0 {
			for i := 0; i < len(param.CarLevelSecondArray); i++ {
				arrField = append(arrField, "carlevelsecond")
				arrValue = append(arrValue, param.CarLevelSecondArray[i])
			}
		}
		tempBuf = this.GetMultiFieldTermFilterDsl_Int32Array(arrField, arrValue, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//主品牌ID数组
	if param.MainBrandArray != nil && len(param.MainBrandArray) > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32Array("mainbrandid", param.MainBrandArray, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//品牌ID数组
	if param.BrandArray != nil && len(param.BrandArray) > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32Array("producerid", param.BrandArray, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//车系ID数组
	if param.CarSerialArray != nil && len(param.CarSerialArray) > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32Array("brandid", param.CarSerialArray, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//车型ID数组
	if param.CarIDArray != nil && len(param.CarIDArray) > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32Array("carid", param.CarIDArray, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}else if param.IsCarId > 0{
		tempBuf = this.GetSingleRangeFilterDsl("carid", "0", "", 0)
		bufFilterAndNot.WriteString(",")
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//变速箱类型
	if param.GearBoxTypeArray != nil && len(param.GearBoxTypeArray) > 0 {
		var arrGearBoxType []int32
		for i := 0; i < len(param.GearBoxTypeArray); i++ {
			if param.GearBoxTypeArray[i] == 2 {
				arrGearBoxType = append(arrGearBoxType, 3, 4, 5, 6, 7, 8)
			} else {
				arrGearBoxType = append(arrGearBoxType, param.GearBoxTypeArray[i])
			}
		}
		tempBuf = this.GetSingleTermFilterDsl_Int32Array("gearboxtype", arrGearBoxType, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//环保标准
	if param.EnvirStandardArray != nil && len(param.EnvirStandardArray) > 0 {
		var arrFieldName []string
		var arrFieldValue []int32
		isandfilter:=false
		for i := 0; i < len(param.EnvirStandardArray); i++ {
			if param.EnvirStandardArray[i] != 0 {
				if param.EnvirStandardArray[i]==-1{
					isandfilter=true
				}
				arrFieldName = append(arrFieldName, "envirstandard_"+ strconv.Itoa(i+1))
				arrFieldValue = append(arrFieldValue, param.EnvirStandardArray[i])
			}
		}
		if isandfilter{
			//and检索
			for i := 0; i < len(arrFieldName); i++ {
				tempBuf = this.GetSingleTermFilterDsl_Int32(arrFieldName[i], arrFieldValue[i], false)
				bufFilterAndNot.Write(tempBuf.Bytes())
			}
		}else{
			//or检索
			tempBuf = this.GetMultiFieldTermFilterDsl_Int32Array(arrFieldName, arrFieldValue, false)
			bufFilterAndNot.Write(tempBuf.Bytes())
		}
		tempBuf.Reset()
	}
	//综合工况油耗自定义范围搜索
	if param.ConsumptionHighArray != nil && len(param.ConsumptionHighArray) > 0 && param.ConsumptionLowerArray != nil && len(param.ConsumptionLowerArray) > 0 && len(param.ConsumptionLowerArray) == len(param.ConsumptionHighArray) {
		tempBuf = this.GetSingleRangeFilterDsl_FloatArray("consumption", param.ConsumptionLowerArray, param.ConsumptionHighArray, 2)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//能源类型
	if param.OilTypeArray != nil && len(param.OilTypeArray) > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32Array("oiltype", param.OilTypeArray, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//发动机位置
	if param.EngineLocationArray != nil && len(param.EngineLocationArray) > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32Array("enginelocation", param.EngineLocationArray, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//车门数
	if param.BodyDoorsHighArray != nil && len(param.BodyDoorsHighArray) > 0 && param.BodyDoorsLowerArray != nil && len(param.BodyDoorsLowerArray) > 0 && len(param.BodyDoorsLowerArray) == len(param.BodyDoorsHighArray) {
		tempBuf = this.GetSingleRangeFilterDsl_IntArray("bodydoors", param.BodyDoorsLowerArray, param.BodyDoorsHighArray, 3)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//座位数/乘员人数
	if param.SeatNumHighArray != nil && len(param.SeatNumHighArray) > 0 && param.SeatNumLowerArray != nil && len(param.SeatNumLowerArray) > 0 && len(param.SeatNumLowerArray) == len(param.SeatNumHighArray) {
		var bufTempSub bytes.Buffer
		bufTempSub.WriteString(",")
		if len(param.SeatNumHighArray) > 1 {
			bufTempSub.WriteString("{\"bool\": {\"should\": [")
		}
		for i := 0; i < len(param.SeatNumHighArray); i++ {
			if i>0{
				bufTempSub.WriteString(",")
			}
			tempBuf = this.GetMultiFieldRangeFilterDsl("seatnummin", "seatnummax", strconv.Itoa(int(param.SeatNumHighArray[i])), strconv.Itoa(int(param.SeatNumLowerArray[i])), 3)
			bufTempSub.Write(tempBuf.Bytes())
		}
		if len(param.SeatNumHighArray) > 1 {
			bufTempSub.WriteString("]}}")
		}
		bufFilterAndNot.Write(bufTempSub.Bytes())
		bufTempSub.Reset()
	}
	//是否旅行版
	if param.IsWagon > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32("iswagon", param.IsWagon, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//驱动方式
	if param.DriveTypeArray != nil && len(param.DriveTypeArray) > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32Array("drivetype", param.DriveTypeArray, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//车身形式
	if param.CsBodyFormArray != nil && len(param.CsBodyFormArray) > 0 {
		tempBuf = this.GetSingleTermFilterDsl_Int32Array("csbodyform", param.CsBodyFormArray, false)
		bufFilterAndNot.Write(tempBuf.Bytes())
		tempBuf.Reset()
	}
	//--------------------------------------------------------------------------------------------------------
	//endregion

	//region 2.1.3 其他筛选条件
	//距离检索
	if param.DistanceKm > 0 && param.Location != "" {
		arrLocation := strings.Split(param.Location, ",")
		if arrLocation != nil && len(arrLocation) == 2 {
			tempBuf = this.GetGeoDistanceDsl(param.DistanceKm, arrLocation[0], arrLocation[1])
			bufFilterAndNot.Write(tempBuf.Bytes())
			tempBuf.Reset()
		}
	}
	//endregion

	//region 4. 拼接function score查询和排序条件
	strFunctionQuery:=""
	if param.SortBoostFlag == 2 {
		//region 站内列表页排序-corescript
		functionScore_template_uncorescript:=",{\"function_score\": {\"functions\": [{\"script_score\": {\"script\": {\"inline\": \"corescript\",\"lang\": \"native\",\"params\": {\"CurrentCityId\":%d,\"CurTime\":\"%s\",\"RequestSource\":%d}}}}]}}"
		if len(param.CityIdArray)>0{
			strFunctionQuery=fmt.Sprintf(functionScore_template_uncorescript,param.CityIdArray[0],strconv.FormatInt(time.Now().Unix()*1000, 10),param.RequestSource)
		}
		bufFilterAndNot.WriteString(strFunctionQuery)
		//endregion
	}else if param.SortBoostFlag == 3 {
		//region 站外列表页排序-uncorescript
		functionScore_template_uncorescript:=",{\"function_score\": {\"functions\": [{\"script_score\": {\"script\": {\"inline\": \"uncorescript\",\"lang\": \"native\",\"params\": {\"CurrentCityId\":%d,\"RelateCityId\":\"%s\"}}}}]}}"
		if param.CityIdArray!=nil && len(param.CityIdArray)>0{
			strRelateCity:=""
			if param.RelateCityArray!=nil && len(param.RelateCityArray)>0{
				for i:=0;i<len(param.RelateCityArray);i++ {
					if i>0{
						strRelateCity+=","
					}
					strRelateCity+=strconv.Itoa(int(param.RelateCityArray[i]))
				}
			}
			strFunctionQuery=fmt.Sprintf(functionScore_template_uncorescript,param.CityIdArray[0],strRelateCity)
		}
		bufFilterAndNot.WriteString(strFunctionQuery)
		//endregion
	}else if param.SortBoostFlag == 4 {
		//region LDS站外排序-siteoutscript
		functionScore_template_siteoutscript:=",{\"function_score\": {\"functions\": [{\"script_score\": {\"script\": {\"inline\": \"siteoutscript\",\"lang\": \"native\",\"params\": {\"CurrentCityId\":%d,\"RelateCityId\":\"%s\"}}}}]}}"
		if param.CityIdArray!=nil && len(param.CityIdArray)>0{
			strRelateCity:=""
			if param.RelateCityArray!=nil && len(param.RelateCityArray)>0{
				for i:=0;i<len(param.RelateCityArray);i++ {
					if i>0{
						strRelateCity+=","
					}
					strRelateCity+=strconv.Itoa(int(param.RelateCityArray[i]))
				}
			}
			strFunctionQuery=fmt.Sprintf(functionScore_template_siteoutscript,param.CityIdArray[0],strRelateCity)
		}
		bufFilterAndNot.WriteString(strFunctionQuery)
		//endregion
	}else if param.SortBoostFlag == 5 {
		//region 补充周边车源排序-relatecityscript
		functionScore_template_relatescript:=",{\"function_score\": {\"functions\": [{\"script_score\": {\"script\": {\"inline\": \"relatecityscript\",\"lang\": \"native\",\"params\": {\"RelateCityId\":\"%s\"}}}}]}}"
		strRelateCity:=""
		if param.RelateCityArray!=nil && len(param.RelateCityArray)>0{
			for i:=0;i<len(param.RelateCityArray);i++ {
				if i>0{
					strRelateCity+=","
				}
				strRelateCity+=strconv.Itoa(int(param.RelateCityArray[i]))
			}
		}
		strFunctionQuery=fmt.Sprintf(functionScore_template_relatescript,strRelateCity)
		bufFilterAndNot.WriteString(strFunctionQuery)
		//endregion
	}
	//bufQuery.WriteString("]}}")
	//endregion

	//region 2.1.4 车源补充规则
	var tempFilter bytes.Buffer
	arrCommonFlagBuf:=this.GetCommonFlagDslAll(param)
	for _,filter:=range arrCommonFlagBuf{
		//添加车源补充规则查询语句（即城市、车源状态）
		if len(arrCommonFlagBuf)>0{
			tempFilter=*bytes.NewBuffer(bufFilterAndNot.Bytes())
		}else{
			tempFilter=bufFilterAndNot
		}

		tempFilter.Write(filter.Bytes())
		//2.1.5 And区域收尾
		tempFilter.WriteString("]}")

		//2.3 拼接全量filter查询条件
		var bufFilter bytes.Buffer
		//bufFilter.WriteString("\"filter\": {")
		bufFilter.Write(tempFilter.Bytes())
		bufFilter.WriteString("}")
		arrFilter=append(arrFilter,bufFilter)
	}
	//endregion

	//region 4. 聚合检索
	var bufAggr bytes.Buffer
	if param.AggrFieldList != nil && len(param.AggrFieldList) > 0 {
		//bufAggr.WriteString(",\"facets\" : {")
		bufAggr.WriteString(",\"aggs\" : {")
		for i := 0; i < len(param.AggrFieldList); i++ {
			tempBuf = this.GetAggregationDsl(param.AggrFieldList[i])
			if i > 0 {
				bufAggr.WriteString(",")
			}
			bufAggr.Write(tempBuf.Bytes())
		}
		bufAggr.WriteString("}")
	}
	//endregion

	//region 5. 拼接排序语句
	var arrSort []bytes.Buffer
	arrSort = this.GetSortByOrderFieldDslAll(param)
	//endregion

	//region 6.拼接最终查询语句DSL
	var bufTotalResult bytes.Buffer
	bufTotalResult.WriteString("{")
	bufTotalResult.WriteString("\"from\":%d")
	//startNum := int(param.StartNum) + int((param.PageIndex - 1) * param.PageSize)
	//bufTotalResult.WriteString(strconv.Itoa(startNum))

	bufTotalResult.WriteString(",\"size\":%d")
	//bufTotalResult.WriteString(strconv.Itoa(int(param.PageSize)))
	bufTotalResult.Write(bufField.Bytes())
	if(bufFieldDistance.Bytes()!=nil){
		bufTotalResult.Write(bufFieldDistance.Bytes())
	}
	//bufTotalResult.WriteString(",")
	bufTotalResult.WriteString(",\"query\": {")

	//region 处理多次查询语句
	var stepTotalResult bytes.Buffer
	for i,filter:=range arrFilter{
		stepTotalResult.Reset()
		if len(arrFilter)>0{
			//多步检索，克隆对象
			stepTotalResult=*bytes.NewBuffer(bufTotalResult.Bytes())
		}else{
			stepTotalResult=bufTotalResult
		}
		if filter.Bytes() != nil {
			stepTotalResult.Write(filter.Bytes())
		}
		if bufQuery.Bytes() != nil{
			stepTotalResult.Write(bufQuery.Bytes())
		}
		if bufAggr.Bytes() != nil {
			stepTotalResult.Write(bufAggr.Bytes())
		}
		if len(arrSort)>i && len(arrSort[i].Bytes()) >0 {
			stepTotalResult.Write(arrSort[i].Bytes())
		}
		stepTotalResult.WriteString("}")
		dsl1:=stepTotalResult.String()
		arrDsl = append(arrDsl,dsl1)
	}
	//endregion
	//endregion
	return arrDsl
}
//endregion

//region 构建多字段数组整型数组value的的term filter语句
func (this *SearchConditionLibrary_V5) GetMultiFieldTermFilterDsl_Int32Array(fieldname []string, fieldvalue []int32, isNotFilter bool) (result bytes.Buffer) {
	if len(fieldvalue) > 1 {
		result.WriteString(",")
		if isNotFilter {
			result.WriteString("{\"not\":")
		}
		result.WriteString("{\"bool\": {\"should\": [{}")
	}

	var bufTemp bytes.Buffer
	for i := 0; i < len(fieldvalue); i++ {
		bufTemp = this.GetSingleTermFilterDsl_Int32(fieldname[i], fieldvalue[i], isNotFilter && len(fieldvalue) == 1)
		result.Write(bufTemp.Bytes())
	}
	if len(fieldvalue) > 1 {
		result.WriteString("]}}")
		if isNotFilter {
			result.WriteString("}")
		}
	}
	return result
}
//endregion

//region 构建单字段数组整型数组value的的term filter语句
func (this *SearchConditionLibrary_V5) GetSingleTermFilterDsl_Int32Array(fieldname string, fieldvalue []int32, isNotFilter bool) (result bytes.Buffer) {
	result.WriteString(",")
	if len(fieldvalue) > 1 {
		if isNotFilter {
			result.WriteString("{\"bool\": {\"must_not\":[")
		}else{
			result.WriteString("{\"bool\": {\"should\":[")
		}
	}
	var bufTemp bytes.Buffer
	for i := 0; i < len(fieldvalue); i++ {
		if i>0{
			result.WriteString(",")
		}
		bufTemp = this.GetSingleTermFilterDsl_Int32_V5(fieldname, fieldvalue[i], isNotFilter && len(fieldvalue) == 1)
		result.Write(bufTemp.Bytes())
	}
	if len(fieldvalue) > 1 {
		result.WriteString("]}}")
	}
	return result
}
//endregion

//region 构建单字段一个整型value的的term filter语句-V5
func (this *SearchConditionLibrary_V5) GetSingleTermFilterDsl_Int32_V5(fieldname string, fieldvalue int32, isNotFilter bool) (bytes.Buffer) {
	var result bytes.Buffer
	templatedsl:="{\"term\": {\"%s\":%d}}"
	if isNotFilter{
		templatedsl="{\"bool\": {\"must_not\":{\"term\": {\"%s\":%d}}}}"
	}
	result.WriteString(fmt.Sprintf(templatedsl,fieldname,fieldvalue))
	return result
}
//endregion

//region 构建单字段一个整型value的的term filter语句
func (this *SearchConditionLibrary_V5) GetSingleTermFilterDsl_Int32(fieldname string, fieldvalue int32, isNotFilter bool) (r bytes.Buffer) {
	var result bytes.Buffer
	result.WriteString(",")
	if isNotFilter {
		result.WriteString("{\"must_not\":")
	}
	result.WriteString("{\"term\": {\"")
	result.WriteString(fieldname)
	result.WriteString("\": ")
	result.WriteString(strconv.Itoa(int(fieldvalue)))
	result.WriteString("}}")
	if isNotFilter {
		result.WriteString("}")
	}
	return result
}
//endregion

//region 构建单字段一个字符串数组value的的term filter语句
func (this *SearchConditionLibrary_V5) GetSingleTermFilterDsl_StringArray(fieldname string, fieldvalue []string) (result bytes.Buffer) {
	result.WriteString(",")
	if len(fieldvalue) > 1 {
		result.WriteString("{\"bool\": {\"should\": [")
	}
	for i := 0; i < len(fieldvalue); i++ {
		if i>0{
			result.WriteString(",")
		}
		tempBuf := this.GetSingleTermFilterDsl_String(fieldname, fieldvalue[i])
		result.Write(tempBuf.Bytes())
	}
	if len(fieldvalue) > 1 {
		result.WriteString("]}}")
	}
	return result
}
//endregion

//region 构建单字段一个字符串value的的term filter语句
func (this *SearchConditionLibrary_V5) GetSingleTermFilterDsl_String(fieldname string, fieldvalue string) (bytes.Buffer) {
	var result bytes.Buffer
	templatedsl:="{\"term\": {\"%s\": \"%s\"}}"
	result.WriteString(fmt.Sprintf(templatedsl,fieldname,fieldvalue))
	return result
}
//endregion

//region 构建单字段一个字符串数组value的的query string语句
func (this *SearchConditionLibrary_V5) GetSingleQueryStringDsl_StringArray(fieldname string, fieldvalue []string) (result bytes.Buffer) {
	if len(fieldvalue) > 1 {
		result.WriteString("{\"bool\": {\"should\": [")
	}
	for i := 0; i < len(fieldvalue); i++ {
		if i>0{
			result.WriteString(",")
		}
		tempBuf := this.GetSingleQueryStringDsl_String(fieldname, fieldvalue[i])
		result.Write(tempBuf.Bytes())
	}
	if len(fieldvalue) > 1 {
		result.WriteString("]}}")
	}
	return result
}
//endregion

//region 构建单字段一个字符串value的的query string 语句
func (this *SearchConditionLibrary_V5) GetSingleQueryStringDsl_String(fieldname string, fieldvalue string) (r bytes.Buffer) {
	var result bytes.Buffer
	result.WriteString("{\"query_string\": {\"fields\" : [\"")
	result.WriteString(fieldname)
	result.WriteString("\"],\"query\": \"")
	result.WriteString(fieldvalue)
	result.WriteString("\"}}")
	return result
}
//endregion

//region 构建单字段一个浮点型范围查询的term filter语句 :isContainEdge:边界查询控制：0为无边界；1为包含做右边界；2为仅包含左边界；3为包含边界；默认为3
func (this *SearchConditionLibrary_V5) GetSingleRangeFilterDsl_FloatArray(fieldname string, arrMinValue []float64, arrMaxValue []float64, isContainEdge int) (result bytes.Buffer) {
	result.WriteString(",")
	if len(arrMinValue) > 1 {
		result.WriteString("{\"bool\": {\"should\": [")
	}
	for i := 0; i < len(arrMinValue); i++ {
		if i > 0 {
			result.WriteString(",")
		}
		tempBuf := this.GetSingleRangeFilterDsl(fieldname, strconv.FormatFloat(arrMinValue[i], 'f', 2, 64), strconv.FormatFloat(arrMaxValue[i], 'f', 2, 64), isContainEdge)
		result.Write(tempBuf.Bytes())
	}
	if len(arrMinValue) > 1 {
		result.WriteString("]}}")
	}
	return result
}
//endregion

//region 构建单字段一个整型范围查询的term filter语句  //isContainEdge:边界查询控制：0为无边界；1为包含做右边界；2为仅包含左边界；3为包含边界；默认为3
func (this *SearchConditionLibrary_V5) GetSingleRangeFilterDsl_IntArray(fieldname string, arrMinValue []int32, arrMaxValue []int32, isContainEdge int) (result bytes.Buffer) {
	result.WriteString(",")
	if len(arrMinValue) > 1 {
		result.WriteString("{\"bool\": {\"should\": [")
	}
	for i := 0; i < len(arrMinValue); i++ {
		if i > 0 {
			result.WriteString(",")
		}
		tempBuf := this.GetSingleRangeFilterDsl(fieldname,strconv.Itoa(int(arrMinValue[i])), strconv.Itoa(int(arrMaxValue[i])), isContainEdge)
		result.Write(tempBuf.Bytes())
	}
	if len(arrMinValue) > 1 {
		result.WriteString("]}}")
	}
	return result
}
//endregion

//region 构建单字段一个字符串范围查询的term filter语句  //isContainEdge:边界查询控制：0为无边界；1为包含做右边界；2为仅包含左边界；3为包含边界；默认为3
func (this *SearchConditionLibrary_V5) GetSingleRangeFilterDsl_StringArray(fieldname string, arrMinValue []string, arrMaxValue []string, isContainEdge int) (result bytes.Buffer) {
	result.WriteString(",")
	if len(arrMinValue) > 1 {
		result.WriteString("{\"bool\": {\"should\": [")
	}
	for i := 0; i < len(arrMinValue); i++ {
		if i > 0 {
			result.WriteString(",")
		}
		tempBuf := this.GetSingleRangeFilterDsl(fieldname, arrMinValue[i], arrMaxValue[i], isContainEdge)
		result.Write(tempBuf.Bytes())
	}
	if len(arrMinValue) > 1 {
		result.WriteString("]}}")
	}
	return result
}
//endregion

//region 构建单字段的range filter语句 //isContainEdge:边界查询控制：0为无边界；1为包含做右边界；2为仅包含左边界；3为包含边界；默认为3
func (this *SearchConditionLibrary_V5) GetSingleRangeFilterDsl(fieldname string, minvalue string, maxvalue string, isContainEdge int) (result bytes.Buffer) {
	var leftoperator, rightoperator string
	switch isContainEdge {
	case 0:
		leftoperator = "gt"
		rightoperator = "lt"
		break
	case 1:
		leftoperator = "gt"
		rightoperator = "lte"
		break
	case 2:
		leftoperator = "gte"
		rightoperator = "lt"
		break
	default:
		leftoperator = "gte"
		rightoperator = "lte"
		break
	}
	result.WriteString("{\"range\" : {\"")
	result.WriteString(fieldname)
	result.WriteString("\":{\"")
	if minvalue == "" {
		result.WriteString(rightoperator)
		result.WriteString("\":")
		result.WriteString(maxvalue)
	} else if maxvalue == "" {
		result.WriteString(leftoperator)
		result.WriteString("\":")
		result.WriteString(minvalue)
	} else {
		result.WriteString(leftoperator)
		result.WriteString("\":")
		result.WriteString(minvalue)
		result.WriteString(",\"")
		result.WriteString(rightoperator)
		result.WriteString("\":")
		result.WriteString(maxvalue)
	}

	result.WriteString("}}}")
	return result
}
//endregion

//region 构建多字段的range filter语句  //isContainEdge:边界查询控制：0为无边界；1为包含做右边界；2为仅包含左边界；3为包含边界；默认为3
func (this *SearchConditionLibrary_V5) GetMultiFieldRangeFilterDsl(lowfieldname string, highfieldname, minvalue string, maxvalue string, isContainEdge int) (result bytes.Buffer) {
	var leftoperator, rightoperator string
	switch isContainEdge {
	case 0:
		leftoperator = "gt"
		rightoperator = "lt"
		break
	case 1:
		leftoperator = "gt"
		rightoperator = "lte"
		break
	case 2:
		leftoperator = "gte"
		rightoperator = "lt"
		break
	default:
		leftoperator = "gte"
		rightoperator = "lte"
		break
	}
	result.WriteString("{\"bool\":{\"must\": [")
	result.WriteString("{\"range\" : {\"")
	result.WriteString(lowfieldname)
	result.WriteString("\":{\"")
	result.WriteString(rightoperator)
	result.WriteString("\":")
	result.WriteString(minvalue)
	result.WriteString("}}}")
	result.WriteString(",{\"range\" : {\"")
	result.WriteString(highfieldname)
	result.WriteString("\":{\"")
	result.WriteString(leftoperator)
	result.WriteString("\":")
	result.WriteString(maxvalue)
	result.WriteString("}}}]}}")
	return result
}
//endregion

//region 构建单字段的multimatch query语句，用于查询Keyword
func (this *SearchConditionLibrary_V5) GetKeywordQueryDsl_MultiMatchQuery(fieldvalue string,fieldname string) (result bytes.Buffer) {
	result.WriteString(",{\"multi_match\" : {\"query\":\"")
	result.WriteString(strings.Replace(fieldvalue,"\"","",-1))
	//\"cartitleinfo^10\",\"fullinfo\"
	result.WriteString("\",\"analyzer\": \"ik_smart\",\"type\": \"most_fields\",\"fields\" :[")
	result.WriteString(fieldname)
	result.WriteString("]}}")
	return result
}
//endregion

//region 构建高亮语句，用于Keyword查询
func (this *SearchConditionLibrary_V5) GetKeywordHighlightDsl(arrfieldname []string) (result bytes.Buffer) {
	result.WriteString(",\"highlight\" : {\"require_field_match\":\"true\",\"fields\":[")
	for i := 0; i < len(arrfieldname); i++ {
		if i>0{
			result.WriteString(",")
		}
		result.WriteString("{\"")
		result.WriteString(arrfieldname[i])
		result.WriteString("\":{}}")
	}

	result.WriteString("]}")
	return result
}
//endregion

//region 构建地理检索查询语句
func (this *SearchConditionLibrary_V5) GetGeoDistanceDsl(distance float64, lon string, lat string) (result bytes.Buffer) {
	templateqsl:=",{\"geo_distance\": {\"distance\":\"%fkm\",\"location\": {\"lat\": %s,\"lon\": %s }}}"
	result.WriteString(fmt.Sprintf(templateqsl,distance,lat,lon))
	return result
}
//endregion

//region 构建单字段聚合检索查询语句
func (this *SearchConditionLibrary_V5) GetAggregationDsl(param *pb.AggrCondition) (result bytes.Buffer) {
	result.WriteString("\"")
	result.WriteString(param.FieldName)
	result.WriteString("\" : {")
	switch param.AggregationType {
	case 1:
		//region term聚合
		result.WriteString("\"terms\": {\"field\":\"")
		result.WriteString(param.FieldName)
		result.WriteString("\",")
		if len(param.OrderFieldArray)>0 && len(param.OrderFieldArray)==len(param.OrderTypeArray) {
			result.WriteString("\"order\": [")
			for i:=0;i<len(param.OrderFieldArray);i++{
				if i>0{
					result.WriteString(",")
				}
				result.WriteString("{\"")
				result.WriteString(param.OrderFieldArray[i])
				result.WriteString("\":\"")
				result.WriteString(param.OrderTypeArray[i])
				result.WriteString("\"}")
			}
			result.WriteString("],")
		}
		result.WriteString("\"size\":")
		result.WriteString(strconv.Itoa(int(param.TopNumber)))
		result.WriteString("}")
		//endregion
		break
	case 2:
		//region IntRange,DoubleRange聚合
		result.WriteString("\"range\": {")
		result.WriteString("\"field\": \"")
		result.WriteString(param.FieldName)
		result.WriteString("\",")
		//region 暂不支持排序 废弃
		if len(param.OrderFieldArray)>0 && len(param.OrderFieldArray)==len(param.OrderTypeArray) {
			result.WriteString("\"order\": [")
			for i:=0;i<len(param.OrderFieldArray);i++{
				if i>0{
					result.WriteString(",")
				}
				result.WriteString("{\"")
				result.WriteString(param.OrderFieldArray[i])
				result.WriteString("\":\"")
				result.WriteString(param.OrderTypeArray[i])
				result.WriteString("\"}")
			}
			result.WriteString("],")
		}
		//endregion
		result.WriteString("\"ranges\":[")
		result.WriteString(param.RangeConfig)
		result.WriteString("]}")
		//endregion
		break
	}
	if len(param.SubKeyFieldArray)>0 && len(param.SubKeyFieldArray)==len(param.SubAggrTypeArray)&&len(param.SubKeyFieldArray)==len(param.SubValueFieldArray){
		tempDsl:=this.GetSubAggregationDsl(param)
		result.Write(tempDsl.Bytes())
	}
	result.WriteString("}")
	return result
}

//生成二次聚合查询条件
func(this *SearchConditionLibrary_V5) GetSubAggregationDsl(param *pb.AggrCondition)(result bytes.Buffer){
	result.WriteString(",\"aggs\":{")
	for i:=0;i<len(param.SubKeyFieldArray);i++{
		if i>0{
			result.WriteString(",")
		}
		result.WriteString("\"")
		result.WriteString(param.SubKeyFieldArray[i])
		result.WriteString("\":{\"")
		result.WriteString(param.SubAggrTypeArray[i])
		result.WriteString("\":{\"field\": \"")
		result.WriteString(param.SubValueFieldArray[i])
		result.WriteString("\"}}")
	}
	result.WriteString("}")
	return result
}
//endregion

//region 构建车源检索排序语句：考虑CommonFlag规则
func (this *SearchConditionLibrary_V5) GetSortByOrderFieldDsl(param *pb.SearchCondition) (result bytes.Buffer) {
	if param.CommonFlag > 0 {
		//特殊查询规则下，无需排序，走自定义评分
		return result
	}
	result.WriteString("\"sort\": [")
	if param.OrderByFieldArray != nil && len(param.OrderByFieldArray) > 0 {
		for i := 0; i < len(param.OrderByFieldArray); i++ {
			if i > 0 {
				result.WriteString(",")
			}
			result.WriteString("{\"")
			result.WriteString(strings.ToLower(param.OrderByFieldArray[i]))
			result.WriteString("\":\"")
			if param.OrderByIsDESCArray != nil && len(param.OrderByIsDESCArray) > i {
				if param.OrderByIsDESCArray[i] {
					result.WriteString("desc")
				} else {
					result.WriteString("asc")
				}
			} else {
				result.WriteString("desc")
			}
			result.WriteString("\"}")
		}
	} else {
		//默认按照权重排序
		result.WriteString("{\"status\":\"asc\"},{\"boostapp\":\"desc\"}")
	}

	result.WriteString("]")
	return result
}
//endregion

//region 构建车源检索排序语句：考虑CommonFlag规则  分布查询时返回多个排序语句
func (this *SearchConditionLibrary_V5) GetSortByOrderFieldDslAll(param *pb.SearchCondition) (arrResult []bytes.Buffer) {
	if param.SortBoostFlag > 0  || param.KeyWord!="" {
		//无需排序
		return nil
	}
	var result bytes.Buffer
	if param.DistanceKm>0 && param.Location!=""{
		//region 按距离排序
		templateqsl_sort_distance:=",\"sort\": [{\"_geo_distance\": {\"location\": {\"lat\": %s,\"lon\": %s},\"order\": \"asc\",\"unit\": \"km\",\"distance_type\": \"plane\"}}]"
		arrLocation:=strings.Split(param.Location,",")
		if len(arrLocation)==2{
			result.WriteString(fmt.Sprintf(templateqsl_sort_distance,arrLocation[1],arrLocation[0]))
		}
		//endregion
	}else if  len(param.OrderByFieldArray) > 0  && len(param.OrderByIsDESCArray) == len(param.OrderByFieldArray) {
		//有自定义字段排序
		butTemp:=this.GetCarSortQueryDsl(param)
		result.Write(butTemp.Bytes())
	}else {
		//默认按照权重排序
		result.WriteString(",\"sort\": [{\"status\":\"asc\"},{\"boostapp\":\"desc\"}]")
	}
	arrResult = append(arrResult,result)

	//region 根据车源补充策略初始化排序对象数组
	switch param.CommonFlag {
	case 1:
		//本地--周边
		arrResult = append(arrResult,result)
	break
	case 2,4:
		//本地在售---周边在售+本地已售
		arrResult = append(arrResult,result)
	break
	case 3:
		//本地---周边---全国
		arrResult = append(arrResult,result)
		arrResult = append(arrResult,result)
	break
	}
	//endregion
	return arrResult
}
//endregion

//region 构建车源检索排序语句:支持常规字段和距离排序
func (this *SearchConditionLibrary_V5) GetCarSortQueryDsl(param *pb.SearchCondition) (result bytes.Buffer) {
	templateqsl_sort_field:="{\"%s\":\"%s\"}"
	templateqsl_sort_distance:="{\"_geo_distance\": {\"location\": {\"lat\": %s,\"lon\": %s},\"order\": \"asc\",\"unit\": \"km\",\"distance_type\": \"plane\"}}"
	if param.OrderByFieldArray != nil && len(param.OrderByFieldArray) > 0 {
		result.WriteString(",\"sort\": [")
		for i := 0; i < len(param.OrderByFieldArray); i++ {
			if i > 0 {
				result.WriteString(",")
			}
			if param.OrderByFieldArray[i]=="distance"{
				//按距离排序
				arrLocation:=strings.Split(param.Location,",")
				if len(param.Location)==2{
					result.WriteString(fmt.Sprintf(templateqsl_sort_distance,arrLocation[0],arrLocation[1]))
				}
			}else{
				//按普通字段排序
				strdesc:="desc"
				if len(param.OrderByIsDESCArray) > i {
					if !param.OrderByIsDESCArray[i] {
						strdesc="asc"
					}
				}
				result.WriteString(fmt.Sprintf(templateqsl_sort_field,strings.ToLower(param.OrderByFieldArray[i]),strdesc))
			}
		}
		result.WriteString("]")
	}
	return result
}
//endregion

//region 构建常规排序语句:按指定字段和排序类型排序
func (this *SearchConditionLibrary_V5) GetSortQueryDsl(orderfield []string,isdesc []bool) (result bytes.Buffer) {
	templateqsl_sort_field:="{\"%s\":\"%s\"}"
	//templateqsl_sort_distance:="{\"_geo_distance\": {\"location\": {\"lat\": %s,\"lon\": %s},\"order\": \"asc\",\"unit\": \"km\",\"distance_type\": \"plane\"}}"
	if orderfield != nil && len(orderfield) > 0 {
		result.WriteString("\"sort\": [")
		for i := 0; i < len(orderfield); i++ {
			if i > 0 {
				result.WriteString(",")
			}
			strdesc:="desc"
			if isdesc != nil && len(isdesc) > i {
				if !isdesc[i] {
					strdesc="asc"
				}
			}
			result.WriteString(fmt.Sprintf(templateqsl_sort_field,strings.ToLower(orderfield[i]),strdesc))
		}
		result.WriteString("]")
	}
	return result
}
//endregion

//region 构建车源补充规则查询语句
func (this *SearchConditionLibrary_V5) GetCommonFlagDsl(param *pb.SearchCondition) (r bytes.Buffer) {
	var tempBuf bytes.Buffer
	var result bytes.Buffer

	if param.SortBoostFlag > 0{
		//region 实时评分---车源补充
		switch param.CommonFlag {
		case 3:
			//region 本地---周边----全国，不添加城市ID筛选条件
			tempBuf = this.GetSingleTermFilterDsl_Int32Array("status", param.StatusArray, false)
			//endregion
			break
		case 1:
			//region 本地---周边
			//添加车源状态筛选条件
			tempBuf = this.GetSingleTermFilterDsl_Int32Array("status", param.StatusArray, false)
			result.Write(tempBuf.Bytes())
			if param.CityIdArray!=nil && len(param.CityIdArray)>0 && param.RelateCityArray!=nil && len(param.RelateCityArray)>0 {
				//region 城市站检索：本地城市+周边城市
				var arrCityId []int32
				arrCityId = append(param.CityIdArray,param.RelateCityArray...)
				tempBuf = this.GetSingleTermFilterDsl_Int32Array("carcityid", arrCityId, false)
				result.Write(tempBuf.Bytes())
				//endregion
			}else if param.ProvinceIdArray!=nil && len(param.ProvinceIdArray)>0{
				//region 省站检索
				tempBuf = this.GetSingleTermFilterDsl_Int32Array("carproviceid", param.ProvinceIdArray, false)
				result.Write(tempBuf.Bytes())
				//endregion
			}
			//endregion
			break
		case 2,4:
			//region 本地在售---周边在售---本地已售
			if param.CityIdArray!=nil && len(param.CityIdArray)>0 && param.RelateCityArray!=nil && len(param.RelateCityArray)>0{
				//region 城市站检索 本地在售---周边在售---本地已售
				result.WriteString(",{\"bool\": {\"should\": [{\"bool\": {\"must\": [{\"term\": {\"carcityid\":")
				result.WriteString(strconv.Itoa(int(param.CityIdArray[0])))
				result.WriteString("}},{\"bool\": {\"should\": [{\"term\": {\"status\":4}},{\"term\": {\"status\": 1}}]}}]}},")
				result.WriteString("{\"bool\": {\"must\": [{\"bool\": {\"should\": [")
				for i,id := range param.RelateCityArray{
					if i>0{
						result.WriteString(",")
					}
					result.WriteString("{\"term\": {\"carcityid\":")
					result.WriteString(strconv.Itoa(int(id)))
					result.WriteString("}}")
				}
				result.WriteString("]}},{\"term\": {\"status\": 1}}]}}]}}")
				//endregion
			}else if param.ProvinceIdArray!=nil && len(param.ProvinceIdArray)>0{
				//region 省站检索   本省在售---本省已售
				tempBuf = this.GetSingleTermFilterDsl_Int32Array("status", param.StatusArray, false)
				result.Write(tempBuf.Bytes())
				tempBuf = this.GetSingleTermFilterDsl_Int32Array("carproviceid", param.ProvinceIdArray, false)
				result.Write(tempBuf.Bytes())
				//endregion
			}

			//endregion
			break
		default:
			//region 无补充规则
			//添加车源状态筛选条件
			tempBuf = this.GetSingleTermFilterDsl_Int32Array("status", param.StatusArray, false)
			result.Write(tempBuf.Bytes())
			if param.CityIdArray != nil && len(param.CityIdArray) > 0 {
				//添加城市筛选条件
				tempBuf = this.GetSingleTermFilterDsl_Int32Array("carcityid",  param.CityIdArray, false)
				result.Write(tempBuf.Bytes())
			} else {
				//添加省份筛选条件
				if param.ProvinceIdArray != nil && len(param.ProvinceIdArray) > 0 {
					tempBuf = this.GetSingleTermFilterDsl_Int32Array("carproviceid", param.ProvinceIdArray, false)
					result.Write(tempBuf.Bytes())
				}
			}
			//endregion
			break
		}
		//endregion
	}else{
		//region 非实时评分---按字段排序---车源补充
		switch param.CommonFlag {
		case 3:
			//region 本地---周边----全国，不添加城市ID筛选条件
			tempBuf = this.GetSingleTermFilterDsl_Int32Array("status", param.StatusArray, false)
			//endregion
			break
		case 1:
			//region 本地---周边
			//添加车源状态筛选条件
			tempBuf = this.GetSingleTermFilterDsl_Int32Array("status", param.StatusArray, false)
			result.Write(tempBuf.Bytes())
			//添加城市筛选条件
			var arrCityId []int32
			arrCityId = append(param.CityIdArray,param.RelateCityArray...)
			tempBuf = this.GetSingleTermFilterDsl_Int32Array("carcityid", arrCityId, false)
			result.Write(tempBuf.Bytes())
			//endregion
			break
		case 2,4:
			//region 本地在售---周边在售---本地已售
			if param.CityIdArray!=nil && len(param.CityIdArray)>0 && param.RelateCityArray!=nil && len(param.RelateCityArray)>0{
				//region 城市站检索 本地在售---周边在售---本地已售
				result.WriteString(",{\"bool\": {\"should\": [{\"bool\": {\"must\": [{\"term\": {\"carcityid\":")
				result.WriteString(strconv.Itoa(int(param.CityIdArray[0])))
				result.WriteString("}},{\"bool\": {\"should\": [{\"term\": {\"status\":4}},{\"term\": {\"status\": 1}}]}}]}},")
				result.WriteString("{\"bool\": {\"must\": [{\"bool\": {\"should\": [")
				for i,id := range param.RelateCityArray{
					if i>0{
						result.WriteString(",")
					}
					result.WriteString("{\"term\": {\"carcityid\":")
					result.WriteString(strconv.Itoa(int(id)))
					result.WriteString("}}")
				}
				result.WriteString("]}},{\"term\": {\"status\": 1}}]}}]}}")
				//endregion
			}else if param.ProvinceIdArray!=nil && len(param.ProvinceIdArray)>0{
				//region 省站检索   本省在售---本省已售
				tempBuf = this.GetSingleTermFilterDsl_Int32Array("status", param.StatusArray, false)
				result.Write(tempBuf.Bytes())
				tempBuf = this.GetSingleTermFilterDsl_Int32Array("carproviceid", param.ProvinceIdArray, false)
				result.Write(tempBuf.Bytes())
				//endregion
			}

			//endregion
			break
		default:
			//region 无补充规则
			//添加车源状态筛选条件
			tempBuf = this.GetSingleTermFilterDsl_Int32Array("status", param.StatusArray, false)
			result.Write(tempBuf.Bytes())
			if param.CityIdArray != nil && len(param.CityIdArray) > 0 {
				//添加城市筛选条件
				tempBuf = this.GetSingleTermFilterDsl_Int32Array("carcityid",  param.CityIdArray, false)
				result.Write(tempBuf.Bytes())
			} else {
				//添加省份筛选条件
				if param.ProvinceIdArray != nil && len(param.ProvinceIdArray) > 0 {
					tempBuf = this.GetSingleTermFilterDsl_Int32Array("carproviceid", param.ProvinceIdArray, false)
					result.Write(tempBuf.Bytes())
				}
			}
			//endregion
			break
		}
		//endregion
	}

	return result
}
//endregion

//region 构建车源补充规则查询语句：分布查询时返回多个查询语句
func (this *SearchConditionLibrary_V5) GetCommonFlagDslAll(param *pb.SearchCondition) (r []bytes.Buffer) {
	var tempBuf bytes.Buffer
	var arrResult []bytes.Buffer
	var result bytes.Buffer
	var result2 bytes.Buffer
	var result3 bytes.Buffer

	if param.SortBoostFlag > 0{
		//region 实时评分---车源补充
		switch param.CommonFlag {
		case 3:
			//region 本地---周边----全国，不添加城市ID筛选条件
			tempBuf = this.GetSingleTermFilterDsl_Int32Array("status", param.StatusArray, false)
			//endregion
			break
		case 1:
			//region 本地---周边
			//添加车源状态筛选条件
			tempBuf = this.GetSingleTermFilterDsl_Int32Array("status", param.StatusArray, false)
			result.Write(tempBuf.Bytes())
			//添加城市筛选条件
			var arrCityId []int32
			arrCityId = append(param.CityIdArray,param.RelateCityArray...)
			tempBuf = this.GetSingleTermFilterDsl_Int32Array("carcityid", arrCityId, false)
			result.Write(tempBuf.Bytes())
			//endregion
			break
		case 2,4:
			//region 本地在售---周边在售---本地已售
			if param.CityIdArray!=nil && len(param.CityIdArray)>0 && param.RelateCityArray!=nil && len(param.RelateCityArray)>0{
				//region 城市站检索 本地在售---周边在售---本地已售
				result.WriteString(",{\"bool\": {\"should\": [{\"bool\": {\"must\": [{\"term\": {\"carcityid\":")
				result.WriteString(strconv.Itoa(int(param.CityIdArray[0])))
				result.WriteString("}},{\"bool\": {\"should\": [{\"term\": {\"status\":4}},{\"term\": {\"status\": 1}}]}}]}},")
				result.WriteString("{\"bool\": {\"must\": [{\"bool\": {\"should\": [")
				for i,id := range param.RelateCityArray{
					if i>0{
						result.WriteString(",")
					}
					result.WriteString("{\"term\": {\"carcityid\":")
					result.WriteString(strconv.Itoa(int(id)))
					result.WriteString("}}")
				}
				result.WriteString("]}},{\"term\": {\"status\": 1}}]}}]}}")
				//endregion
			}else if param.ProvinceIdArray!=nil && len(param.ProvinceIdArray)>0{
				//region 省站检索   本省在售---本省已售
				tempBuf = this.GetSingleTermFilterDsl_Int32Array("status", param.StatusArray, false)
				result.Write(tempBuf.Bytes())
				tempBuf = this.GetSingleTermFilterDsl_Int32Array("carproviceid", param.ProvinceIdArray, false)
				result.Write(tempBuf.Bytes())
				//endregion
			}

			//endregion
			break

		}
		//endregion
	}else{
		//region 非实时评分---按字段排序---车源补充
		switch param.CommonFlag {
		case 3:
			//region 本地---周边----全国，不添加城市ID筛选条件
			//车源状态筛选条件
			tempBuf = this.GetSingleTermFilterDsl_Int32Array("status", param.StatusArray, false)
			result.Write(tempBuf.Bytes())
			result2.Write(tempBuf.Bytes())
			result3.Write(tempBuf.Bytes())
			//分步添加城市检索条件
			//第一步：本地
			tempBuf = this.GetSingleTermFilterDsl_Int32Array("carcityid", param.CityIdArray, false)
			result.Write(tempBuf.Bytes())
			//第二步：周边
			tempBuf = this.GetSingleTermFilterDsl_Int32Array("carcityid", param.RelateCityArray, false)
			result2.Write(tempBuf.Bytes())
			//第三步：全国
			tempBuf = this.GetSingleTermFilterDsl_Int32Array("carcityid", append(param.RelateCityArray,param.CityIdArray...) ,true)
			result3.Write(tempBuf.Bytes())
			//endregion
			break
		case 1:
			//region 本地---周边
			//添加车源状态筛选条件
			tempBuf = this.GetSingleTermFilterDsl_Int32Array("status", param.StatusArray, false)
			result.Write(tempBuf.Bytes())
			result2.Write(tempBuf.Bytes())
			//分步添加城市筛选条件
			//第一步：本地
			tempBuf = this.GetSingleTermFilterDsl_Int32Array("carcityid", param.CityIdArray, false)
			result.Write(tempBuf.Bytes())
			//第二步：周边
			tempBuf = this.GetSingleTermFilterDsl_Int32Array("carcityid", param.RelateCityArray, false)
			result2.Write(tempBuf.Bytes())
			//endregion
			break
		case 2,4:
			//region 本地在售---周边在售---本地已售
			if param.CityIdArray!=nil && len(param.CityIdArray)>0 && param.RelateCityArray!=nil && len(param.RelateCityArray)>0{
				//region 城市站检索 本地在售---周边在售---本地已售

				//分步添加城市筛选条件
				//第一步：本地--在售
				tempBuf = this.GetSingleTermFilterDsl_Int32("status", 1, false)
				result.Write(tempBuf.Bytes())
				tempBuf = this.GetSingleTermFilterDsl_Int32Array("carcityid", param.CityIdArray, false)
				result.Write(tempBuf.Bytes())

				//第二步：周边--在售  本地--已售
				result2.WriteString(",{\"bool\": {\"should\": [{\"bool\":{\"must\":[{\"term\": {\"carcityid\": ")
				result2.WriteString(strconv.Itoa(int(param.CityIdArray[0])))
				result2.WriteString("}},{\"term\": {\"status\": 4}}]}},{\"bool\":{\"must\":[{\"term\": {\"status\": 1}},{\"bool\":{\"should\":[")
				for i,id := range param.RelateCityArray{
					if i>0{
						result2.WriteString(",")
					}
					result2.WriteString("{\"term\": {\"carcityid\":")
					result2.WriteString(strconv.Itoa(int(id)))
					result2.WriteString("}}")
				}
				result2.WriteString("]}}]}}]}}")
				//endregion
			}else if param.ProvinceIdArray!=nil && len(param.ProvinceIdArray)>0{
				//region 省站检索   本省在售---本省已售
				tempBuf = this.GetSingleTermFilterDsl_Int32Array("status", param.StatusArray, false)
				result.Write(tempBuf.Bytes())
				tempBuf = this.GetSingleTermFilterDsl_Int32Array("carproviceid", param.ProvinceIdArray, false)
				result.Write(tempBuf.Bytes())
				//endregion
			}

			//endregion
			break
		}
		//endregion
	}

	//region 无补充规则

	if param.CommonFlag==0 {
		//添加车源状态筛选条件
		tempBuf = this.GetSingleTermFilterDsl_Int32Array("status", param.StatusArray, false)
		result.Write(tempBuf.Bytes())
		if param.CityIdArray != nil && len(param.CityIdArray) > 0 {
			//添加城市筛选条件
			tempBuf = this.GetSingleTermFilterDsl_Int32Array("carcityid", param.CityIdArray, false)
			result.Write(tempBuf.Bytes())
		} else {
			//添加省份筛选条件
			if param.ProvinceIdArray != nil && len(param.ProvinceIdArray) > 0 {
				tempBuf = this.GetSingleTermFilterDsl_Int32Array("carproviceid", param.ProvinceIdArray, false)
				result.Write(tempBuf.Bytes())
			}
		}
	}
	//endregion

	arrResult= append(arrResult,result)
	if result2.Bytes()!=nil{
		arrResult= append(arrResult,result2)
	}
	if result3.Bytes()!=nil{
		arrResult= append(arrResult,result3)
	}
	return arrResult
}
//endregion
package ESGoServer

import (
	pb "../grpc"
	"strconv"
	"../tools"
	"strings"
	"crypto/md5"
	"fmt"
	"encoding/hex"
)

/*
功能：添加搜索规则
 */

type SearchRule struct {
}

//渠道ID分组：站内列表页、店铺页
var RequestSource_CoreAndVendor=[]int{174,175,176,177,178,179,184,185,189,193,198,221,248,256,261,306,307}
//渠道ID分组：站内PC列表页、店铺页
var RequestSource_CorePCAndVendor=[]int{174,175,176,177,178,179,184,185,189,193,248,256,261,306,307}
//渠道ID分组：站内非PC列表页（用于喜相逢站内控制）
var RequestSource_CoreForXixiangfeng=[]int{198,221}
//渠道ID分组：站内店铺页：车源批售 2017-06-08
var RequestSource_CoreVendor=[]int{175,184,189}

//region 校验传入参数是否合法，并初始化默认参数值--车源索引
func (this *SearchRule) CheckParameters(param *pb.SearchCondition,indexname string) (p *pb.SearchCondition, r bool, errmsg string) {
	//region 常规参数校验
	if param.PageSize < 0 {
		param.PageSize = 10
	}
	if param.PageSize > 500 {
		param.PageSize = 500
	}
	if param.IsCountSearch{
		param.PageSize=0
	}
	if param.PageIndex <= 0 {
		param.PageIndex = 1
	}
	if param.PageIndex*param.PageSize >2550 {
		param.PageIndex = 1
	}
	if param.AdCity>0 && indexname!="cpccar"{
		param.AdCity=0
	}
	if param.RequestSource <= 0 {
		return param, false, "Invalid RequestSource(can not lower than zero)"
	}
	if param.CommonFlag < 0 || param.CommonFlag > 4 {
		return param, false, "Invalid CommonFlag("+strconv.Itoa(int(param.CommonFlag))+")"
	}
	if param.IsCountSearch {
		param.SortBoostFlag=0
		param.CommonFlag=0
	}
	if len(param.StatusArray)==0{
		param.StatusArray=[]int32{1}
	}
	//endregion

	//region 校验自定义评分参数
	if param.SortBoostFlag>0 {
		if param.KeyWord!=""{
			//存在关键词检索，取消自定义评分，根据关键词匹配度进行打分
			param.SortBoostFlag=0
		}else if len(param.OrderByFieldArray)>0 && len(param.OrderByIsDESCArray)>0{
			//region 存在自定义排序时，取消自定义评分，按用户排序条件进行排序
			arrDefaultSortField:=[]string{"status","boost","boostc","boostapp","istop","isneglect","siteid"}
			for _,fieldname := range param.OrderByFieldArray{
				if !objSearchTool.CheckSliceContainString(arrDefaultSortField,fieldname){
					//存在自定义排序条件，取消实时评分配置
					param.SortBoostFlag=0
					break
				}
			}
			//endregion
		}else if param.DistanceKm>0 && param.Location!=""{
			//存在距离检索，取消自定义评分，根据距离排序
			param.SortBoostFlag=0
		}else if len(param.CityIdArray)==0{
			//全国车源检索，取消自定义评分，默认按照是否置顶、站内基础权重排序 2017-08-21
			param.SortBoostFlag=0
			if len(param.OrderByFieldArray)==0 || len(param.OrderByIsDESCArray)==0{
				param.OrderByFieldArray=[]string{"istop","boostapp"}
				param.OrderByIsDESCArray=[]bool{true,true}
			}
		}
	}
	//endregion

	//region 校验车源补充规则
	switch param.CommonFlag {
	case 1:
		//本地----周边
		if param.CityIdArray == nil || len(param.CityIdArray) == 0 || param.RelateCityArray == nil || len(param.RelateCityArray) == 0 {
			param.CommonFlag = 0
		}
		break
	case 2,4:
		//列表页规则：本地在售----周边在售----本地已售
		if(!objSearchTool.CheckSliceContain(param.StatusArray,4)){
			param.CommonFlag = 1
			if (param.CityIdArray == nil || len(param.CityIdArray) == 0) && (param.ProvinceIdArray != nil && len(param.ProvinceIdArray) > 0) {
				//省站检索
				param.CommonFlag = 0
			}
		}
		if param.CityIdArray != nil && len(param.CityIdArray) > 0 && (param.RelateCityArray == nil || len(param.RelateCityArray) == 0) {
			param.CommonFlag = 0
		}

		if (param.CityIdArray == nil || len(param.CityIdArray) == 0) && (param.ProvinceIdArray == nil || len(param.ProvinceIdArray) == 0) {
			param.CommonFlag = 0
		}
		break
	case 3:
		//本地--周边--全国
		if param.CityIdArray == nil || len(param.CityIdArray) == 0 || param.RelateCityArray == nil || len(param.RelateCityArray) == 0 {
			param.CommonFlag = 0
		}
		break
	}
	//endregion

	return param, true, ""
}
//endregion

//region 校验传入参数是否合法，并初始化默认参数值--问答索引
func (this *SearchRule) CheckParametersQuestion(param *pb.SearchQuestionCondition) (p *pb.SearchQuestionCondition, r bool, errmsg string) {
	//0. 参数校验
	if param.PageSize <= 0 {
		param.PageSize = 10
	}
	if param.PageSize > 500 {
		param.PageSize = 500
	}
	if param.PageIndex <= 0 {
		param.PageIndex = 1
	}
	if param.RequestSource <= 0 {
		return param, false, "RequestSource不能为空！"
	}
	if param.IsHightLight && len(param.HightLightFieldArray)==0{
		param.HightLightFieldArray=[]string{"title","body","replybody"}
	}
	return param, true, ""
}
//endregion

//region 根据请求条件获取指定的索引名
func (this *SearchRule) GetIndexName(param *pb.SearchCondition)(indexname string) {
	indexname="car_base"
	//2017-08-21 全国检索及补充周边车源时，忽略宁波车源
	if len(param.CityIdArray)>0 && param.CityIdArray[0]==3002 {
		//宁波车源
		indexname="car_city_3002"
	}
	return indexname
}
//endregion

//region 获取CPL车源索引名称
func (this *SearchRule) GetCPLCarIndexName(param *pb.SearchCondition)(indexname string) {
	//indexname="car_cpl"
	indexname="car"
	return indexname
}
//endregion

//region LDS相关规则过滤
func (this *SearchRule) CheckCarLdsRules(param *pb.SearchCondition,indexname string) *pb.SearchCondition {
	//region CPC索引、问答索引、京东索引，不走LDS规则
	if indexname=="cpccar" || indexname=="jdcar" || indexname=="question"{
		return param
	}
	//endregion

	//region 按照UserId、ID或SerialNumber精准检索时，不走LDS规则
	if len(param.UserIdArray)>0 || len(param.IdArray)>0 || len(param.SerialNumberArray)>0{
		return param
	}
	//endregion

	//实施常规车源索引LDS规则-----------------------------------------------------------------------------------

	//region 设置指定渠道请求，屏蔽接通率低于40%的商家车源 2017-03-29
	if len(tools.MyConfigHelper.LDSMarkingvendorSource)>=1 && tools.MyConfigHelper.LDSMarkingvendorSource[0]>0 && !objSearchTool.CheckSliceContainInt(tools.MyConfigHelper.LDSMarkingvendorSource,int(param.RequestSource)){
		//剔除7天内接通率低于30%的商家车源
		param.CallConnectRateLower=0.4
		param.CallConnectRateHigh=1.0
	}
	//endregion

	//region 特定城市剔除特定客户的车源：'苏州','成都'  1502,2501  2017-04-18
	if len(param.CityIdArray) > 0 && objSearchTool.CheckSliceContain(tools.MyConfigHelper.LDSMarkingAgencyCity, param.CityIdArray[0]) {
		if !objSearchTool.CheckSliceContainInt(RequestSource_CoreAndVendor,int(param.RequestSource)) {
			//屏蔽以下客户编号下的经销商车源   1085804136  1024818901  1039209239
			//人人车：1085804136，瓜子：1037391190，喜相逢：1005189834,1028932386,1035062931,1071341554,1086550310
			param.NoCrmCustomerIdArray = append(param.NoCrmCustomerIdArray,tools.MyConfigHelper.LDSMarkingAgencyCustomer...)
		}
	}
	//endregion

	//region 特定渠道剔除喜相逢车源：99  2017-05-08
	if !objSearchTool.CheckSliceContainInt(RequestSource_CoreAndVendor,int(param.RequestSource)) {
		//屏蔽喜相逢车源
		param.NoCrmCustomerIdArray = append(param.NoCrmCustomerIdArray,99)
	}
	//endregion

	//region 特定渠道屏蔽CPL车源  2017-06-05
	if objSearchTool.CheckSliceContain(tools.MyConfigHelper.CPLRequestSourceForMarking,param.RequestSource) {
		//屏蔽CPL车源
		param.NoCrmCustomerIdArray = append(param.NoCrmCustomerIdArray,tools.MyConfigHelper.CPLCustomerIdArray...)
	}
	//endregion

	//region 排除特定渠道剔除（批售商家）车源：1002088063  2017-06-08
	if !objSearchTool.CheckSliceContainInt(RequestSource_CoreVendor,int(param.RequestSource)) {
		//屏蔽批售商家车源
		param.NoCrmCustomerIdArray = append(param.NoCrmCustomerIdArray,1002088063)
	}
	//endregion

	//region 站外渠道，调整默认排序机制为按boost排序
	if param.SortBoostFlag==3 || param.SortBoostFlag==4 {
		param.SortBoostFlag=0
		param.OrderByFieldArray=[]string{"boost"}
		param.OrderByIsDESCArray=[]bool{true}
	}
	//endregion



	return param
}
//endregion

//region 校验返回字段值是否有效
func (this *SearchRule) CheckCarReturnFieldIsValid(param *pb.SearchCondition,fieldname string) bool {
	arrInvlidReturnField:=[]string{"fullinfo","cartitleinfo","cartitlefullinfo"}
	return !objSearchTool.CheckSliceContainString(arrInvlidReturnField,fieldname)
}
//endregion

//region 校验CPL检索传入参数是否合法，并初始化默认参数值--车源索引-CPL检索
func (this *SearchRule) CheckParameters_CPL(param *pb.SearchCondition,indexname string) (p *pb.SearchCondition, r bool, errmsg string) {
	//常规参数校验
	param, r, errmsg =this.CheckParameters(param,indexname)

	//region 校验ReturnField，需包含排序字段
	if len(param.OrderByFieldArray)>0 && len(param.OrderByFieldArray)==len(param.OrderByIsDESCArray){
		for _,fieldname:=range param.OrderByFieldArray{
			if !objSearchTool.CheckSliceContainString(param.ReturnFieldArray,fieldname){
				param.ReturnFieldArray=append(param.ReturnFieldArray,fieldname)
			}
		}
	}
	//endregion

	return param, r, errmsg
}
//endregion

//region 判断是否启用本地缓存
func (this *SearchRule) CheckIsLocalCache(param *pb.SearchCondition,indexname string) (iscache bool,cachekey string) {
	iscache=false
	if tools.MyConfigHelper.ConfigCentor().ES_LocalCacheExpire>0{
		if strings.Contains(indexname,","){
			iscache=true
		}else if param.AggrFieldList!=nil && len(param.AggrFieldList)>0 {
			iscache=true
		}
		if iscache{
			md5Ctx := md5.New()
			md5Ctx.Write([]byte(fmt.Sprintf("%v", param)))
			cachekey=hex.EncodeToString(md5Ctx.Sum(nil))
		}
	}
	return iscache,cachekey
}
//endregion
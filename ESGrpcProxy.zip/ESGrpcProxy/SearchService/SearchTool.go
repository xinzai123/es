package ESGoServer

import (
	"strings"
	pb "../grpc"
)

/*
功能：搜索相关工具方法
 */

type SearchTool struct {
}

//region 转换颜色字符串为标准颜色值
func (this *SearchTool) GetStandardColor(sourcecolor string) (r string) {
	sourcecolor=strings.TrimRight(sourcecolor,"色")
	arrColorTitle := []string{ "黑", "白", "红", "蓝", "银灰", "深灰", "银", "灰", "金", "香槟", "绿", "黄", "橙", "紫", "棕", "咖啡", "多彩" }
	arrColorValue := []string{ "黑", "白", "红", "蓝", "银灰", "深灰", "银", "灰", "香槟", "香槟", "绿", "黄", "橙", "紫", "咖啡", "咖啡", "多彩" }
	for i := 0; i < len(arrColorTitle); i++ {
		if FindStr(sourcecolor, arrColorTitle[i], false) != -1 {
			return arrColorValue[i]
		}
	}
	return sourcecolor
}
//endregion

//region 检查slice中是否包含某值
func (this *SearchTool) CheckSliceContain(arr []int32,val int32) (r bool) {
	if arr==nil || len(arr)==0{
		return false
	}
	for i := 0; i < len(arr); i++ {
		if arr[i]==val{
			return true
		}
	}
	return false
}

func (this *SearchTool) CheckSliceContainInt(arr []int,val int) (r bool) {
	if arr==nil || len(arr)==0{
		return false
	}
	for i := 0; i < len(arr); i++ {
		if arr[i]==val{
			return true
		}
	}
	return false
}

func (this *SearchTool) CheckSliceContainString(arr []string,val string) (r bool) {
	if arr==nil || len(arr)==0{
		return false
	}
	for i := 0; i < len(arr); i++ {
		if strings.ToLower(arr[i])==strings.ToLower(val) {
			return true
		}
	}
	return false
}
//endregion

//region 将价格区间枚举值转换为价格数组
func (this *SearchTool) GetPriceRange(index int32)[]float32{
	var arrprice []float32
	switch index {
	case 1:
		arrprice=[]float32{0.0,3.0}
		break
	case 2:
		arrprice=[]float32{3.0,5.0}
		break
	case 3:
		arrprice=[]float32{5.0,8.0}
		break
	case 4:
		arrprice=[]float32{8.0,10.0}
		break
	case 5:
		arrprice=[]float32{10.0,15.0}
		break
	case 6:
		arrprice=[]float32{15.0,20.0}
		break
	case 7:
		arrprice=[]float32{20.0,30.0}
		break
	case 8:
		arrprice=[]float32{30.0,50.0}
		break
	case 9:
		arrprice=[]float32{50.0,100.0}
		break
	case 10:
		arrprice=[]float32{100.0,9999.0}
		break
	default:
		//异常值，返回全区间
		arrprice=[]float32{0.0,9999.0}
		break
	}
	return arrprice
}
//func (this *SearchTool) GetPriceRange(index int32)[]string{
//	var arrprice []string
//	switch index {
//	case 1:
//		arrprice=[]string{"0.0","3.0"}
//		break
//	case 2:
//		arrprice=[]string{"3.0","5.0"}
//		break
//	case 3:
//		arrprice=[]string{"5.0","8.0"}
//		break
//	case 4:
//		arrprice=[]string{"8.0","10.0"}
//		break
//	case 5:
//		arrprice=[]string{"10.0","15.0"}
//		break
//	case 6:
//		arrprice=[]string{"15.0","20.0"}
//		break
//	case 7:
//		arrprice=[]string{"20.0","30.0"}
//		break
//	case 8:
//		arrprice=[]string{"30.0","50.0"}
//		break
//	case 9:
//		arrprice=[]string{"50.0","100.0"}
//		break
//	case 10:
//		arrprice=[]string{"100.0","9999.0"}
//		break
//	default:
//		//异常值，返回全区间
//		arrprice=[]string{"0.0","9999.0"}
//		break
//	}
//	return arrprice
//}
//endregion

//region 字符串sep在字符串s中的索引位置,ignoreCase表示是否忽略大小写
func (this *SearchTool) FindStr(s string, sep string, ignoreCase bool) int {

	n := len(sep)
	if n == 0 {
		return 0
	}

	//to Lower
	if ignoreCase == true {
		s = strings.ToLower(s)
		sep = strings.ToLower(sep)
	}

	c := sep[0]
	if n == 1 {
		// special case worth making fast
		for i := 0; i < len(s); i++ {
			if s[i] == c {
				return i
			}
		}
		return -1
	}
	// n > 1
	for i := 0; i+n <= len(s); i++ {
		if s[i] == c && s[i:i+n] == sep {
			return i
		}
	}
	return -1
}
//endregion


//region 根据自定义排序条件合并车源列表
func (this *SearchTool) MergeCarListWithSortField(list1 []*pb.DTOCarInfoIndexField,list2 []*pb.DTOCarInfoIndexField,param *pb.SearchCondition)[]*pb.DTOCarInfoIndexField{
	//自定义排序：价格、里程、车龄、刷新时间
	mergeList := make([]*pb.DTOCarInfoIndexField,0)
	i1,i2:=0,0
	var (
		compareresult int
		tempvalue_int32_1 int32
		tempvalue_int32_2 int32
		tempvalue_float64_1 float64
		tempvalue_float64_2 float64
		tempvalue_string_1 string
		tempvalue_string_2 string
		car1 *pb.DTOCarInfoIndexField=nil
		car2 *pb.DTOCarInfoIndexField=nil
	)
	for{
		if car1==nil && i1<len(list1){
			car1=list1[i1]
		}
		if car2==nil && i2<len(list2){
			car2=list2[i2]
		}
		if car1!=nil && car2!=nil{
			for i,sortfieldname:=range param.OrderByFieldArray {
				//region 根据排序字段比较当前两个car的大小
				switch strings.ToLower(sortfieldname) {
				case "status":
					tempvalue_int32_1 = car1.status
					tempvalue_int32_2 = car2.status
					compareresult = objSearchTool.CompareInt32(tempvalue_int32_1, tempvalue_int32_2, param.OrderByIsDESCArray[i])
					break
				case "displayprice":
					tempvalue_float64_1 = car1.Displayprice
					tempvalue_float64_2 = car2.Displayprice
					compareresult = objSearchTool.CompareFloat64(tempvalue_float64_1, tempvalue_float64_2, param.OrderByIsDESCArray[i])
					break
				case "buycardate":
					tempvalue_string_1 = car1.Buycardate
					tempvalue_string_2 = car2.Buycardate
					compareresult = objSearchTool.CompareString(tempvalue_string_1, tempvalue_string_2, param.OrderByIsDESCArray[i])
					break
				case "color":
					tempvalue_string_1 = car1.Color
					tempvalue_string_2 = car2.Color
					compareresult = objSearchTool.CompareString(tempvalue_string_1, tempvalue_string_2, param.OrderByIsDESCArray[i])
					break
				}
				//endregion
			}
		}else if car1!=nil{
			compareresult=1
		}else if car2!=nil{
			compareresult=-1
		}else{
			//car1和car2均为nil，跳出
			break
		}
		//region 根据car大小拼接最终返回对接集合
		if compareresult==1{
			//优先取car1
			mergeList=append(mergeList,car1)
			i1++
			car1=nil
		}else{
			//优先取car2
			mergeList=append(mergeList,car2)
			i2++
			car2=nil
		}
		//endregion
	}

	return mergeList
}
//endregion

//region 根据排序方式（正序&倒序）比较两个int32值大小
func (this *SearchTool) CompareInt32(val1 int32,val2 int32,isdesc bool)int{
	ret:=0
	if val1>val2{
		//car1值大
		if isdesc{
			ret=1
		}else{
			ret=-1
		}
	}else if val1<val2{
		//car1值小
		if !isdesc{
			ret=1
		}else{
			ret=-1
		}
	}else{
		//等值，继续下一个排序字段
		ret=0
	}
	return ret
}
//endregion

//region 根据排序方式（正序&倒序）比较两个int64值大小
func (this *SearchTool) CompareInt64(val1 int64,val2 int64,isdesc bool)int{
	ret:=0
	if val1>val2{
		//car1值大
		if isdesc{
			ret=1
		}else{
			ret=-1
		}
	}else if val1<val2{
		//car1值小
		if !isdesc{
			ret=1
		}else{
			ret=-1
		}
	}else{
		//等值，继续下一个排序字段
		ret=0
	}
	return ret
}
//endregion

//region 根据排序方式（正序&倒序）比较两个float64值大小
func (this *SearchTool) CompareFloat64(val1 float64,val2 float64,isdesc bool)int{
	ret:=0
	if val1>val2{
		//car1值大
		if isdesc{
			ret=1
		}else{
			ret=-1
		}
	}else if val1<val2{
		//car1值小
		if !isdesc{
			ret=1
		}else{
			ret=-1
		}
	}else{
		//等值，继续下一个排序字段
		ret=0
	}
	return ret
}
//endregion

//region 根据排序方式（正序&倒序）比较两个string值大小
func (this *SearchTool) CompareString(val1 string,val2 string,isdesc bool)int{
	ret:=strings.Compare(val1,val2)
	if isdesc{
		ret=ret*-1
	}
	return ret
}
//endregion
package Test5

import (
	"testing"
	"../SearchService"
	pb "../grpc"
	"fmt"
	"time"
	"strconv"
	"strings"
)

var objSearchService = new(ESGoServer.SearchServiceClient_V5)
var objSearchRule = new(ESGoServer.SearchRule)

//region 车源ID数组
func Test_IdArray(t *testing.T) {
	var functitle="Test_IdArray"
	var param=GetBaseParam()
	var initData=GetInitData()
	var id=initData.CarList[0].id

	if id<=0{
		t.Errorf("Error:%s:Invalid InitParam:%q,Count:%q",functitle,id,initData.Count)
	}
	param.IdArray=[]int32{id}
	param.ReturnFieldArray=[]string{"id"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].id!=id{
			t.Errorf("Error:%s:Invalid Data:Id:%q",functitle,ret.CarList[i].id,ret.CarList[i].Carsource1L)
		}
	}
}
//endregion

//region 排除车源ID数组
func Test_NoIdArray(t *testing.T) {
	var functitle="Test_NoIdArray"
	var param=GetBaseParam()
	var initData=GetInitData()
	var id=initData.CarList[0].id
	param.NoIdArray=[]int32{id}
	param.ReturnFieldArray=[]string{"id"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
		fmt.Println(ret.RequestParametersLog)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].id==id{
			t.Errorf("Error:%s:Invalid Data:Id:%d",functitle,id)
		}
	}
}
//endregion

//是否认证车
func Test_IsAuthenticated(t *testing.T) {
	var functitle="Test_IsAuthenticated"
	var param=GetBaseParam()
	param.IsAuthenticated=1
	param.ReturnFieldArray=[]string{"id","isauthenticated"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Isauthenticated!=1{
			t.Error("Error:%s:Invalid Data:Id:%d,Isauthenticated:%d",functitle,ret.CarList[i].id,ret.CarList[i].Isauthenticated)
		}
	}
}

//车源编号数组
func Test_SerialNumberArray(t *testing.T) {
	var functitle="Test_SerialNumberArray"
	var param=GetBaseParam()
	var initData=GetInitData()
	var serialnumber=initData.CarList[0].serialnumber
	if serialnumber==""{
		t.Errorf("Error:%s:Invalid InitParam:%s,Count:%q",functitle,serialnumber,initData.Count)
	}
	param.SerialNumberArray=[]string{serialnumber}
	param.ReturnFieldArray=[]string{"id","serialnumber"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].serialnumber!=serialnumber{
			t.Errorf("Error:%s:Invalid Data:Id:%q,",functitle,ret.CarList[i].id,ret.CarList[i].serialnumber)
		}
	}
}

//region 多颜色
func Test_MultiColorArray(t *testing.T) {
	var functitle="Test_MultiColorArray"
	var param=GetBaseParam()
	param.PageSize=200
	param.ColorArray=[]string{"红","黑"}
	param.ReturnFieldArray=[]string{"id","color"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Color!="红" && ret.CarList[i].Color!="黑"{
			t.Errorf("Error:%s:Invalid Data:Id:%q,",functitle,ret.CarList[i].id,ret.CarList[i].Color)
		}
	}
}
//endregion

//region 单颜色
func Test_SingleColorArray(t *testing.T) {
	var functitle="Test_SingleColorArray"
	var param=GetBaseParam()
	param.PageSize=200
	param.ColorArray=[]string{"红"}
	param.ReturnFieldArray=[]string{"id","color"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Color!="红"{
			t.Errorf("Error:%s:Invalid Data:Id:%q,",functitle,ret.CarList[i].id,ret.CarList[i].Color)
		}
	}
}
//endregion


//是否可跨区，即是否可售外地
func Test_Source(t *testing.T) {
	var functitle="Test_Source"
	var param=GetBaseParam()
	param.Source=1
	param.ReturnFieldArray=[]string{"id","source"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Source!=1{
			t.Error("Error:%s:Invalid Data:Id:%d,Source:%d",functitle,ret.CarList[i].id,ret.CarList[i].Source)
		}
	}
}

//车辆来源：个人、商家
func Test_CarSource1l(t *testing.T) {
	var functitle="Test_Source"
	var param=GetBaseParam()
	param.CarSource1L=1
	param.ReturnFieldArray=[]string{"id","carsource1l"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Carsource1L!=1{
			t.Errorf("Error:"+functitle+":Invalid Data:Id:"+strconv.Itoa(int(ret.CarList[i].id))+","+strconv.Itoa(int(ret.CarList[i].Carsource1L)))
		}
	}
}

//是否有图：1为有图
func Test_PictureCount(t *testing.T) {
	var functitle="Test_PictureCount"
	var param=GetBaseParam()
	param.PictureCount=1
	param.ReturnFieldArray=[]string{"id","picturenumber"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Picturenumber<1{
			t.Errorf("Error:%s:Invalid Data:Id:%d:%d",functitle,ret.CarList[i].id,ret.CarList[i].Picturenumber)
		}
	}
}

//排除城市ID数组
func Test_NoCityIdArray(t *testing.T) {
	var functitle="Test_NoCityIdArray"
	var param=GetBaseParam()
	param.NoCityIdArray=[]int32{201}
	param.ReturnFieldArray=[]string{"id","carcityid"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Carcityid==201{
			t.Errorf("Error:%s:Invalid Data:Id:%d",functitle,ret.CarList[i].id)
		}
	}
}

//价格区间-单区间
func Test_Price(t *testing.T) {
	var functitle="Test_Price"
	var param=GetBaseParam()
	param.PriceHighArray=[]float64{7.0}
	param.PriceLowerArray=[]float64{3.0}
	param.ReturnFieldArray=[]string{"id","displayprice"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Displayprice<3.0 || ret.CarList[i].Displayprice>7.0{
			t.Errorf("Error:%s:Invalid Data:Id:%d:%d",functitle,ret.CarList[i].id,ret.CarList[i].Displayprice)
		}
	}
}
//价格区间-多区间
func Test_Price_Multi(t *testing.T) {
	var functitle="Test_Price"
	var param=GetBaseParam()
	param.PriceHighArray=[]float64{7.0,15.0}
	param.PriceLowerArray=[]float64{3.0,14.0}
	param.ReturnFieldArray=[]string{"id","displayprice"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if !((ret.CarList[i].Displayprice>=3.0 && ret.CarList[i].Displayprice<=7.0) || (ret.CarList[i].Displayprice>=14.0 && ret.CarList[i].Displayprice<=15.0)){
			t.Errorf("Error:%s:Invalid Data:Id:%d:%d",functitle,ret.CarList[i].id,ret.CarList[i].Displayprice)
		}
	}
}

//厂商指导价区间
func Test_CarReferprice(t *testing.T) {
	var functitle="Test_CarReferprice"
	var param=GetBaseParam()
	param.CPriceHighArray=[]float64{10.0}
	param.CPriceLowerArray=[]float64{3.0}
	param.ReturnFieldArray=[]string{"id","carreferprice"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Carreferprice<3.0 || ret.CarList[i].Carreferprice>10.0{
			t.Errorf("Error:%s:Invalid Data:Id:%d:%f",functitle,ret.CarList[i].id,ret.CarList[i].Carreferprice)
		}
	}
}

//B2B串车价格区间
func Test_B2BPrice(t *testing.T) {
	var functitle="Test_B2BPrice"
	var param=GetBaseParam()
	param.B2BPriceHighArray=[]float64{27.0}
	param.B2BPriceLowerArray=[]float64{3.0}
	param.ReturnFieldArray=[]string{"id","b2bprice"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].B2Bprice<3.0 || ret.CarList[i].B2Bprice>27.0{
			t.Errorf("Error:%s:Invalid Data:Id:%d:%d",functitle,ret.CarList[i].id,ret.CarList[i].B2Bprice)
		}
	}
}

//车龄区间
func Test_CarAge(t *testing.T) {
	var functitle="Test_CarAge"
	var param=GetBaseParam()
	param.CarAgeHighArray=[]int32{3};
	param.CarAgeLowerArray=[]int32{1}
	param.ReturnFieldArray=[]string{"id","buycardate"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	var dtStart,dtEnd,dtCur time.Time
	dtStart,_=time.Parse("2006-01-02",(time.Now().AddDate(-3,0,0).Format("\"2006-01") + "-01T00:00:00\""))
	dtEnd,_ = time.Parse("2006-01-02",(time.Now().AddDate(-1,0,0).Format("\"2006-01") + "-01T00:00:00\""))
	for i:=0;i<len(ret.CarList);i++{
		dtCur,_=time.Parse("2006-01-02",ret.CarList[i].Buycardate)
		if dtCur.Before(dtStart) || dtCur.After(dtEnd){
			t.Errorf(strconv.Itoa(i)+":Error:%s:Invalid Data:Id:%d,"+dtCur.Format("\"2006-01-02")+"|"+dtStart.Format("\"2006-01-02")+","+dtEnd.Format("\"2006-01-02"),functitle,ret.CarList[i].id)
		}
	}
}

//排气量自定义区间
func Test_ExhaustLevel(t *testing.T) {
	var functitle="Test_ExhaustLevel"
	var param=GetBaseParam()
	param.ExhaustLevelLowerArray=[]float64{1.0}
	param.ExhaustLevelHighArray=[]float64{1.6}
	param.ReturnFieldArray=[]string{"id","exhaustvalue"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Exhaustvalue<1.0 || ret.CarList[i].Exhaustvalue>1.6{
			t.Errorf("Error:%s:Invalid Data:Id:%d:%d",functitle,ret.CarList[i].id,ret.CarList[i].Exhaustvalue)
		}
	}
}

//排气量枚举值
func Test_ExhaustValue(t *testing.T) {
	var functitle="Test_ExhaustValue"
	var param=GetBaseParam()
	param.ExhaustLevelArray=[]int32{3}
	param.ReturnFieldArray=[]string{"id","exhaustvalue"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Exhaustvalue<1.6 || ret.CarList[i].Exhaustvalue>2.0{
			t.Errorf("Error:%s:Invalid Data:Id:%d:%d",functitle,ret.CarList[i].id,ret.CarList[i].Exhaustvalue)
		}
	}
}

//行驶里程区间
func Test_DrivingMileage(t *testing.T) {
	var functitle="Test_DrivingMileage"
	var param=GetBaseParam()
	param.DrivingMileageHighArray=[]int32{3}
	param.DrivingMileageLowerArray=[]int32{1}
	param.ReturnFieldArray=[]string{"id","drivingmileage"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Drivingmileage<10000 || ret.CarList[i].Drivingmileage>30000{
			t.Errorf("Error:%s:Invalid Data:Id:%d:%d",functitle,ret.CarList[i].id,ret.CarList[i].Drivingmileage)
		}
	}
}

//国别数组
func Test_Country(t *testing.T) {
	var functitle="Test_Country"
	var param=GetBaseParam()
	param.CountryArray=[]int32{8}
	param.ReturnFieldArray=[]string{"id","country"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Country!="日本"{
			t.Errorf("Error:%s:Invalid Data:Id:%d,CarSource1l:%d",functitle,ret.CarList[i].id,ret.CarList[i].Country)
		}
	}
}

//用户ID数组
func Test_UserId(t *testing.T) {
	var functitle="Test_UserId"
	var param=GetBaseParam()
	var initData=GetInitData()
	tempid:=initData.CarList[0].Userid
	param.UserIdArray=[]int32{tempid}
	param.ReturnFieldArray=[]string{"id","userid"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Userid!=tempid{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Userid)
		}
	}
}

//排除用户ID数组
func Test_NoUserId(t *testing.T) {
	var functitle="Test_NoUserId"
	var param=GetBaseParam()
	var initData=GetInitData()
	tempid:=initData.CarList[0].Userid
	param.NoUserIdArray=[]int32{tempid}
	param.ReturnFieldArray=[]string{"id","userid"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Userid==tempid{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Userid)
		}
	}
}

//上级厂商ID
func Test_SuperiorId(t *testing.T) {
	var functitle="Test_SuperiorId"
	var param=GetBaseParam()
	param.SuperiorId=40
	param.ReturnFieldArray=[]string{"id","superiorid"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Superiorid!=40{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Superiorid)
		}
	}
}

//品牌属性数组
func Test_BrandAttr(t *testing.T) {
	var functitle="Test_BrandAttr"
	var param=GetBaseParam()
	param.BrandAttrArray=[]int32{2}
	param.ReturnFieldArray=[]string{"id","brandattr"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Brandattr!=2{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Brandattr)
		}
	}
}

//车辆来源
func Test_UserType(t *testing.T) {
	var functitle="Test_UserType"
	var param=GetBaseParam()
	param.UserType=1
	param.ReturnFieldArray=[]string{"id","usertype"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Usertype!=1{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Usertype)
		}
	}
}

//审核状态
func Test_IsNeglect(t *testing.T) {
	var functitle="Test_IsNeglect"
	var param=GetBaseParam()
	param.IsNeglect=1
	param.ReturnFieldArray=[]string{"id","isneglect"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Isneglect!=1{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Isneglect)
		}
	}
}

//是否首图合格
func Test_IsFirstPicTrue(t *testing.T) {
	var functitle="Test_IsFirstPicTrue"
	var param=GetBaseParam()
	param.IsFirstPicTrue=1
	param.ReturnFieldArray=[]string{"id","firstpictrue"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Firstpictrue!=1{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Firstpictrue)
		}
	}
}

//是否商家推荐车源
func Test_IsDealerRecommend(t *testing.T) {
	var functitle="Test_IsDealerRecommend"
	var param=GetBaseParam()
	param.IsDealerRecommend=1
	param.ReturnFieldArray=[]string{"id","isdealerrecommend"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Isdealerrecommend!=1{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Isdealerrecommend)
		}
	}
}

//车源来源类型
func Test_CarSourceType(t *testing.T) {
	var functitle="Test_CarSourceType"
	var param=GetBaseParam()
	param.CarSourceTypeArray=[]int32{2}
	param.ReturnFieldArray=[]string{"id","cartype"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Cartype!=2{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Cartype)
		}
	}
}

//车型年款数组
func Test_CarYear(t *testing.T) {
	var functitle="Test_CarYear"
	var param=GetBaseParam()
	param.CarYearArray=[]string{"2014"}
	param.ReturnFieldArray=[]string{"id","caryear"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Caryear!=2014{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Caryear)
		}
	}
}

//车辆配置数组
func Test_CarTypeConfig(t *testing.T) {
	var functitle="Test_CarTypeConfig"
	var param=GetBaseParam()
	param.CarSource1L=2
	param.CityIdArray=[]int32{201}
	param.CarTypeConfig=[]int32{ 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
	param.ReturnFieldArray=[]string{"id","cartypeconfig"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		rs := []rune(ret.CarList[i].Cartypeconfig)
		if string(rs[0])!="1" || string(rs[1])!="1" || string(rs[2])!="1" || string(rs[3])!="1" {
			t.Errorf("Error:"+functitle+":Invalid Data:Id:"+strconv.Itoa(int(ret.CarList[i].id))+","+ret.CarList[i].Cartypeconfig)
		}
	}
}

//是否豪华车源
//func Test_IsRecommendGL(t *testing.T) {
//	var functitle="Test_IsRecommendGL"
//	var param=GetBaseParam()
//	param.IsRecommendGL=1
//	param.ReturnFieldArray=[]string{"id","isrecommendgl"}
//	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
//	if err != nil {
//		t.Errorf("Error:%s:Exception:%s",functitle,err)
//	}
//	if ret==nil{
//		t.Errorf("Error:%s:ret=nil",functitle)
//	}
//	if ret.Count<=0 || len(ret.CarList)<=0{
//		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
//	}
//	for i:=0;i<len(ret.CarList);i++{
//		if ret.CarList[i].Isrecommendgl!=1{
//			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Isrecommendgl)
//		}
//	}
//}

//是否保障车
func Test_IsWarranty(t *testing.T) {
	var functitle="Test_IsWarranty"
	var param=GetBaseParam()
	param.IsWarranty=1
	param.ReturnFieldArray=[]string{"id","iswarranty"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Iswarranty!=1{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Iswarranty)
		}
	}
}

//保障服务类型
func Test_WarrantyType(t *testing.T) {
	var functitle="Test_WarrantyType"
	var param=GetBaseParam()
	param.CarSource1L=2
	param.WarrantyTypeArray=[]int32{ 1, 0, 1 };
	param.ReturnFieldArray=[]string{"id","warrantytypes"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		rs := []rune(ret.CarList[i].Warrantytypes)
		if string(rs[0])!="1" || string(rs[2])!="1" {
			t.Errorf("Error:"+functitle+":Invalid Data:Id:"+strconv.Itoa(int(ret.CarList[i].id))+","+ret.CarList[i].Warrantytypes)
		}
	}
}

//是否置顶车源
func Test_IsTop(t *testing.T) {
	var functitle="Test_IsTop"
	var param=GetBaseParam()
	param.IsTop=0
	param.ReturnFieldArray=[]string{"id","istop"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Istop!=0{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Istop)
		}
	}
}

//是否参加特定活动车源
//func Test_IsActivity(t *testing.T) {
//	var functitle="Test_IsActivity"
//	var param=GetBaseParam()
//	param.IsActivity=1
//	param.ReturnFieldArray=[]string{"id","isactivity"}
//	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
//	if err != nil {
//		t.Errorf("Error:%s:Exception:%s",functitle,err)
//	}
//	if ret==nil{
//		t.Errorf("Error:%s:ret=nil",functitle)
//	}
//	if ret.Count<=0 || len(ret.CarList)<=0{
//		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
//	}
//	for i:=0;i<len(ret.CarList);i++{
//		if ret.CarList[i].Isactivity!=1{
//			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Istop)
//		}
//	}
//}

//是否帮买车源
func Test_IsBangmai(t *testing.T) {
	var functitle="Test_IsBangmai"
	var param=GetBaseParam()
	param.IsBangmai=0
	param.ReturnFieldArray=[]string{"id","isbangmai"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Isbangmai!=0{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Isbangmai)
		}
	}
}

//是否显示维保记录
func Test_IsShowMr(t *testing.T) {
	var functitle="Test_IsShowMr"
	var param=GetBaseParam()
	param.IsShowMr=1
	param.ReturnFieldArray=[]string{"id","isshowmr"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Isshowmr!=1{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Isshowmr)
		}
	}
}

//是否有车型ID-车型ID大于0
func Test_IsCarId(t *testing.T) {
	var functitle="Test_IsCarId"
	var param=GetBaseParam()
	param.IsCarId=1
	param.ReturnFieldArray=[]string{"id","carid"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Carid<=0{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Carid)
		}
	}
}

//是否B2B串车车源
func Test_IsB2B(t *testing.T) {
	var functitle="Test_IsB2B"
	var param=GetBaseParam()
	param.IsB2B=1
	param.ReturnFieldArray=[]string{"id","isb2b"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Isb2B!=1{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Isb2B)
		}
	}
}

//-----------------------------------------------------------------------------------------------------------------
//2.1.2 车型相关查询条件
//车辆级别数组：一级级别
func Test_CarLevel(t *testing.T) {
	var functitle="Test_CarLevel"
	var param=GetBaseParam()
	param.CarLevelArray=[]int32{2}
	param.ReturnFieldArray=[]string{"id","carlevelvalue"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Carlevelvalue!=2{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Carlevelvalue)
		}
	}
}

//车辆级别数组：二级级别
func Test_CarLevelSecond(t *testing.T) {
	var functitle="Test_CarLevelSecond"
	var param=GetBaseParam()
	param.CarLevelSecondArray=[]int32{2}
	param.ReturnFieldArray=[]string{"id","carlevelsecond"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Carlevelsecond!=2{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Carlevelsecond)
		}
	}
}

//主品牌ID数组
func Test_MainBrand(t *testing.T) {
	var functitle="Test_MainBrand"
	var param=GetBaseParam()
	param.MainBrandArray=[]int32{9}
	param.ReturnFieldArray=[]string{"id","mainbrandid"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Mainbrandid!=9{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Mainbrandid)
		}
	}
}

//品牌ID数组
func Test_Brand(t *testing.T) {
	var functitle="Test_Brand"
	var param=GetBaseParam()
	param.BrandArray=[]int32{20004}
	param.ReturnFieldArray=[]string{"id","producerid"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Producerid!=20004{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Producerid)
		}
	}
}

//车系ID数组
func Test_CarSerial(t *testing.T) {
	var functitle="Test_CarSerial"
	var param=GetBaseParam()
	param.CarSerialArray=[]int32{1905}
	param.ReturnFieldArray=[]string{"id","brandid"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Brandid!=1905{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Brandid)
		}
	}
}

//车型ID数组
func Test_CarId(t *testing.T) {
	var functitle="Test_CarId"
	var param=GetBaseParam()
	var initData=GetInitData()
	var carid =initData.CarList[0].Carid
	param.CarIDArray=[]int32{int32(carid)}
	param.ReturnFieldArray=[]string{"id","carid"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Carid!=carid{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Carid)
		}
	}
}

//变速箱类型
func Test_GearBoxType(t *testing.T) {
	var functitle="Test_GearBoxType"
	var param=GetBaseParam()
	param.GearBoxTypeArray=[]int32{1}
	param.ReturnFieldArray=[]string{"id","gearboxtype"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Gearboxtype!=1{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Gearboxtype)
		}
	}
}

//环保标准
func Test_EnvirStandard(t *testing.T) {
	var functitle="Test_EnvirStandard"
	var param=GetBaseParam()
	param.EnvirStandardArray=[]int32{0,1,0,0,0,0,0,0,0}
	param.ReturnFieldArray=[]string{"id","envirstandard"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{

		if !strings.Contains(ret.CarList[i].Envirstandard,"国3"){
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Envirstandard)
		}
	}
}

//综合工况油耗自定义范围搜索
func Test_Consumption(t *testing.T) {
	var functitle="Test_Consumption"
	var param=GetBaseParam()
	param.ConsumptionLowerArray=[]float64{6.0}
	param.ConsumptionHighArray=[]float64{9.0}
	param.ReturnFieldArray=[]string{"id","consumption"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Consumption<6.0 || ret.CarList[i].Consumption>9.0{
			t.Errorf("Error:%s:Invalid Data:Id:%d:%d",functitle,ret.CarList[i].id,ret.CarList[i].Consumption)
		}
	}
}

//能源类型
func Test_OilType(t *testing.T) {
	var functitle="Test_OilType"
	var param=GetBaseParam()
	var initData=GetInitData()

	var oil int32
	for i:=0;i<len(initData.CarList);i++{
		oil=initData.CarList[i].Oiltype
		if oil>0{
			break
		}
	}
	param.OilTypeArray=[]int32{oil}
	param.ReturnFieldArray=[]string{"id","oiltype"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Oiltype!=oil{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Oiltype)
		}
	}
}

//发动机位置
func Test_EngineLocation(t *testing.T) {
	var functitle="Test_EngineLocation"
	var param=GetBaseParam()
	param.EngineLocationArray=[]int32{0}
	param.ReturnFieldArray=[]string{"id","enginelocation"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Enginelocation!=0{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Enginelocation)
		}
	}
}

//车门数
func Test_BodyDoors(t *testing.T) {
	var functitle="Test_BodyDoors"
	var param=GetBaseParam()
	param.BodyDoorsHighArray=[]int32{4}
	param.BodyDoorsLowerArray=[]int32{4}
	param.ReturnFieldArray=[]string{"id","bodydoors"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Bodydoors!=4{
			t.Errorf("Error:%s:Invalid Data:Id:%d:%d",functitle,ret.CarList[i].id,ret.CarList[i].Bodydoors)
		}
	}
}

//座位数/乘员人数
func Test_SeatNum(t *testing.T) {
	var functitle="Test_SeatNum"
	var param=GetBaseParam()
	param.SeatNumHighArray=[]int32{5}
	param.SeatNumLowerArray=[]int32{4}
	param.ReturnFieldArray=[]string{"id","seatnummin","seatnummax"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle+ret.RequestParametersLog)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Seatnummax<4 || ret.CarList[i].Seatnummin>5{
			t.Errorf("Error:%s:Invalid Data:Id:%d:%d-%d",functitle,ret.CarList[i].id,ret.CarList[i].Seatnummin,ret.CarList[i].Seatnummax)
		}
	}
}

func Test_SeatNum_Multi(t *testing.T) {
	var functitle="Test_SeatNum"
	var param=GetBaseParam()
	param.SeatNumHighArray=[]int32{3,5}
	param.SeatNumLowerArray=[]int32{3,4}
	param.ReturnFieldArray=[]string{"id","seatnummin","seatnummax"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle+ret.RequestParametersLog)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Seatnummax<3 || ret.CarList[i].Seatnummin>5 {
			t.Errorf("Error:%s:Invalid Data:Id:%d:%d-%d",functitle,ret.CarList[i].id,ret.CarList[i].Seatnummin,ret.CarList[i].Seatnummax)
		}
	}
}

//是否旅行版
func Test_IsWagon(t *testing.T) {
	var functitle="Test_IsWagon"
	var param=GetBaseParam()
	param.IsWagon=1
	param.ReturnFieldArray=[]string{"id","iswagon"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Iswagon!=1{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Iswagon)
		}
	}
}

//驱动方式
func Test_DriveType(t *testing.T) {
	var functitle="Test_DriveType"
	var param=GetBaseParam()
	param.DriveTypeArray=[]int32{2,3,4}
	param.ReturnFieldArray=[]string{"id","drivetype"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Drivetype<2{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Drivetype)
		}
	}
}

//车身形式
func Test_CsBodyForm(t *testing.T) {
	var functitle="Test_CsBodyForm"
	var param=GetBaseParam()
	param.CsBodyFormArray=[]int32{0}
	param.ReturnFieldArray=[]string{"id","csbodyform"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Csbodyform!=0{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Csbodyform)
		}
	}
}

//客户编号
func Test_CrmCustomerId(t *testing.T) {
	var functitle="Test_CrmCustomerId"
	var param=GetBaseParam()
	var initData=GetInitData()
	cusid:=initData.CarList[0].Crmcustomerid
	param.CrmCustomerIdArray=[]int32{cusid}
	param.ReturnFieldArray=[]string{"id","crmcustomerid"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Crmcustomerid!=cusid{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Crmcustomerid)
		}
	}
}

//是否Json车检报告
func Test_IsCheckReportJson(t *testing.T) {
	var functitle="Test_IsCheckReportJson"
	var param=GetBaseParam()
	param.IsCheckReportJson=1
	param.ReturnFieldArray=[]string{"id","ischeckreportjson"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Ischeckreportjson!=1{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Ischeckreportjson)
		}
	}
}

//是否未上牌
func Test_IsLicensed(t *testing.T) {
	var functitle="Test_IsLicensed"
	var param=GetBaseParam()
	param.IsLicensed=-1
	param.ReturnFieldArray=[]string{"id","islicensed"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Islicensed!=0{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Islicensed)
		}
	}
}

//车源优惠/超值系数区间检索
func Test_CarBenefitRate(t *testing.T) {
	var functitle="Test_CarBenefitRate"
	var param=GetBaseParam()
	param.CarBenefitRateHigh=0.4
	param.CarBenefitRateLower=0.1
	param.ReturnFieldArray=[]string{"id","carbenefitrate"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0|"+ret.RequestParametersLog,functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Carbenefitrate<=0.1 || ret.CarList[i].Carbenefitrate>0.4{
			t.Errorf("Error:%s:Invalid Data:Id:%d:%f|"+ret.RequestParametersLog,functitle,ret.CarList[i].id,ret.CarList[i].Carbenefitrate)
		}
	}
}

//车源优惠/超值系数区间检索
func Test_CarBenefitRate1(t *testing.T) {
	var functitle="Test_CarBenefitRate1"
	var param=GetBaseParam()
	param.CarBenefitRateHigh=0.4
	param.CarBenefitRateLower=0
	param.ReturnFieldArray=[]string{"id","carbenefitrate"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0|"+ret.RequestParametersLog,functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Carbenefitrate>0.4{
			t.Errorf("Error:%s:Invalid Data:Id:%d:%f|"+ret.RequestParametersLog,functitle,ret.CarList[i].id,ret.CarList[i].Carbenefitrate)
		}
	}
}


//距离检索
func Test_DistanceKm(t *testing.T) {
	var functitle="Test_DistanceKm"
	var param=GetBaseParam()
	param.CarSource1L=2
	param.DistanceKm=100
	param.Location="116.403909,39.913994"
	param.ReturnFieldArray=[]string{"id","baidumap","userid","distance"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		fmt.Println(ret.RequestParametersLog)
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Distance<=0{
			t.Errorf("Error:%s:Invalid Data:Id:%d,%d",functitle,ret.CarList[i].id,ret.CarList[i].Distance)
		}
	}
}



func GetBaseParam()(p *pb.SearchCondition){
	//param := new(pb.SearchCondition)
	var param pb.SearchCondition
	param.RequestParametersLog="get"
	param.ReturnFieldArray=[]string{"id"}
	param.RequestSource=9
	param.StatusArray=[]int32{1}
	param.CommonFlag=0
	param.PageIndex=1
	param.PageSize=20
	param.RequestParametersLog="get"
	return &param
}

func GetInitData()(ret *pb.SearchResult){
	var param=GetBaseParam()
	param.CarSource1L=2
	param.ReturnFieldArray=[]string{"id","serialnumber","userid","carid","oiltype","crmcustomerid"}
	var retInit,err=objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err!=nil{
		fmt.Print("Init DataSource failed!",err)
	}
	return retInit
}

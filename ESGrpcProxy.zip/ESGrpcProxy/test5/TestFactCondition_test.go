package Test5

import (
	"testing"
	pb "../grpc"
)


//region 聚合检索
func Test_Aggr_Term(t *testing.T) {
	var functitle="Test_Aggr_Term"
	var param=GetBaseParam()
	param.IsCountSearch=true
	objAggrMainbrandid := &pb.AggrCondition{FieldName:"mainbrandid",AggregationType:1,TopNumber:5,SubKeyFieldArray:[]string{"displayprice_stats","displayprice_min","displayprice_max","displayprice_avg","displayprice_sum"},SubAggrTypeArray:[]string{"stats","min","max","avg","sum"},SubValueFieldArray:[]string{"carid","displayprice","displayprice","displayprice","displayprice"},OrderFieldArray:[]string{"displayprice_max"},OrderTypeArray:[]string{"desc"}}
	//objAggrMainbrandid := &pb.AggrCondition{FieldName:"mainbrandid",AggregationType:1,TopNumber:100}
	objAggrColor := &pb.AggrCondition{FieldName:"color",AggregationType:1,TopNumber:10}
	objAggrBrandid := &pb.AggrCondition{FieldName:"brandid",AggregationType:1,TopNumber:100}
	objAggrCarid := &pb.AggrCondition{FieldName:"carid",AggregationType:1,TopNumber:100}
	objAggrCountryvalue := &pb.AggrCondition{FieldName:"countryvalue",AggregationType:1,TopNumber:20}
	objAggrGearboxtype := &pb.AggrCondition{FieldName:"gearboxtype",AggregationType:1,TopNumber:10}
	objAggrCarlevelsecond := &pb.AggrCondition{FieldName:"carlevelsecond",AggregationType:1,TopNumber:10}
	rangeExhaust:=`{"to": 1,"key": "exhaustvalue_1"},{"from": 1.1,"to": 1.5,"key": "exhaustvalue_2"},{"from": 1.6,"to": 2,"key": "exhaustvalue_3"},{"from": 2.1,"to": 3,"key": "exhaustvalue_4"},{"from": 3.1,"key": "exhaustvalue_5"}`
	objAggrExhaustvalue := &pb.AggrCondition{FieldName:"exhaustvalue",AggregationType:2,TopNumber:0,RangeConfig:rangeExhaust}
	rangeDrivingmileage:=`{"to": 10000,"key": "drivingmileage_1"},{"to": 30000,"key": "drivingmileage_2"},{"to": 50000,"key": "drivingmileage_3"},{"to": 100000,"key": "drivingmileage_4"}`
	objAggrDrivingmileage := &pb.AggrCondition{FieldName:"drivingmileage",AggregationType:2,TopNumber:0,RangeConfig:rangeDrivingmileage}
	rangePrice:=`{"to":3,"key":"displayprice_1"},{"from":3,"to":5,"key":"displayprice_2"},{"from":5,"to":8,"key":"displayprice_3"},{"from":8,"to":10,"key":"displayprice_4"},{"from":10,"to":15,"key":"displayprice_5"},{"from":15,"to":20,"key":"displayprice_6"},{"from":20,"to":30,"key":"displayprice_7"},{"from":30,"to":50,"key":"displayprice_8"},{"from":50,"to":100,"key":"displayprice_9"},{"from":100,"key":"displayprice_10"}`
	objAggrPrice := &pb.AggrCondition{FieldName:"displayprice",AggregationType:2,TopNumber:0,RangeConfig:rangePrice}
	rangeBuycardate:=`{"from":"2015-06-01T00:00:00","key":"buycardate_1"},{"from":"2014-06-01T00:00:00","to":"2015-05-31T00:00:00","key":"buycardate_2"},{"from":"2013-06-01T00:00:00","to":"2014-05-31T00:00:00","key":"buycardate_3"},{"from":"2010-06-01T00:00:00","to":"2013-05-31T00:00:00","key":"buycardate_4"},{"from":"2007-06-01T00:00:00","to":"2010-05-31T00:00:00","key":"buycardate_5"},{"to":"2007-05-31T00:00:00","key":"buycardate_6"}`
	objAggrBuycardate := &pb.AggrCondition{FieldName:"buycardate",AggregationType:2,TopNumber:0,RangeConfig:rangeBuycardate}

	param.AggrFieldList=[]*pb.AggrCondition{objAggrMainbrandid,objAggrColor,objAggrBrandid,objAggrCarid,objAggrCountryvalue,objAggrGearboxtype,objAggrCarlevelsecond,objAggrExhaustvalue,objAggrDrivingmileage,objAggrPrice,objAggrBuycardate}
	param.ReturnFieldArray=[]string{"id","color","brandid","mainbrandid","buycardate","displayprice","drivingmileage","exhaustvalue","carlevelsecond","gearboxtype","countryvalue","carid"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0{
		t.Errorf("Error:%s:ret.Count=0",functitle)
	}
	if len(ret.Facet)<=0{
		t.Errorf("Error:%s:Invalid ret.Facet",functitle)
	}

}
//endregion

package Test5

import (
	"testing"
	"fmt"
	"strconv"
)

//region 自定义评分检索：SortBoostFlag=2  CommonFlag=0
func Test_SortBoostFlag2_CommonFlag0(t *testing.T) {
	var functitle="Test_SortBoostFlag2_CommonFlag0"
	var param=GetBaseParam()
	param.SortBoostFlag=2
	param.CommonFlag=0
	param.IsCountSearch=false
	param.ReturnFieldArray=[]string{"id","score","status","displayprice","boostapp"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0{
		t.Errorf("Error:%s:ret.Count=0",functitle)
	}
	if len(ret.CarList)==0{
		fmt.Println(ret.RequestParametersLog)
		t.Errorf("Error:%s:len(ret.CarList)=0:"+strconv.Itoa(int(ret.Count)),functitle)
	}
	var lastScore float64
	var curScore float64
	for i,car := range ret.CarList{
		curScore=car.Score
		if lastScore>0 && curScore>lastScore{
			//Score校验失败
			fmt.Println(ret.RequestParametersLog)
			t.Errorf("Error:%s:Invalid Score：Current:%d---Score=%f，Last---Score=%f",functitle,i,curScore,lastScore)
		}
	}
}
//endregion

//region 自定义评分检索：SortBoostFlag=2  CommonFlag=1
func Test_SortBoostFlag2_CommonFlag1(t *testing.T) {
	var functitle="Test_SortBoostFlag2_CommonFlag1"
	var param=GetBaseParam()
	param.SortBoostFlag=2
	param.CommonFlag=1
	param.CityIdArray=[]int32{201}
	param.RelateCityArray=[]int32{ 906, 2601, 910, 902, 911 }
	param.ReturnFieldArray=[]string{"id","score"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0{
		t.Errorf("Error:%s:ret.Count=0",functitle)
	}
	if len(ret.CarList)==0{
		fmt.Println(ret.RequestParametersLog)
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	var lastScore float64
	var curScore float64
	for i,car := range ret.CarList{
		curScore=car.Score
		if lastScore>0 && curScore>lastScore{
			//Score校验失败
			fmt.Println(ret.RequestParametersLog)
			t.Errorf("Error:%s:Invalid Score：Current:%d---Score=%f，Last---Score=%f",functitle,i,curScore,lastScore)
		}
	}
}
//endregion

//region 自定义评分检索：SortBoostFlag=2  CommonFlag=4
func Test_SortBoostFlag2_CommonFlag2(t *testing.T) {
	var functitle="Test_SortBoostFlag2_CommonFlag4"
	var param=GetBaseParam()
	param.SortBoostFlag=2
	param.CommonFlag=4
	param.CityIdArray=[]int32{201}
	param.RelateCityArray=[]int32{ 906, 2601, 910, 902, 911 }
	param.ReturnFieldArray=[]string{"id","score"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		fmt.Println(ret.RequestParametersLog)
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0{
		fmt.Println(ret.RequestParametersLog)
		t.Errorf("Error:%s:ret.Count=0",functitle)
	}
	if len(ret.CarList)==0{
		fmt.Println(ret.RequestParametersLog)
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	var lastScore float64
	var curScore float64
	for i,car := range ret.CarList{
		curScore=car.Score
		if lastScore>0 && curScore>lastScore{
			//Score校验失败
			fmt.Println(ret.RequestParametersLog)
			t.Errorf("Error:%s:Invalid Score：Current:%d---Score=%f，Last---Score=%f",functitle,i,curScore,lastScore)
		}
	}
}
//endregion

//region 自定义评分检索：SortBoostFlag=2  CommonFlag=3
func Test_SortBoostFlag2_CommonFlag3(t *testing.T) {
	var functitle="Test_SortBoostFlag2_CommonFlag3"
	var param=GetBaseParam()
	param.SortBoostFlag=2
	param.CommonFlag=3
	param.CityIdArray=[]int32{201}
	param.RelateCityArray=[]int32{ 906, 2601, 910, 902, 911 }
	param.ReturnFieldArray=[]string{"id","score"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		fmt.Println(ret.RequestParametersLog)
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0{
		fmt.Println(ret.RequestParametersLog)
		t.Errorf("Error:%s:ret.Count=0",functitle)
	}
	if len(ret.CarList)==0{
		fmt.Println(ret.RequestParametersLog)
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	var lastScore float64
	var curScore float64
	for i,car := range ret.CarList{
		curScore=car.Score
		if lastScore>0 && curScore>lastScore{
			//Score校验失败
			fmt.Println(ret.RequestParametersLog)
			t.Errorf("Error:%s:Invalid Score：Current:%d---Score=%f，Last---Score=%f",functitle,i,curScore,lastScore)
		}
	}
}
//endregion


//region 自定义评分检索：SortBoostFlag=3  CommonFlag=0
func Test_SortBoostFlag3_CommonFlag0(t *testing.T) {
	var functitle="Test_SortBoostFlag3_CommonFlag0"
	var param=GetBaseParam()
	param.SortBoostFlag=3
	param.CommonFlag=0
	param.ReturnFieldArray=[]string{"id","score"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		fmt.Println(ret.RequestParametersLog)
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0{
		fmt.Println(ret.RequestParametersLog)
		t.Errorf("Error:%s:ret.Count=0",functitle)
	}
	if len(ret.CarList)==0{
		fmt.Println(ret.RequestParametersLog)
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	var lastScore float64
	var curScore float64
	for i,car := range ret.CarList{
		curScore=car.Score
		if lastScore>0 && curScore>lastScore{
			//Score校验失败
			fmt.Println(ret.RequestParametersLog)
			t.Errorf("Error:%s:Invalid Score：Current:%d---Score=%f，Last---Score=%f",functitle,i,curScore,lastScore)
		}
	}
}
//endregion

//region 自定义评分检索：SortBoostFlag=3  CommonFlag=1
func Test_SortBoostFlag3_CommonFlag1(t *testing.T) {
	var functitle="Test_SortBoostFlag3_CommonFlag1"
	var param=GetBaseParam()
	param.SortBoostFlag=3
	param.CommonFlag=1
	param.CityIdArray=[]int32{201}
	param.RelateCityArray=[]int32{ 906, 2601, 910, 902, 911 }
	param.ReturnFieldArray=[]string{"id","score"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		fmt.Println(ret.RequestParametersLog)
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0{
		fmt.Println(ret.RequestParametersLog)
		t.Errorf("Error:%s:ret.Count=0",functitle)
	}
	if len(ret.CarList)==0{
		fmt.Println(ret.RequestParametersLog)
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	var lastScore float64
	var curScore float64
	for i,car := range ret.CarList{
		curScore=car.Score
		if lastScore>0 && curScore>lastScore{
			//Score校验失败
			fmt.Println(ret.RequestParametersLog)
			t.Errorf("Error:%s:Invalid Score：Current:%d---Score=%f，Last---Score=%f",functitle,i,curScore,lastScore)
		}
	}
}
//endregion

//region 自定义评分检索：SortBoostFlag=3  CommonFlag=4
func Test_SortBoostFlag3_CommonFlag2(t *testing.T) {
	var functitle="Test_SortBoostFlag3_CommonFlag4"
	var param=GetBaseParam()
	param.SortBoostFlag=3
	param.CommonFlag=4
	param.CityIdArray=[]int32{201}
	param.RelateCityArray=[]int32{ 906, 2601, 910, 902, 911 }
	param.ReturnFieldArray=[]string{"id","score"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0{
		t.Errorf("Error:%s:ret.Count=0",functitle)
	}
	if len(ret.CarList)==0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	var lastScore float64
	var curScore float64
	for i,car := range ret.CarList{
		curScore=car.Score
		if lastScore>0 && curScore>lastScore{
			//Score校验失败
			t.Errorf("Error:%s:Invalid Score：Current:%d---Score=%f，Last---Score=%f",functitle,i,curScore,lastScore)
		}
	}
}
//endregion

//region 自定义评分检索：SortBoostFlag=3  CommonFlag=3
func Test_SortBoostFlag3_CommonFlag3(t *testing.T) {
	var functitle="Test_SortBoostFlag3_CommonFlag3"
	var param=GetBaseParam()
	param.SortBoostFlag=3
	param.CommonFlag=3
	param.CityIdArray=[]int32{201}
	param.RelateCityArray=[]int32{ 906, 2601, 910, 902, 911 }
	param.ReturnFieldArray=[]string{"id","score"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0{
		t.Errorf("Error:%s:ret.Count=0",functitle)
	}
	if len(ret.CarList)==0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	var lastScore float64
	var curScore float64
	for i,car := range ret.CarList{
		curScore=car.Score
		if lastScore>0   && curScore>lastScore{
			//Score校验失败
			t.Errorf("Error:%s:Score序列异常：第%d个车源Score为%f，上一个车源Score为%f",functitle,i,curScore,lastScore)
		}
	}
}
//endregion


//region 自定义评分检索：SortBoostFlag=4  CommonFlag=0
func Test_SortBoostFlag4_CommonFlag0(t *testing.T) {
	var functitle="Test_SortBoostFlag4_CommonFlag0"
	var param=GetBaseParam()
	param.SortBoostFlag=4
	param.CommonFlag=0
	param.CityIdArray=[]int32{201}
	param.RelateCityArray=[]int32{ 906, 2601, 910, 902, 911 }
	param.ReturnFieldArray=[]string{"id","score"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		fmt.Println(ret.RequestParametersLog)
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0{
		fmt.Println(ret.RequestParametersLog)
		t.Errorf("Error:%s:ret.Count=0",functitle)
	}
	if len(ret.CarList)==0{
		fmt.Println(ret.RequestParametersLog)
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	var lastScore float64
	var curScore float64
	for i,car := range ret.CarList{
		curScore=car.Score
		if lastScore>0 && curScore>lastScore{
			//Score校验失败
			fmt.Println(ret.RequestParametersLog)
			t.Errorf("Error:%s:Invalid Score：Current:%d---Score=%f，Last---Score=%f",functitle,i,curScore,lastScore)
		}
	}
}
//endregion

//region 自定义评分检索：SortBoostFlag=4  CommonFlag=1
func Test_SortBoostFlag4_CommonFlag1(t *testing.T) {
	var functitle="Test_SortBoostFlag4_CommonFlag1"
	var param=GetBaseParam()
	param.SortBoostFlag=4
	param.CommonFlag=1
	param.CityIdArray=[]int32{201}
	param.RelateCityArray=[]int32{ 906, 2601, 910, 902, 911 }
	param.ReturnFieldArray=[]string{"id","score"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		fmt.Println(ret.RequestParametersLog)
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0{
		fmt.Println(ret.RequestParametersLog)
		t.Errorf("Error:%s:ret.Count=0",functitle)
	}
	if len(ret.CarList)==0{
		fmt.Println(ret.RequestParametersLog)
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	var lastScore float64
	var curScore float64
	for i,car := range ret.CarList{
		curScore=car.Score
		if lastScore>0 && curScore>lastScore{
			//Score校验失败
			fmt.Println(ret.RequestParametersLog)
			t.Errorf("Error:%s:Invalid Score：Current:%d---Score=%f，Last---Score=%f",functitle,i,curScore,lastScore)
		}
	}
}
//endregion

//region 自定义评分检索：SortBoostFlag=4  CommonFlag=4
func Test_SortBoostFlag4_CommonFlag2(t *testing.T) {
	var functitle="Test_SortBoostFlag4_CommonFlag4"
	var param=GetBaseParam()
	param.SortBoostFlag=3
	param.CommonFlag=4
	param.CityIdArray=[]int32{201}
	param.RelateCityArray=[]int32{ 906, 2601, 910, 902, 911 }
	param.ReturnFieldArray=[]string{"id","score"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0{
		t.Errorf("Error:%s:ret.Count=0",functitle)
	}
	if len(ret.CarList)==0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	var lastScore float64
	var curScore float64
	for i,car := range ret.CarList{
		curScore=car.Score
		if lastScore>0 && curScore>lastScore{
			//Score校验失败
			t.Errorf("Error:%s:Invalid Score：Current:%d---Score=%f，Last---Score=%f",functitle,i,curScore,lastScore)
		}
	}
}
//endregion

//region 自定义评分检索：SortBoostFlag=4  CommonFlag=3
func Test_SortBoostFlag4_CommonFlag3(t *testing.T) {
	var functitle="Test_SortBoostFlag4_CommonFlag3"
	var param=GetBaseParam()
	param.SortBoostFlag=4
	param.CommonFlag=3
	param.CityIdArray=[]int32{201}
	param.RelateCityArray=[]int32{ 906, 2601, 910, 902, 911 }
	param.ReturnFieldArray=[]string{"id","score"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0{
		t.Errorf("Error:%s:ret.Count=0",functitle)
	}
	if len(ret.CarList)==0{
		t.Errorf("Error:%s:len(ret.CarList)=0"+ret.RequestParametersLog,functitle)
	}
	var lastScore float64
	var curScore float64
	for i,car := range ret.CarList{
		curScore=car.Score
		if lastScore>0   && curScore>lastScore{
			//Score校验失败
			t.Errorf("Error:%s:Score序列异常：第%d个车源Score为%f，上一个车源Score为%f",functitle,i,curScore,lastScore)
		}
	}
}
//endregion



//region 自定义评分检索：SortBoostFlag=4，默认排序
func Test_SortBoostFlag4_DefaultSort(t *testing.T) {
	var functitle="Test_SortBoostFlag4_DefaultSort"
	var param=GetBaseParam()
	param.SortBoostFlag=4
	param.CommonFlag=0
	param.CityIdArray=[]int32{201}
	param.RelateCityArray=[]int32{ 906, 2601, 910, 902, 911 }
	param.OrderByFieldArray=[]string{"status","boost"}
	param.OrderByIsDESCArray=[]bool{false,true}
	param.ReturnFieldArray=[]string{"id","score"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0{
		t.Errorf("Error:%s:ret.Count=0",functitle)
	}
	if len(ret.CarList)==0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	if param.SortBoostFlag==0{
		t.Errorf("Error:%s:Not default sort,SortBoostFlag=0",functitle)
	}
	var lastScore float64
	var curScore float64
	for i,car := range ret.CarList{
		curScore=car.Score
		if lastScore>0   && curScore>lastScore{
			//Score校验失败
			t.Errorf("Error:%s:Score序列异常：第%d个车源Score为%f，上一个车源Score为%f",functitle,i,curScore,lastScore)
		}
	}
}
//endregion

//region 自定义评分检索：SortBoostFlag=4，自定义排序
func Test_SortBoostFlag4_CustomerSort(t *testing.T) {
	var functitle="Test_SortBoostFlag4_CustomerSort"
	var param=GetBaseParam()
	param.SortBoostFlag=4
	param.CommonFlag=0
	param.CityIdArray=[]int32{201}
	param.RelateCityArray=[]int32{ 906, 2601, 910, 902, 911 }
	param.OrderByFieldArray=[]string{"status","istop","userid","boost"}
	param.OrderByIsDESCArray=[]bool{false,true,false,true}
	param.ReturnFieldArray=[]string{"id","score"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0{
		t.Errorf("Error:%s:ret.Count=0",functitle)
	}
	if len(ret.CarList)==0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	if param.SortBoostFlag==4{
		t.Errorf("Error:%s:Not customer sort,SortBoostFlag=4",functitle)
	}
}
//endregion


//region 自定义评分检索：SortBoostFlag=5，默认排序
func Test_SortBoostFlag5_DefaultSort(t *testing.T) {
	var functitle="Test_SortBoostFlag5_CustomerSort"
	var param=GetBaseParam()
	param.SortBoostFlag=5
	param.CommonFlag=0
	param.NoCityIdArray=[]int32{101}
	param.RelateCityArray=[]int32{ 201, 2601, 910, 902, 911 }
	param.ReturnFieldArray=[]string{"id","score"}

	var ret, err = objSearchService.SearchEs(param,"car")
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0{
		t.Errorf("Error:%s:ret.Count=0",functitle)
	}
	if len(ret.CarList)==0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	if param.SortBoostFlag==4{
		t.Errorf("Error:%s:Not customer sort,SortBoostFlag=5",functitle)
	}
}
//endregion

//region 自定义评分检索：SortBoostFlag=5，自定义排序
func Test_SortBoostFlag5_CustomerSort(t *testing.T) {
	var functitle="Test_SortBoostFlag5_CustomerSort"
	var param=GetBaseParam()
	param.SortBoostFlag=5
	param.CommonFlag=0
	param.NoCityIdArray=[]int32{101}
	param.RelateCityArray=[]int32{ 201, 2601, 910, 902, 911 }
	param.OrderByFieldArray=[]string{"status","istop","userid","boost"}
	param.OrderByIsDESCArray=[]bool{false,true,false,true}
	param.ReturnFieldArray=[]string{"id","score"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0{
		t.Errorf("Error:%s:ret.Count=0",functitle)
	}
	if len(ret.CarList)==0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	if param.SortBoostFlag==4{
		t.Errorf("Error:%s:Not customer sort,SortBoostFlag=4",functitle)
	}
}
//endregion
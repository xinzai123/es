package Test5

import (
	"testing"
)


func Test_1(t *testing.T) {
	var functitle="Test_1"
	var param=GetBaseParam()
	param.MainBrandArray=[]int32{26}
	param.PriceLowerArray=[]float64{3.0}
	param.PriceHighArray=[]float64{10.0}
	param.ProvinceIdArray=[]int32{2}
	param.OrderByFieldArray=[]string{"displayprice"}
	param.OrderByIsDESCArray=[]bool{false}
	param.ReturnFieldArray=[]string{"id","siteid","carpublishtime","istop","displayprice"}
	var ret, err = objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
}

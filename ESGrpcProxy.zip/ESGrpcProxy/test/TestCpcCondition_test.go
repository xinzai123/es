package Test

import (
	"testing"
)

//默认条件
func Test_CpcIndex(t *testing.T) {
	var functitle="Test_CpcIndex"
	var param=GetBaseParam()
	param.CityIdArray=[]int32{201}
	param.ReturnFieldArray=[]string{"id","carcityid"}
	var ret, err = objSearchService.SearchEs(param,"cpccar")
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
	for i:=0;i<len(ret.CarList);i++{
		if ret.CarList[i].Carcityid!=201{
			t.Errorf("Error:%s:Invalid Data:Id:%d,CarCityId:%d",functitle,ret.CarList[i].id,ret.CarList[i].Carcityid)
		}
	}
}

//投放城市
func Test_CpcAdCity(t *testing.T) {
	var functitle="Test_CpcAdCity"
	var param=GetBaseParam()
	param.AdCity=201
	param.ReturnFieldArray=[]string{"id","carcityid"}
	var ret, err = objSearchService.SearchEs(param,"cpccar")
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
}

//投放条件
func Test_CpcAdCondition(t *testing.T) {
	var functitle="Test_CpcAdCondition"
	var param=GetBaseParam()
	param.AdCondition=10
	param.ReturnFieldArray=[]string{"id"}
	var ret, err = objSearchService.SearchEs(param,"cpccar")
	if err != nil {
		t.Errorf("Error:%s:Exception:%s",functitle,err)
	}
	if ret==nil{
		t.Errorf("Error:%s:ret=nil",functitle)
	}
	if ret.Count<=0 || len(ret.CarList)<=0{
		t.Errorf("Error:%s:len(ret.CarList)=0",functitle)
	}
}
package main
import (
	"fmt"
	"./SearchService"
	pb "./grpc"
	"strconv"
	"github.com/simplejia/lc"
)

var objSearchRule = new(ESGoServer.SearchRule)

func main() {

	//初始化local cache size
	lc.Init(1e5)

	//searchrecommend()
	//searchcarcpl()
	searchcar()
	//searchcar()
	//searchquestion()
	//searchcar_v5()
}

//region 搜索推荐车源
func searchrecommend(){
	var objSearchService = new(ESGoServer.SearchServiceClient)
	param:=new(pb.SearchRecommendCondition)
	param.SearchCondition="[{\"fieldname\":\"iscpc\",\"score\":500,\"fieldvalue\":[]},{\"fieldname\":\"mainbrandid\",\"score\":500,\"fieldvalue\":[{\"value\":\"3\",\"weight\":1},{\"value\":\"8\",\"weight\":0.8}]},{\"fieldname\":\"carlevelvalue\",\"score\":800,\"fieldvalue\":[{\"value\":\"8\",\"weight\":1},{\"value\":\"3\",\"weight\":0.5}]},{\"fieldname\":\"displayprice\",\"score\":500,\"fieldvalue\":[{\"value\":\"8,10\",\"weight\":1},{\"value\":\"3,5.5\",\"weight\":0.2}]}]"
	param.PageSize=10
	param.PageIndex=1
	param.RequestSource=9
	param.CarCityIdArray=[]int32{201,901}
	//param.CarProvinceIdArray=[]int32{2,1}
	param.Position="aaa"
	param.IsQueryDsl=1

	ret,err:=objSearchService.SearchRecommendCar(param)
	if(err!=nil){
		fmt.Println(err)
	}
	fmt.Println(ret.Count)
	fmt.Println(ret.QueryDsl)
	fmt.Println(ret.CarJson)

}
//endregion

//region 搜索问答
func searchquestion(){
	var objSearchService = new(ESGoServer.SearchServiceClient)
	var param pb.SearchQuestionCondition
	param.RequestSource=9
	param.PageIndex=1
	param.PageSize=20

	param.KeyWord="韩国 ?驾驶证 ？ 驾驶证z&*……￥！!@#$%QQ"
	param.IsHightLight=true
	param.CategoriesArray=[]string{"保养","过户"}
	param.IsSolveArray=[]int32{1}
	param.HightLightFieldArray=[]string{"title","body"}
	param.CutLengthFieldNameArray=[]string{"title"}
	param.CutLengthFieldValueArray=[]int32{6}
	param.ReturnFieldArray=[]string{"qoid","title","body"}
	param.OrderByFieldArray=[]string{"lastmodifytime"}
	param.OrderByIsDESCArray=[]bool{true}
	ret, _ := objSearchService.SearchEsQuestion(&param)

	for i:=0;i<len(ret.QuestionList);i++{
		fmt.Println(strconv.Itoa(int(ret.QuestionList[i].Qoid))+"问题："+ret.QuestionList[i].Title)
		//fmt.Println("描述："+ret.QuestionList[i].Body)
	}
	fmt.Println(ret.RequestParametersLog)
}
//endregion

//region 搜索车源---CPL
func searchcarcpl(){
	var objSearchService = new(ESGoServer.SearchServiceClient)
	param := new(pb.SearchCondition)
	param.RequestSource=8
	//param.CarSource1L=2
	//param.SiteId=[]int32{5}
	param.StatusArray=[]int32{1}
	param.OrderByFieldArray=[]string{"status","displayprice"}
	param.OrderByIsDESCArray=[]bool{false,false}
	param.CommonFlag=0
	param.CarIDArray=[]int32{6896}
	param.SortBoostFlag=2
	param.PageIndex=1
	param.PageSize=60
	//param.NoCrmCustomerIdArray=[]int32{111,222}
	//param.IsLicensed=0
	//param.DistanceKm=50
	//param.Location="116.403909,39.913994"
	//param.CarAgeHighArray=[]int32{3};
	//param.CarAgeLowerArray=[]int32{1}
	//param.PriceHighArray=[]float64{11.0}
	//param.PriceLowerArray=[]float64{10}
	//param.ColorArray=[]string{"棕"}
	//param.CarSerialArray=[]int32{1825}
	//param.ProvinceIdArray=[]int32{9}
	param.CityIdArray=[]int32{201}
	//param.EnvirStandardArray=[]int32{-1,-1,-1,1,1,-1,-1,-1,-1}
	//param.RelateCityArray=[]int32{ 906, 2601, 910, 902, 911 }
	//param.NoIdArray=[]int32{1111,2222,3333}
	//param.NoCityIdArray=[]int32{301,1001}
	//param.ColorArray=[]string{"深灰"}
	//region 构建facet聚合查询条件
	//objAggrMainbrandid := &pb.AggrCondition{FieldName:"mainbrandid",AggregationType:1,TopNumber:5,SubKeyFieldArray:[]string{"displayprice_stats","displayprice_min","displayprice_max","displayprice_avg","displayprice_sum"},SubAggrTypeArray:[]string{"stats","min","max","avg","sum"},SubValueFieldArray:[]string{"carid","displayprice","displayprice","displayprice","displayprice"},OrderFieldArray:[]string{"displayprice_max"},OrderTypeArray:[]string{"desc"}}
	//objAggrColor := &pb.AggrCondition{FieldName:"color",AggregationType:1,TopNumber:15}
	//objAggrBrandid := &pb.AggrCondition{FieldName:"brandid",AggregationType:1,TopNumber:5}
	//objAggrCarid := &pb.AggrCondition{FieldName:"carid",AggregationType:1,TopNumber:5}
	//objAggrCountryvalue := &pb.AggrCondition{FieldName:"countryvalue",AggregationType:1,TopNumber:5}
	//objAggrGearboxtype := &pb.AggrCondition{FieldName:"gearboxtype",AggregationType:1,TopNumber:5}
	//objAggrCarlevelsecond := &pb.AggrCondition{FieldName:"carlevelsecond",AggregationType:1,TopNumber:5}
	//rangeExhaust:=`{"to": 1,"key": "exhaustvalue_1"},{"from": 1.1,"to": 1.5,"key": "exhaustvalue_2"},{"from": 1.6,"to": 2,"key": "exhaustvalue_3"},{"from": 2.1,"to": 3,"key": "exhaustvalue_4"},{"from": 3.1,"key": "exhaustvalue_5"}`
	//objAggrExhaustvalue := &pb.AggrCondition{FieldName:"exhaustvalue",AggregationType:2,TopNumber:0,RangeConfig:rangeExhaust}
	//rangeDrivingmileage:=`{"to": 10000,"key": "drivingmileage_1"},{"to": 30000,"key": "drivingmileage_2"},{"to": 50000,"key": "drivingmileage_3"},{"to": 100000,"key": "drivingmileage_4"}`
	//objAggrDrivingmileage := &pb.AggrCondition{FieldName:"drivingmileage",AggregationType:2,TopNumber:0,RangeConfig:rangeDrivingmileage}
	//rangePrice:=`{"to":3,"key":"displayprice_1"},{"from":3,"to":5,"key":"displayprice_2"},{"from":5,"to":8,"key":"displayprice_3"},{"from":8,"to":10,"key":"displayprice_4"},{"from":10,"to":15,"key":"displayprice_5"},{"from":15,"to":20,"key":"displayprice_6"},{"from":20,"to":30,"key":"displayprice_7"},{"from":30,"to":50,"key":"displayprice_8"},{"from":50,"to":100,"key":"displayprice_9"},{"from":100,"key":"displayprice_10"}`
	//objAggrPrice := &pb.AggrCondition{FieldName:"displayprice",AggregationType:2,TopNumber:0,RangeConfig:rangePrice}
	//rangeBuycardate:=`{"from":"2015-06-01T00:00:00","key":"buycardate_1"},{"from":"2014-06-01T00:00:00","to":"2015-05-31T00:00:00","key":"buycardate_2"},{"from":"2013-06-01T00:00:00","to":"2014-05-31T00:00:00","key":"buycardate_3"},{"from":"2010-06-01T00:00:00","to":"2013-05-31T00:00:00","key":"buycardate_4"},{"from":"2007-06-01T00:00:00","to":"2010-05-31T00:00:00","key":"buycardate_5"},{"to":"2007-05-31T00:00:00","key":"buycardate_6"}`
	//objAggrBuycardate := &pb.AggrCondition{FieldName:"buycardate",AggregationType:2,TopNumber:0,RangeConfig:rangeBuycardate,SubKeyFieldArray:[]string{"displayprice_avg"},SubAggrTypeArray:[]string{"avg"},SubValueFieldArray:[]string{"displayprice"}}
	//////endregion
	//param.AggrFieldList=[]*pb.AggrCondition{objAggrMainbrandid,objAggrColor,objAggrBrandid,objAggrCarid,objAggrCountryvalue,objAggrGearboxtype,objAggrCarlevelsecond,objAggrExhaustvalue,objAggrDrivingmileage,objAggrPrice,objAggrBuycardate}
	//param.AggrFieldList=[]*pb.AggrCondition{objAggrColor}

	//param.AdCity=201
	//param.AdCondition=10
	param.ReturnFieldArray=[]string{"id","cartitle","color","lastprice","score","vendorname"}
	//param.ReturnFieldArray=[]string{"id","serialnumber","status","distance","carcityid","color","drivingmileage","completerate","carsource1l","isvideo","firstpictrue","cartype","source","isneglect","picturecount","displayprice","statusmodifytime","createtime","buycardate","carpublishtime","picwholepath","isdealerrecommend","isauthenticated","isrecommendgl","isowncar","c2bprice","isblackvendor","istop","statedescription","iswarranty","warrantytypes","mainbrandid","brandid","carid","carlevel","caryear","producerid","country","gearboxtype","gearboxtypestring","exhaustvalue","car_referprice","userid","superiorid","vendorname","vendortype","isjdvendor","membertype","isbangmai","dvqflag","isbangmaiche","ismarkingvendor","baidumap","distance","contact","envirstandard","consumption","oiltype","iswagon","drivetype","isagency","usertype","csbodyform","cartypeconfig","envirstandard_1","envirstandard_2","envirstandard_3","envirstandard_4","envirstandard_5","envirstandard_6","envirstandard_7","envirstandard_8","envirstandard_9","id","siteid","isactivity","boostapp"}

	//param.KeyWord="宝马x"
	//param.CarBenefitRateHigh=0.5
	//param.CarBenefitRateLower=0.3
	//param.IsCarId=1
	//param.IsCountSearch=true
	param.RequestParametersLog="get"
	//param.VinCodeArray=[]string{"LFV3A24G6D3087641"}

	ret, _ := objSearchService.SearchEs_CPL(param,"car")
	//ret, _ := objSearchService.SearchEs(param,"car")
	fmt.Println(ret.Count)
	fmt.Println(ret.RequestParametersLog)
	//tools.GetLogger().Log("测试日志消息1："+ret.RequestParametersLog,"car",2,nil,param,nil)
	//tools.GetLogger().Log("测试日志消息2："+ret.RequestParametersLog,"car",2,nil,param,nil)
	//tools.GetLogger().Log("测试日志消息3："+ret.RequestParametersLog,"car",2,nil,param,nil)
	//tools.GetLogger().Log("测试日志消息4："+ret.RequestParametersLog,"car",2,nil,param,nil)
	//tools.GetLogger().LogCount("car",4)
	//tools.GetLogger().LogCount("car",1)
	//tools.GetLogger().LogCount("car",2)
	//tools.GetLogger().LogCount("car",3)
	//tools.GetLogger().LogCount("car",4)
	//tools.GetLogger().LogCount("car",1)
	//tools.GetLogger().LogCount("car",2)
	//tools.GetLogger().LogCount("car",2)
	//tools.GetLogger().LogCount("car",3)
	//tools.GetLogger().LogCount("car",3)
	//tools.ConsumeLogCountChannel()
	//return

	if ret==nil{
		fmt.Println("返回结果为空")
		return
	}
	for i:=0;i<len(ret.Facet);i++{
		fmt.Println(ret.Facet[i].FieldName)
		for j:=0;j<len(ret.Facet[i].AggrValue);j++{
			fmt.Println(ret.Facet[i].AggrValue[j].TermName+","+strconv.Itoa(int(ret.Facet[i].AggrValue[j].Count)))
			if len(ret.Facet[i].AggrValue[j].SubAggr)>0{
				for k:=0;k<len(ret.Facet[i].AggrValue[j].SubAggr);k++{
					fmt.Println(ret.Facet[i].AggrValue[j].SubAggr)
				}
			}
		}

	}
	for i:=0;i<len(ret.CarList);i++{
		fmt.Println(strconv.Itoa(int(ret.CarList[i].id))+"\t"+ret.CarList[i].Vendorname+"\t"+ret.CarList[i].Cartitle+"\t"+strconv.Itoa(int(ret.CarList[i].status))+"\t"+strconv.FormatFloat(ret.CarList[i].Displayprice,'f',6,64)+"\t"+strconv.FormatFloat(ret.CarList[i].Score,'f',6,64))
	}
}
//endregion

//region 搜索车源---老版本
func searchcar(){
	var objSearchService = new(ESGoServer.SearchServiceClient)
	param := new(pb.SearchCondition)
	param.RequestSource=221
	//param.CarSource1L=2
	//param.SiteId=[]int32{5}
	param.StatusArray=[]int32{1}
	//param.OrderByFieldArray=[]string{"id","cartitle","score"}
	//param.OrderByIsDESCArray=[]bool{false,false}
	param.CommonFlag=2
	param.SortBoostFlag=3
	param.PageIndex=1
	param.PageSize=20
	//param.ProvinceIdArray=[]int32{1}
	//param.IsActivity=100
	//param.NoCrmCustomerIdArray=[]int32{111,222}
	//param.IsLicensed=0
	//param.DistanceKm=50
	//param.Location="116.403909,39.913994"
	//param.CarAgeHighArray=[]int32{3};
	//param.CarAgeLowerArray=[]int32{1}
	//param.PriceHighArray=[]float64{11.0}
	//param.PriceLowerArray=[]float64{10}
	//param.ColorArray=[]string{"棕"}
	//param.CarSerialArray=[]int32{1825}
	//param.ProvinceIdArray=[]int32{9}
	//param.CityIdArray=[]int32{201}
	//param.EnvirStandardArray=[]int32{-1,-1,-1,1,1,-1,-1,-1,-1}
	//param.RelateCityArray=[]int32{ 906, 2601, 910, 902, 911 }
	//param.NoIdArray=[]int32{1111,2222,3333}
	//param.NoCityIdArray=[]int32{301,1001}
	//param.ColorArray=[]string{"深灰"}
	//region 构建facet聚合查询条件
	//objAggrMainbrandid := &pb.AggrCondition{FieldName:"mainbrandid",AggregationType:1,TopNumber:5,SubKeyFieldArray:[]string{"displayprice_stats","displayprice_min","displayprice_max","displayprice_avg","displayprice_sum"},SubAggrTypeArray:[]string{"stats","min","max","avg","sum"},SubValueFieldArray:[]string{"carid","displayprice","displayprice","displayprice","displayprice"},OrderFieldArray:[]string{"displayprice_max"},OrderTypeArray:[]string{"desc"}}
	//objAggrColor := &pb.AggrCondition{FieldName:"color",AggregationType:1,TopNumber:15}
	//objAggrBrandid := &pb.AggrCondition{FieldName:"brandid",AggregationType:1,TopNumber:5}
	//objAggrCarid := &pb.AggrCondition{FieldName:"carid",AggregationType:1,TopNumber:5}
	//objAggrCountryvalue := &pb.AggrCondition{FieldName:"countryvalue",AggregationType:1,TopNumber:5}
	//objAggrGearboxtype := &pb.AggrCondition{FieldName:"gearboxtype",AggregationType:1,TopNumber:5}
	//objAggrCarlevelsecond := &pb.AggrCondition{FieldName:"carlevelsecond",AggregationType:1,TopNumber:5}
	//rangeExhaust:=`{"to": 1,"key": "exhaustvalue_1"},{"from": 1.1,"to": 1.5,"key": "exhaustvalue_2"},{"from": 1.6,"to": 2,"key": "exhaustvalue_3"},{"from": 2.1,"to": 3,"key": "exhaustvalue_4"},{"from": 3.1,"key": "exhaustvalue_5"}`
	//objAggrExhaustvalue := &pb.AggrCondition{FieldName:"exhaustvalue",AggregationType:2,TopNumber:0,RangeConfig:rangeExhaust}
	//rangeDrivingmileage:=`{"to": 10000,"key": "drivingmileage_1"},{"to": 30000,"key": "drivingmileage_2"},{"to": 50000,"key": "drivingmileage_3"},{"to": 100000,"key": "drivingmileage_4"}`
	//objAggrDrivingmileage := &pb.AggrCondition{FieldName:"drivingmileage",AggregationType:2,TopNumber:0,RangeConfig:rangeDrivingmileage}
	//rangePrice:=`{"to":3,"key":"displayprice_1"},{"from":3,"to":5,"key":"displayprice_2"},{"from":5,"to":8,"key":"displayprice_3"},{"from":8,"to":10,"key":"displayprice_4"},{"from":10,"to":15,"key":"displayprice_5"},{"from":15,"to":20,"key":"displayprice_6"},{"from":20,"to":30,"key":"displayprice_7"},{"from":30,"to":50,"key":"displayprice_8"},{"from":50,"to":100,"key":"displayprice_9"},{"from":100,"key":"displayprice_10"}`
	//objAggrPrice := &pb.AggrCondition{FieldName:"displayprice",AggregationType:2,TopNumber:0,RangeConfig:rangePrice}
	//rangeBuycardate:=`{"from":"2015-06-01T00:00:00","key":"buycardate_1"},{"from":"2014-06-01T00:00:00","to":"2015-05-31T00:00:00","key":"buycardate_2"},{"from":"2013-06-01T00:00:00","to":"2014-05-31T00:00:00","key":"buycardate_3"},{"from":"2010-06-01T00:00:00","to":"2013-05-31T00:00:00","key":"buycardate_4"},{"from":"2007-06-01T00:00:00","to":"2010-05-31T00:00:00","key":"buycardate_5"},{"to":"2007-05-31T00:00:00","key":"buycardate_6"}`
	//objAggrBuycardate := &pb.AggrCondition{FieldName:"buycardate",AggregationType:2,TopNumber:0,RangeConfig:rangeBuycardate,SubKeyFieldArray:[]string{"displayprice_avg"},SubAggrTypeArray:[]string{"avg"},SubValueFieldArray:[]string{"displayprice"}}
	//////endregion
	//param.AggrFieldList=[]*pb.AggrCondition{objAggrMainbrandid,objAggrColor,objAggrBrandid,objAggrCarid,objAggrCountryvalue,objAggrGearboxtype,objAggrCarlevelsecond,objAggrExhaustvalue,objAggrDrivingmileage,objAggrPrice,objAggrBuycardate}
	//param.AggrFieldList=[]*pb.AggrCondition{objAggrColor}

	//param.AdCity=201
	//param.AdCondition=10
	param.ReturnFieldArray=[]string{"id","cartitle","color","lastprice","score","carproviceid"}
	//param.ReturnFieldArray=[]string{"id","serialnumber","status","distance","carcityid","color","drivingmileage","completerate","carsource1l","isvideo","firstpictrue","cartype","source","isneglect","picturecount","displayprice","statusmodifytime","createtime","buycardate","carpublishtime","picwholepath","isdealerrecommend","isauthenticated","isrecommendgl","isowncar","c2bprice","isblackvendor","istop","statedescription","iswarranty","warrantytypes","mainbrandid","brandid","carid","carlevel","caryear","producerid","country","gearboxtype","gearboxtypestring","exhaustvalue","car_referprice","userid","superiorid","vendorname","vendortype","isjdvendor","membertype","isbangmai","dvqflag","isbangmaiche","ismarkingvendor","baidumap","distance","contact","envirstandard","consumption","oiltype","iswagon","drivetype","isagency","usertype","csbodyform","cartypeconfig","envirstandard_1","envirstandard_2","envirstandard_3","envirstandard_4","envirstandard_5","envirstandard_6","envirstandard_7","envirstandard_8","envirstandard_9","id","siteid","isactivity","boostapp"}

	//param.KeyWord="宝马x"
	//param.CarBenefitRateHigh=0.5
	//param.CarBenefitRateLower=0.3
	//param.IsCarId=1
	//param.IsCountSearch=true
	param.SeatNumLowerArray=[]int32{2,5}
	param.SeatNumHighArray=[]int32{2,5}
	param.RequestParametersLog="get"

	indexname:=objSearchRule.GetIndexName(param)
	fmt.Println(indexname)
	//param.VinCodeArray=[]string{"LFV3A24G6D3087641"}

	ret, _ := objSearchService.SearchEsWithLocalCache(param,indexname)
	//ret, _ := objSearchService.SearchEs(param,"car")
	fmt.Println(ret.RequestParametersLog)
	fmt.Println(ret.Count)
	ret, _ = objSearchService.SearchEsWithLocalCache(param,indexname)
	//ret, _ := objSearchService.SearchEs(param,"car")
	fmt.Println(ret.RequestParametersLog)
	fmt.Println(ret.Count)

	//tools.GetLogger().Log("测试日志消息1："+ret.RequestParametersLog,"car",2,nil,param,nil)
	//tools.GetLogger().Log("测试日志消息2："+ret.RequestParametersLog,"car",2,nil,param,nil)
	//tools.GetLogger().Log("测试日志消息3："+ret.RequestParametersLog,"car",2,nil,param,nil)
	//tools.GetLogger().Log("测试日志消息4："+ret.RequestParametersLog,"car",2,nil,param,nil)
	//tools.GetLogger().LogCount("car",4)
	//tools.GetLogger().LogCount("car",1)
	//tools.GetLogger().LogCount("car",2)
	//tools.GetLogger().LogCount("car",3)
	//tools.GetLogger().LogCount("car",4)
	//tools.GetLogger().LogCount("car",1)
	//tools.GetLogger().LogCount("car",2)
	//tools.GetLogger().LogCount("car",2)
	//tools.GetLogger().LogCount("car",3)
	//tools.GetLogger().LogCount("car",3)
	//tools.ConsumeLogCountChannel()
	//return

	if ret==nil || len(ret.CarList)==0{
		fmt.Println("返回结果为空")
		return
	}
	//for i:=0;i<len(ret.Facet);i++{
	//	fmt.Println(ret.Facet[i].FieldName)
	//	for j:=0;j<len(ret.Facet[i].AggrValue);j++{
	//		fmt.Println(ret.Facet[i].AggrValue[j].TermName+","+strconv.Itoa(int(ret.Facet[i].AggrValue[j].Count)))
	//		if len(ret.Facet[i].AggrValue[j].SubAggr)>0{
	//			for k:=0;k<len(ret.Facet[i].AggrValue[j].SubAggr);k++{
	//				fmt.Println(ret.Facet[i].AggrValue[j].SubAggr)
	//			}
	//		}
	//	}
	//
	//}
	//for i:=0;i<len(ret.CarList);i++{
	//	fmt.Println(ret.CarList[i].Cartitle+"\t"+ret.CarList[i].Color+"\t"+strconv.Itoa(int(ret.CarList[i].status))+"\t"+strconv.FormatFloat(ret.CarList[i].Distance,'f',6,64)+"\t"+strconv.FormatFloat(ret.CarList[i].Displayprice,'f',6,64)+"\t"+strconv.FormatFloat(ret.CarList[i].Score,'f',6,64))
	//	//fmt.Println(ret.CarList[i].Lastprice)
	//	//fmt.Println(ret.CarList[i].Pricechangetime)
	//}
}
//endregion

//region 搜索车源---新版本
func searchcar_v5(){
	var objSearchService = new(ESGoServer.SearchServiceClient_V5)
	param := new(pb.SearchCondition)
	param.RequestSource=8
	param.CarSource1L=2
	param.StatusArray=[]int32{1}
	//param.OrderByFieldArray=[]string{"boostc"}
	//param.OrderByIsDESCArray=[]bool{true}
	param.CommonFlag=0
	param.SortBoostFlag=0
	param.PageIndex=1
	param.PageSize=5
	//param.DistanceKm=50
	//param.Location="116.403909,39.913994"
	//param.CarAgeHighArray=[]int32{3};
	//param.CarAgeLowerArray=[]int32{1}
	//param.PriceHighArray=[]float64{10.0,20}
	//param.PriceLowerArray=[]float64{3.0,15.0}
	//param.DistanceKm=100
	//param.Location="116.403909,39.913994"
	//param.ColorArray=[]string{"白"}
	//param.CarSerialArray=[]int32{1825}
	//param.CityIdArray=[]int32{201}
	//param.RelateCityArray=[]int32{ 906, 2601, 910, 902, 911 }
	//param.SeatNumHighArray=[]int32{3,5}
	//param.SeatNumLowerArray=[]int32{2,4}
	//param.NoIdArray=[]int32{1111,444}
	//param.NoCityIdArray=[]int32{301,1001}
	//param.AdCity=2401
	//region 构建facet聚合查询条件
	//objAggrMainbrandid := &pb.AggrCondition{FieldName:"mainbrandid",AggregationType:1,TopNumber:5,SubKeyFieldArray:[]string{"displayprice_stats","displayprice_min","displayprice_max","displayprice_avg","displayprice_sum"},SubAggrTypeArray:[]string{"stats","min","max","avg","sum"},SubValueFieldArray:[]string{"carid","displayprice","displayprice","displayprice","displayprice"},OrderFieldArray:[]string{"displayprice_max"},OrderTypeArray:[]string{"desc"}}
	//objAggrColor := &pb.AggrCondition{FieldName:"color",AggregationType:1,TopNumber:15}
	//objAggrBrandid := &pb.AggrCondition{FieldName:"brandid",AggregationType:1,TopNumber:5}
	//objAggrCarid := &pb.AggrCondition{FieldName:"carid",AggregationType:1,TopNumber:5}
	//objAggrCountryvalue := &pb.AggrCondition{FieldName:"countryvalue",AggregationType:1,TopNumber:5}
	//objAggrGearboxtype := &pb.AggrCondition{FieldName:"gearboxtype",AggregationType:1,TopNumber:5}
	//objAggrCarlevelsecond := &pb.AggrCondition{FieldName:"carlevelsecond",AggregationType:1,TopNumber:5}
	//rangeExhaust:=`{"to": 1,"key": "exhaustvalue_1"},{"from": 1.1,"to": 1.5,"key": "exhaustvalue_2"},{"from": 1.6,"to": 2,"key": "exhaustvalue_3"},{"from": 2.1,"to": 3,"key": "exhaustvalue_4"},{"from": 3.1,"key": "exhaustvalue_5"}`
	//objAggrExhaustvalue := &pb.AggrCondition{FieldName:"exhaustvalue",AggregationType:2,TopNumber:0,RangeConfig:rangeExhaust}
	//rangeDrivingmileage:=`{"to": 10000,"key": "drivingmileage_1"},{"to": 30000,"key": "drivingmileage_2"},{"to": 50000,"key": "drivingmileage_3"},{"to": 100000,"key": "drivingmileage_4"}`
	//objAggrDrivingmileage := &pb.AggrCondition{FieldName:"drivingmileage",AggregationType:2,TopNumber:0,RangeConfig:rangeDrivingmileage}
	//rangePrice:=`{"to":3,"key":"displayprice_1"},{"from":3,"to":5,"key":"displayprice_2"},{"from":5,"to":8,"key":"displayprice_3"},{"from":8,"to":10,"key":"displayprice_4"},{"from":10,"to":15,"key":"displayprice_5"},{"from":15,"to":20,"key":"displayprice_6"},{"from":20,"to":30,"key":"displayprice_7"},{"from":30,"to":50,"key":"displayprice_8"},{"from":50,"to":100,"key":"displayprice_9"},{"from":100,"key":"displayprice_10"}`
	//objAggrPrice := &pb.AggrCondition{FieldName:"displayprice",AggregationType:2,TopNumber:0,RangeConfig:rangePrice}
	//rangeBuycardate:=`{"from":"2015-06-01T00:00:00","key":"buycardate_1"},{"from":"2014-06-01T00:00:00","to":"2015-05-31T00:00:00","key":"buycardate_2"},{"from":"2013-06-01T00:00:00","to":"2014-05-31T00:00:00","key":"buycardate_3"},{"from":"2010-06-01T00:00:00","to":"2013-05-31T00:00:00","key":"buycardate_4"},{"from":"2007-06-01T00:00:00","to":"2010-05-31T00:00:00","key":"buycardate_5"},{"to":"2007-05-31T00:00:00","key":"buycardate_6"}`
	//objAggrBuycardate := &pb.AggrCondition{FieldName:"buycardate",AggregationType:2,TopNumber:0,RangeConfig:rangeBuycardate,SubKeyFieldArray:[]string{"displayprice_avg"},SubAggrTypeArray:[]string{"avg"},SubValueFieldArray:[]string{"displayprice"}}
	//////endregion
	//param.AggrFieldList=[]*pb.AggrCondition{objAggrMainbrandid,objAggrColor,objAggrBrandid,objAggrCarid,objAggrCountryvalue,objAggrGearboxtype,objAggrCarlevelsecond,objAggrExhaustvalue,objAggrDrivingmileage,objAggrPrice,objAggrBuycardate}
	//param.AggrFieldList=[]*pb.AggrCondition{objAggrColor,objAggrMainbrandid,objAggrBrandid,objAggrExhaustvalue,objAggrDrivingmileage,objAggrBuycardate}


	//objAggrMainbrandid := &pb.AggrCondition{FieldName:"mainbrandid",AggregationType:1,TopNumber:5,SubKeyFieldArray:[]string{"displayprice_stats","displayprice_min","displayprice_max","displayprice_avg","displayprice_sum"},SubAggrTypeArray:[]string{"stats","min","max","avg","sum"},SubValueFieldArray:[]string{"carid","displayprice","displayprice","displayprice","displayprice"},OrderFieldArray:[]string{"displayprice_max"},OrderTypeArray:[]string{"desc"}}
	//objAggrMainbrandid := &pb.AggrCondition{FieldName:"mainbrandid",AggregationType:1,TopNumber:100}
	//objAggrColor := &pb.AggrCondition{FieldName:"color",AggregationType:1,TopNumber:10}
	//objAggrBrandid := &pb.AggrCondition{FieldName:"brandid",AggregationType:1,TopNumber:100}
	//objAggrCarid := &pb.AggrCondition{FieldName:"carid",AggregationType:1,TopNumber:100}
	//objAggrCountryvalue := &pb.AggrCondition{FieldName:"countryvalue",AggregationType:1,TopNumber:20}
	//objAggrGearboxtype := &pb.AggrCondition{FieldName:"gearboxtype",AggregationType:1,TopNumber:10}
	//objAggrCarlevelsecond := &pb.AggrCondition{FieldName:"carlevelsecond",AggregationType:1,TopNumber:10}
	//rangeExhaust:=`{"to": 1,"key": "exhaustvalue_1"},{"from": 1.1,"to": 1.5,"key": "exhaustvalue_2"},{"from": 1.6,"to": 2,"key": "exhaustvalue_3"},{"from": 2.1,"to": 3,"key": "exhaustvalue_4"},{"from": 3.1,"key": "exhaustvalue_5"}`
	//objAggrExhaustvalue := &pb.AggrCondition{FieldName:"exhaustvalue",AggregationType:2,TopNumber:0,RangeConfig:rangeExhaust}
	//rangeDrivingmileage:=`{"to": 10000,"key": "drivingmileage_1"},{"to": 30000,"key": "drivingmileage_2"},{"to": 50000,"key": "drivingmileage_3"},{"to": 100000,"key": "drivingmileage_4"}`
	//objAggrDrivingmileage := &pb.AggrCondition{FieldName:"drivingmileage",AggregationType:2,TopNumber:0,RangeConfig:rangeDrivingmileage}
	//rangePrice:=`{"to":3,"key":"displayprice_1"},{"from":3,"to":5,"key":"displayprice_2"},{"from":5,"to":8,"key":"displayprice_3"},{"from":8,"to":10,"key":"displayprice_4"},{"from":10,"to":15,"key":"displayprice_5"},{"from":15,"to":20,"key":"displayprice_6"},{"from":20,"to":30,"key":"displayprice_7"},{"from":30,"to":50,"key":"displayprice_8"},{"from":50,"to":100,"key":"displayprice_9"},{"from":100,"key":"displayprice_10"}`
	//objAggrPrice := &pb.AggrCondition{FieldName:"displayprice",AggregationType:2,TopNumber:0,RangeConfig:rangePrice}
	//rangeBuycardate:=`{"from":"2015-06-01T00:00:00","key":"buycardate_1"},{"from":"2014-06-01T00:00:00","to":"2015-05-31T00:00:00","key":"buycardate_2"},{"from":"2013-06-01T00:00:00","to":"2014-05-31T00:00:00","key":"buycardate_3"},{"from":"2010-06-01T00:00:00","to":"2013-05-31T00:00:00","key":"buycardate_4"},{"from":"2007-06-01T00:00:00","to":"2010-05-31T00:00:00","key":"buycardate_5"},{"to":"2007-05-31T00:00:00","key":"buycardate_6"}`
	//objAggrBuycardate := &pb.AggrCondition{FieldName:"buycardate",AggregationType:2,TopNumber:0,RangeConfig:rangeBuycardate}
	//
	//param.AggrFieldList=[]*pb.AggrCondition{objAggrMainbrandid,objAggrColor,objAggrBrandid,objAggrCarid,objAggrCountryvalue,objAggrGearboxtype,objAggrCarlevelsecond,objAggrExhaustvalue,objAggrDrivingmileage,objAggrPrice,objAggrBuycardate}
	param.ProvinceIdArray=[]int32{10}
	param.CarSerialArray=[]int32{2593}
	param.ReturnFieldArray=[]string{"warrantytypes_3","warrantytypes_2","warrantytypes_1","id","color","brandid","mainbrandid","buycardate","displayprice","drivingmileage","exhaustvalue","carlevelsecond","gearboxtype","countryvalue","carid"}


	//param.AdCity=201
	//param.AdCondition=10
	//param.ReturnFieldArray=[]string{"id","cartitle","color","carcityid","status","displayprice","score","distance"}
	//param.ReturnFieldArray=[]string{"id","serialnumber","status","distance","carcityid","color","drivingmileage","completerate","carsource1l","isvideo","firstpictrue","cartype","source","isneglect","picturecount","displayprice","statusmodifytime","createtime","buycardate","carpublishtime","picwholepath","isdealerrecommend","isauthenticated","isrecommendgl","isowncar","c2bprice","isblackvendor","istop","statedescription","iswarranty","warrantytypes","mainbrandid","brandid","carid","carlevel","caryear","producerid","country","gearboxtype","gearboxtypestring","exhaustvalue","car_referprice","userid","superiorid","vendorname","vendortype","isjdvendor","membertype","isbangmai","dvqflag","isbangmaiche","ismarkingvendor","baidumap","distance","contact","envirstandard","consumption","oiltype","iswagon","drivetype","isagency","usertype","csbodyform","cartypeconfig","envirstandard_1","envirstandard_2","envirstandard_3","envirstandard_4","envirstandard_5","envirstandard_6","envirstandard_7","envirstandard_8","envirstandard_9","id","siteid","isactivity","boostapp"}

	//param.KeyWord="2013"
	//param.CarBenefitRateHigh=0.5
	//param.CarBenefitRateLower=0.3
	//param.IsCarId=1
	//param.IsCountSearch=true
	//param.DistanceKm=100
	//param.Location="116.403909,39.913994"
	param.RequestParametersLog="get"
	//param.IsCountSearch=true
	ret, err := objSearchService.SearchEs(param,objSearchRule.GetIndexName(param))
	if err!=nil{
		fmt.Println(err)
	}
	fmt.Println(ret.Count)
	fmt.Println(ret.RequestParametersLog)

	if ret==nil{
		fmt.Println("返回结果为空")
		return
	}
	for i:=0;i<len(ret.Facet);i++{
		fmt.Println(ret.Facet[i].FieldName)
		for j:=0;j<len(ret.Facet[i].AggrValue);j++{
			fmt.Println(ret.Facet[i].AggrValue[j].TermName+","+strconv.Itoa(int(ret.Facet[i].AggrValue[j].Count)))
			if len(ret.Facet[i].AggrValue[j].SubAggr)>0{
				for k:=0;k<len(ret.Facet[i].AggrValue[j].SubAggr);k++{
					fmt.Println(ret.Facet[i].AggrValue[j].SubAggr)
				}
			}
		}

	}
	for i:=0;i<len(ret.CarList);i++{
		fmt.Println(ret.CarList[i].Score)
		fmt.Println(ret.CarList[i].Cartitle+"\t"+strconv.Itoa(int(ret.CarList[i].Distance))+"\t"+strconv.Itoa(int(ret.CarList[i].status))+"\t"+strconv.FormatFloat(ret.CarList[i].Displayprice,'f',6,64))
	}
}
//endregion
package main

import (
	"./SearchService"
	"fmt"
	pb "./grpc"
	"golang.org/x/net/context"
	"net"
	"log"
	"google.golang.org/grpc"
	"./tools"
	"github.com/simplejia/lc"
)

///**************************************************************************
/// ES-Proxy 服务入口类
///**************************************************************************

type ESServiceServerImpl struct {
}

//region 定义公共变量
var objRequest = new(ESGoServer.RequestHelper)
var objSearchService = new(ESGoServer.SearchServiceClient)
var objSearchRule = new(ESGoServer.SearchRule)
var objSearchTool = new(ESGoServer.SearchTool)
//endregion

//region 搜索推荐车源，用于猜你喜欢车源区块【未启用】
//按传入的多组标签进行动态打分，返回得分最高的车源，因CPU资源消耗过多，未启用
func (s *ESServiceServerImpl) SearchRecommendCar(ctx context.Context, param *pb.SearchRecommendCondition) (r *pb.SearchRecommendResult, err error) {
	r, err = objSearchService.SearchRecommendCar(param)
	return r, err
}
//endregion

//region 搜索常规车源入口方法
func (s *ESServiceServerImpl) SearchCar(ctx context.Context, param *pb.SearchCondition) (r *pb.SearchResult, err error) {
	indexname:=objSearchRule.GetIndexName(param)
	r, err = objSearchService.SearchEsWithLocalCache(param,indexname)
	//终止CPL车源补充机制：2017-08-10
	//if objSearchTool.CheckSliceContain(tools.MyConfigHelper.ConfigCentor().CPLRequestSourceArray,param.RequestSource){
	//	//部分渠道采取CPL车源补充规则
	//	r, err = objSearchService.SearchEs_CPL(param,indexname)
	//}else{
	//	r, err = objSearchService.SearchEs(param,indexname)
	//}
	if tools.MyConfigHelper.ConfigCentor().ES_IsCopyRequest && tools.MyConfigHelper.ConfigCentor().ES_CopyRequestSource>=0{
		//复制请求到RequestChannel
		if tools.MyConfigHelper.ConfigCentor().ES_CopyRequestSource==0 || tools.MyConfigHelper.ConfigCentor().ES_CopyRequestSource==int(param.RequestSource){
			objRequest.AddRequestChannel(param)
		}
	}
	return r, err
}
//endregion

//region 搜索京东车源入口
func (this *ESServiceServerImpl) SearchJDCar(ctx context.Context, param *pb.SearchCondition) (r *pb.SearchResult, err error) {
	r, err = objSearchService.SearchEs(param,"jdcar")
	return r, err
}
//endregion

//region 搜索CPC车源入口
func (this *ESServiceServerImpl) SearchCPCCar(ctx context.Context, param *pb.SearchCondition) (*pb.SearchResult, error) {
	return objSearchService.SearchEs(param,"cpccar")
}
//endregion

//region 搜索问答数据入口
func (this *ESServiceServerImpl) SearchQuestion(ctx context.Context, param *pb.SearchQuestionCondition) (r *pb.SearchResult, err error) {
	r, err = objSearchService.SearchEsQuestion(param)
	return r, err
}
//endregion

//region 服务总入口方法
func main() {
	//region 启动异步routine，用于执行异步操作
	go func(){
		//定时自动刷新配置文件
		tools.RefreshConfigCentor()
	}()
	go func(){
		//消费搜索明细日志chan
		tools.ConsumeLogChannel()
	}()
	go func(){
		//消费搜索次数日志chan
		tools.ConsumeLogCountChannel()
	}()
	go func(){
		//自动复制请求并异步访问
		ESGoServer.ConsumeRequestChannel()
	}()
	//endregion

	//初始化本地缓存队列大小local cache size
	lc.Init(tools.MyConfigHelper.ConfigCentor().ES_LocalCacheSize)

	//runtime.GOMAXPROCS(runtime.NumCPU())
	tools.GetLogger().Log("服务启动--开始："+tools.MyConfigHelper.ConfigCentor().Server_Host+":"+tools.MyConfigHelper.ConfigCentor().Server_Port,"esgrpc",1,nil,nil,nil,0,-1)
	fmt.Println(tools.MyConfigHelper.ConfigCentor().Server_Host+":"+tools.MyConfigHelper.ConfigCentor().Server_Port)
	lis, err := net.Listen("tcp", tools.MyConfigHelper.ConfigCentor().Server_Host+":"+tools.MyConfigHelper.ConfigCentor().Server_Port)
	if err != nil {
		log.Fatalf("failed to listen: %v", err)
		fmt.Println(err)
		tools.GetLogger().Log("服务启动-Listen初始化失败："+tools.MyConfigHelper.ConfigCentor().Server_Host+":"+tools.MyConfigHelper.ConfigCentor().Server_Port,"esgrpc",1,nil,nil,err,0,-1)
	}
	s := grpc.NewServer()
	pb.RegisterESServiceServer(s,&ESServiceServerImpl{})
	if err := s.Serve(lis); err != nil {
		log.Fatalf("failed to serve: %v", err)
		fmt.Println(err)
		tools.GetLogger().Log("服务启动-Serve失败："+tools.MyConfigHelper.ConfigCentor().Server_Host+":"+tools.MyConfigHelper.ConfigCentor().Server_Port,"esgrpc",1,nil,nil,err,0,-1)
	}else{
		fmt.Println("begin to liston...")
		tools.GetLogger().Log("服务启动--完成，开始监听："+tools.MyConfigHelper.ConfigCentor().Server_Host+":"+tools.MyConfigHelper.ConfigCentor().Server_Port,"esgrpc",1,nil,nil,nil,0,-1)
	}
}
//endregion